"""AWS CloudWatch Logs adapter for unified error monitoring."""
import os
import logging
import boto3
from typing import List, Optional
from datetime import datetime
from dotenv import load_dotenv
from botocore.exceptions import ClientError, NoCredentialsError

from src.monitoring.base import MonitoringToolInterface
from src.normalization.normalizer import UnifiedError
from src.monitoring.config import get_cloudwatch_filter_pattern, get_cloudwatch_log_groups, is_query_all_log_groups

load_dotenv()

AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")


def _resolve_region() -> str:
    """Resolve AWS region with guards against invalid placeholders."""
    region = os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1"
    region = region.strip()
    if not region:
        raise ValueError("AWS region is empty; set AWS_REGION or AWS_DEFAULT_REGION")
    if region.lower() == "global":
        raise ValueError("AWS_REGION is set to 'Global'; please set a real region like 'us-east-1'")
    return region

logger = logging.getLogger(__name__)


class CloudWatchMonitor(MonitoringToolInterface):
    """CloudWatch Logs monitoring adapter."""
    
    def __init__(self):
        """Initialize CloudWatch client."""
        self.client = self._get_client()
        self.log_groups = get_cloudwatch_log_groups()
        self.filter_pattern = get_cloudwatch_filter_pattern()
        
    def _get_client(self):
        """Get AWS CloudWatch Logs client with credentials from environment."""
        region = _resolve_region()
        if AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY:
            return boto3.client(
                'logs',
                region_name=region,
                aws_access_key_id=AWS_ACCESS_KEY_ID,
                aws_secret_access_key=AWS_SECRET_ACCESS_KEY
            )
        # Try to use default credentials (IAM role, ~/.aws/credentials, etc.)
        return boto3.client('logs', region_name=region)
    
    def get_tool_name(self) -> str:
        """Return the name of the monitoring tool."""
        return "CLOUDWATCH"
    
    def validate_connection(self) -> bool:
        """
        Validate AWS CloudWatch connection and permissions.
        
        Returns:
            True if connection successful
            
        Raises:
            ValueError: If required environment variables are missing
            ConnectionError: If CloudWatch API is unreachable or permissions are insufficient
        """
        try:
            # Test connection with a simple API call
            if is_query_all_log_groups():
                # Query all log groups
                response = self.client.describe_log_groups(limit=1)
                if 'logGroups' not in response:
                    raise ConnectionError("CloudWatch API returned unexpected response")
                logger.info("✅ CloudWatch connection validated (ALL log groups)")
            elif isinstance(self.log_groups, list):
                # Validate first log group
                log_group = self.log_groups[0]
                response = self.client.describe_log_groups(
                    logGroupNamePrefix=log_group,
                    limit=1
                )
                log_groups = response.get('logGroups', [])
                if not log_groups:
                    raise ConnectionError(f"CloudWatch log group not found: {log_group}")
                logger.info(f"✅ CloudWatch connection validated ({len(self.log_groups)} log groups)")
            else:
                # Single log group
                response = self.client.describe_log_groups(
                    logGroupNamePrefix=self.log_groups,
                    limit=1
                )
                log_groups = response.get('logGroups', [])
                if not log_groups or not any(lg['logGroupName'] == self.log_groups for lg in log_groups):
                    raise ConnectionError(f"CloudWatch log group not found: {self.log_groups}")
                logger.info(f"✅ CloudWatch connection validated (log group: {self.log_groups})")
            
            return True
            
        except NoCredentialsError:
            raise ConnectionError("AWS credentials not found. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY or configure AWS CLI.")
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'AccessDeniedException':
                raise ConnectionError("AWS access denied. Check IAM permissions for CloudWatch Logs.")
            elif error_code == 'ResourceNotFoundException':
                raise ConnectionError(f"CloudWatch resource not found: {self.log_groups}")
            else:
                raise ConnectionError(f"CloudWatch API error: {error_code} - {e.response['Error']['Message']}")
        except Exception as e:
            raise ConnectionError(f"CloudWatch connection validation failed: {e}")
    
    def fetch_errors_since(self, since_timestamp: str) -> List[UnifiedError]:
        """
        Fetch CloudWatch error logs since a given timestamp.
        
        Args:
            since_timestamp: ISO 8601 timestamp (YYYY-MM-DDTHH:MM:SSZ)
            
        Returns:
            List[UnifiedError]: List of errors in unified format
        """
        # Convert ISO timestamp to Unix timestamp in milliseconds
        last_seen_dt = datetime.fromisoformat(since_timestamp.replace('Z', '+00:00'))
        start_time = int(last_seen_dt.timestamp() * 1000)
        
        errors = []
        
        try:
            if is_query_all_log_groups():
                # Query all log groups
                errors = self._fetch_from_all_log_groups(start_time)
            elif isinstance(self.log_groups, list):
                # Query multiple specific log groups
                for log_group in self.log_groups:
                    errors.extend(self._fetch_from_log_group(log_group, start_time))
            else:
                # Query single log group
                errors = self._fetch_from_log_group(self.log_groups, start_time)
            
            logger.info(f"Fetched {len(errors)} error logs from CloudWatch since {since_timestamp}")
            return errors
            
        except Exception as e:
            logger.error(f"Failed to fetch CloudWatch logs: {e}")
            raise ConnectionError(f"CloudWatch fetch failed: {e}")
    
    def _fetch_from_all_log_groups(self, start_time: int) -> List[UnifiedError]:
        """Fetch errors from all log groups."""
        errors = []
        
        try:
            # Get all log groups
            paginator = self.client.get_paginator('describe_log_groups')
            for page in paginator.paginate():
                for log_group in page['logGroups']:
                    log_group_name = log_group['logGroupName']
                    try:
                        errors.extend(self._fetch_from_log_group(log_group_name, start_time))
                    except Exception as e:
                        logger.warning(f"Failed to fetch from log group {log_group_name}: {e}")
                        continue
        except Exception as e:
            logger.error(f"Failed to query all log groups: {e}")
            raise
        
        return errors
    
    def _fetch_from_log_group(self, log_group_name: str, start_time: int) -> List[UnifiedError]:
        """Fetch errors from a specific log group."""
        errors = []
        
        try:
            paginator = self.client.get_paginator('filter_log_events')
            page_iterator = paginator.paginate(
                logGroupName=log_group_name,
                startTime=start_time,
                filterPattern=self.filter_pattern
            )
            
            for page in page_iterator:
                for event in page.get('events', []):
                    unified_error = self._parse_log_event(event, log_group_name)
                    if unified_error:
                        errors.append(unified_error)
        except ClientError as e:
            # Log group might not exist or no permissions
            error_code = e.response['Error']['Code']
            if error_code in ['ResourceNotFoundException', 'AccessDeniedException']:
                logger.warning(f"Cannot access log group {log_group_name}: {error_code}")
            else:
                raise
        
        return errors
    
    def _parse_log_event(self, event: dict, log_group_name: str) -> Optional[UnifiedError]:
        """
        Parse a CloudWatch log event into UnifiedError format.
        
        Args:
            event: CloudWatch log event dictionary
            log_group_name: Name of the log group
            
        Returns:
            UnifiedError object or None if parsing fails
        """
        try:
            message = event.get('message', '')
            timestamp_ms = event.get('timestamp', 0)
            
            # Convert timestamp to ISO format
            timestamp_iso = datetime.fromtimestamp(timestamp_ms / 1000).isoformat() + 'Z'
            
            # Extract log stream name
            log_stream = event.get('logStreamName', '')
            
            # Extract service name from log group (e.g., /aws/lambda/my-function -> my-function)
            service_name = log_group_name.split('/')[-1] if log_group_name else 'unknown'
            
            # Detect error type and severity from message
            error_type = self._detect_error_type(message)
            severity = self._infer_severity(message)
            
            # Create unified error
            unified_error = UnifiedError(
                error_description=message,
                source_tool="CLOUDWATCH",
                title=f"{error_type} in {service_name}" if error_type else f"Error in {service_name}",
                error_type=error_type,
                timestamp=timestamp_iso,
                service_name=service_name,
                severity=severity,
                context_metadata={
                    'log_group': log_group_name,
                    'log_stream': log_stream,
                    'event_id': event.get('eventId', ''),
                }
            )
            
            return unified_error
            
        except Exception as e:
            logger.warning(f"Failed to parse CloudWatch log event: {e}")
            return None
    
    def _infer_severity(self, message: str) -> Optional[str]:
        """
        Infer severity level from CloudWatch log message.
        CloudWatch doesn't have built-in severity, so we parse from message content.
        
        Returns:
            Inferred severity level (FATAL, ERROR, CRITICAL, WARNING, INFO, DEBUG)
        """
        message_upper = message.upper()
        
        # Check for severity keywords in order of priority
        if any(keyword in message_upper for keyword in ['FATAL', 'PANIC']):
            return 'FATAL'
        elif any(keyword in message_upper for keyword in ['CRITICAL', 'CRIT']):
            return 'CRITICAL'
        elif 'ERROR' in message_upper or 'EXCEPTION' in message_upper:
            return 'ERROR'
        elif any(keyword in message_upper for keyword in ['WARN', 'WARNING']):
            return 'WARNING'
        elif 'INFO' in message_upper:
            return 'INFO'
        elif 'DEBUG' in message_upper or 'TRACE' in message_upper:
            return 'DEBUG'
        
        # If no explicit severity found but it matches error filter pattern, assume ERROR
        return 'ERROR'
    
    def _detect_error_type(self, message: str) -> Optional[str]:
        """Detect error type from log message."""
        message_lower = message.lower()
        
        # Check for common error patterns
        if 'exception' in message_lower:
            # Try to extract exception class name
            import re
            match = re.search(r'(\w+Exception|Error)', message)
            if match:
                return match.group(1)
            return 'Exception'
        elif 'error' in message_lower:
            return 'Error'
        elif 'fatal' in message_lower:
            return 'FatalError'
        elif 'critical' in message_lower:
            return 'CriticalError'
        
        return None
