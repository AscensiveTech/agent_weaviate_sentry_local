"""
Smart defaults and configuration for monitoring tools.
Provides sensible defaults that work out-of-the-box while allowing .env overrides.
"""
import os
from typing import List, Optional


class MonitoringConfig:
    """Configuration manager for monitoring tools with smart defaults."""
    
    # Default error patterns for CloudWatch log filtering
    # These cover common error keywords across multiple languages/frameworks
    DEFAULT_ERROR_KEYWORDS = [
        "ERROR",           # Standard log level (uppercase)
        "FATAL",           # Critical errors
        "CRITICAL",        # Python logging level
        "Exception",       # Java, Python, C# exceptions
        "exception",       # Lowercase variant
        "error",           # Lowercase variant
        "Error",           # Capitalized variant
        "Traceback",       # Python stack traces
        "EXCEPTION",       # Uppercase variant
    ]
    
    # Tech stack-specific error patterns
    TECH_STACK_PATTERNS = {
        "python": ["Traceback", "raise ", "AssertionError", "RuntimeError"],
        "nodejs": ["UnhandledPromiseRejection", "UnhandledRejection", "throw new Error"],
        "javascript": ["UnhandledPromiseRejection", "throw new Error", "TypeError"],
        "java": ["Exception in thread", "java.lang.Exception", "Stack trace"],
        "dotnet": ["System.Exception", "Unhandled exception", "Stack Trace"],
        "go": ["panic:", "fatal error:", "runtime error"],
        "ruby": ["RuntimeError", "raise ", "backtrace"],
        "php": ["Fatal error", "Parse error", "Exception", "Stack trace"],
    }
    
    @staticmethod
    def get_cloudwatch_filter_pattern(tech_stack: Optional[dict] = None) -> str:
        """
        Get CloudWatch filter pattern with smart defaults.
        
        Priority:
        1. Use CLOUDWATCH_FILTER_PATTERN from .env if set
        2. Build pattern from tech stack if provided
        3. Use default error keywords
        
        Args:
            tech_stack: Optional dict with 'languages' and 'frameworks' keys
            
        Returns:
            CloudWatch filter pattern string (space-separated = OR logic)
        """
        # Check for explicit override in environment
        env_pattern = os.getenv("CLOUDWATCH_FILTER_PATTERN")
        if env_pattern:
            return env_pattern
        
        # Build pattern based on tech stack
        patterns = set(MonitoringConfig.DEFAULT_ERROR_KEYWORDS)
        
        if tech_stack:
            # Extract language-specific patterns
            languages = tech_stack.get("languages", [])
            frameworks = tech_stack.get("frameworks", [])
            
            # Add patterns for detected languages
            for lang in languages:
                lang_lower = str(lang).lower()
                for tech_key, tech_patterns in MonitoringConfig.TECH_STACK_PATTERNS.items():
                    if tech_key in lang_lower:
                        patterns.update(tech_patterns)
            
            # Add patterns for detected frameworks
            for framework in frameworks:
                framework_lower = str(framework).lower()
                # Django/Flask = Python
                if any(fw in framework_lower for fw in ["django", "flask", "fastapi"]):
                    patterns.update(MonitoringConfig.TECH_STACK_PATTERNS["python"])
                # Express/Next = Node.js
                elif any(fw in framework_lower for fw in ["express", "next", "nest"]):
                    patterns.update(MonitoringConfig.TECH_STACK_PATTERNS["nodejs"])
                # Spring = Java
                elif "spring" in framework_lower:
                    patterns.update(MonitoringConfig.TECH_STACK_PATTERNS["java"])
        
        # Convert to CloudWatch filter pattern (space-separated = OR)
        # CloudWatch treats multiple terms separated by spaces as OR
        return " ".join(sorted(patterns))
    
    @staticmethod
    def get_severity_filter() -> List[str]:
        """
        Get list of severity levels to filter for.
        
        Returns:
            List of severity strings to include
        """
        # Check for override
        env_severities = os.getenv("ERROR_SEVERITY_FILTER")
        if env_severities:
            return [s.strip() for s in env_severities.split(",")]
        
        # Default: Only actual errors (exclude INFO, DEBUG, TRACE, WARN)
        return ["ERROR", "FATAL", "CRITICAL", "EXCEPTION"]
    
    @staticmethod
    def get_log_lookback_minutes() -> int:
        """
        Get how many minutes to look back for logs.
        
        Returns:
            Number of minutes to look back (default: 60)
        """
        env_lookback = os.getenv("LOG_LOOKBACK_MINUTES")
        if env_lookback:
            try:
                return int(env_lookback)
            except ValueError:
                pass
        return 60  # Default: 1 hour
    
    @staticmethod
    def get_max_logs_per_fetch() -> int:
        """
        Get maximum number of logs to fetch per request.
        
        Returns:
            Maximum logs to fetch (default: 100)
        """
        env_max = os.getenv("MAX_LOGS_PER_FETCH")
        if env_max:
            try:
                return int(env_max)
            except ValueError:
                pass
        return 100  # Default: 100 logs
    
    @staticmethod
    def should_deduplicate_logs() -> bool:
        """
        Check if logs should be deduplicated before processing.
        
        Returns:
            True if deduplication enabled (default: True)
        """
        env_dedupe = os.getenv("DEDUPLICATE_LOGS", "true").lower()
        return env_dedupe in ("true", "1", "yes", "enabled")
    
    @staticmethod
    def get_config_summary(tech_stack: Optional[dict] = None) -> str:
        """
        Get human-readable summary of current configuration.
        
        Args:
            tech_stack: Optional tech stack dict
            
        Returns:
            Multi-line string with config summary
        """
        filter_pattern = MonitoringConfig.get_cloudwatch_filter_pattern(tech_stack)
        
        lines = [
            "📋 Monitoring Configuration:",
            f"  - CloudWatch Filter: {filter_pattern[:100]}{'...' if len(filter_pattern) > 100 else ''}",
            f"  - Severity Filter: {', '.join(MonitoringConfig.get_severity_filter())}",
            f"  - Lookback Period: {MonitoringConfig.get_log_lookback_minutes()} minutes",
            f"  - Max Logs/Fetch: {MonitoringConfig.get_max_logs_per_fetch()}",
            f"  - Deduplication: {'Enabled' if MonitoringConfig.should_deduplicate_logs() else 'Disabled'}",
        ]
        
        log_groups = MonitoringConfig.get_cloudwatch_log_groups()
        if log_groups == "ALL":
            lines.append(f"  - Log Groups: ALL (queries all log groups)")
        elif isinstance(log_groups, list):
            lines.append(f"  - Log Groups: {len(log_groups)} groups")
        else:
            lines.append(f"  - Log Groups: {log_groups}")
        
        if tech_stack:
            lines.append(f"  - Tech Stack: {tech_stack.get('languages', [])} + {tech_stack.get('frameworks', [])}")
        
        return "\n".join(lines)
    
    @staticmethod
    def get_cloudwatch_log_groups() -> any:
        """
        Get CloudWatch log group(s) to query.
        
        Returns:
            - "ALL" to query all log groups
            - "/aws/lambda/*" for wildcard pattern
            - List of log group names for multiple groups
            - Single log group name string
        """
        env_log_group = os.getenv("CLOUDWATCH_LOG_GROUP", "")
        
        if not env_log_group:
            raise ValueError("CLOUDWATCH_LOG_GROUP not set in .env file")
        
        # Handle "ALL" - query all log groups
        if env_log_group.upper() == "ALL":
            return "ALL"
        
        # Handle comma-separated list
        if "," in env_log_group:
            return [lg.strip() for lg in env_log_group.split(",")]
        
        # Single log group or pattern
        return env_log_group
    
    @staticmethod
    def is_query_all_log_groups() -> bool:
        """Check if configuration is set to query ALL log groups."""
        try:
            log_groups = MonitoringConfig.get_cloudwatch_log_groups()
            return log_groups == "ALL"
        except:
            return False


# Convenience functions for direct import
def get_cloudwatch_filter_pattern(tech_stack: Optional[dict] = None) -> str:
    """Get CloudWatch filter pattern with smart defaults."""
    return MonitoringConfig.get_cloudwatch_filter_pattern(tech_stack)


def get_severity_filter() -> List[str]:
    """Get severity levels to filter for."""
    return MonitoringConfig.get_severity_filter()


def get_config_summary(tech_stack: Optional[dict] = None) -> str:
    """Get human-readable config summary."""
    return MonitoringConfig.get_config_summary(tech_stack)


def get_cloudwatch_log_groups() -> any:
    """Get CloudWatch log groups to query (ALL, list, or single group)."""
    return MonitoringConfig.get_cloudwatch_log_groups()


def is_query_all_log_groups() -> bool:
    """Check if set to query ALL log groups."""
    return MonitoringConfig.is_query_all_log_groups()


if __name__ == "__main__":
    # Test the configuration
    print("=" * 70)
    print("MONITORING CONFIGURATION TEST")
    print("=" * 70)
    
    # Test 1: Default configuration
    print("\n1. Default Configuration (no tech stack):")
    print(get_config_summary())
    print(f"\nFilter Pattern: {get_cloudwatch_filter_pattern()}")
    
    # Test 2: Python/Flask tech stack
    print("\n" + "=" * 70)
    print("2. Python/Flask Tech Stack:")
    python_stack = {
        "languages": ["Python 3.11"],
        "frameworks": ["Flask", "SQLAlchemy"],
        "host": "AWS Lambda",
        "database": "PostgreSQL"
    }
    print(get_config_summary(python_stack))
    print(f"\nFilter Pattern: {get_cloudwatch_filter_pattern(python_stack)}")
    
    # Test 3: Node.js/Express tech stack
    print("\n" + "=" * 70)
    print("3. Node.js/Express Tech Stack:")
    nodejs_stack = {
        "languages": ["JavaScript ES6", "TypeScript"],
        "frameworks": ["Express", "React"],
        "host": "Docker",
        "database": "MongoDB"
    }
    print(get_config_summary(nodejs_stack))
    print(f"\nFilter Pattern: {get_cloudwatch_filter_pattern(nodejs_stack)}")
    
    # Test 4: With .env override
    print("\n" + "=" * 70)
    print("4. With Environment Override:")
    print("Set CLOUDWATCH_FILTER_PATTERN in .env to test override")
    
    print("\n" + "=" * 70)
