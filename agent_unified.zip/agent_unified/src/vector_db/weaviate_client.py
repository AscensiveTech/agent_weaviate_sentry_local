"""Weaviate client and vector database operations."""
import atexit
import os
import logging
import requests
from typing import Optional, List
from urllib.parse import urlparse
from weaviate.connect import ConnectionParams, ProtocolParams
from weaviate.auth import AuthApiKey
from weaviate import WeaviateClient
from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv

# FastAPI imports for API endpoints
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

load_dotenv()

# Weaviate Configuration
WEAVIATE_URL = os.getenv("WEAVIATE_URL")
WEAVIATE_GRPC = os.getenv("WEAVIATE_GRPC")
WEAVIATE_API_KEY = os.getenv("WEAVIATE_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# ============================================================================
# API ROUTER - Vector Database Endpoints
# ============================================================================

router = APIRouter(prefix="/vector-db", tags=["Vector Database"])


class SearchRequest(BaseModel):
    """Request model for similarity search"""
    query: str = Field(..., description="Search query text")
    threshold: float = Field(0.9, ge=0.0, le=1.0, description="Similarity threshold (0.0-1.0)")


class SearchResponse(BaseModel):
    """Response model for similarity search"""
    found: bool
    solution_recommendation: Optional[str] = None
    solution_steps: Optional[List[str]] = None
    resolved: Optional[bool] = None
    certainty: Optional[float] = None


class VectorDBHealthResponse(BaseModel):
    """Response model for Weaviate health check"""
    connected: bool
    message: str
    schema_exists: bool = False

_weaviate_client: Optional[WeaviateClient] = None
_embedder: Optional[OpenAIEmbeddings] = None


def _close_weaviate_client() -> None:
    """Close the cached Weaviate client when the process exits."""
    global _weaviate_client
    if _weaviate_client is None:
        return
    try:
        _weaviate_client.close()
        logging.debug("Closed Weaviate client connection.")
    except Exception as exc:
        logging.debug(f"Unable to close Weaviate client gracefully: {exc}")
    finally:
        _weaviate_client = None


atexit.register(_close_weaviate_client)


def _build_protocol_params(url: Optional[str], default_scheme: str) -> Optional[ProtocolParams]:
    """Construct ProtocolParams from a URL string expected in environment variables."""
    if not url:
        return None
    raw = url.strip()
    if "://" not in raw:
        raw = f"{default_scheme}://{raw}"
    parsed = urlparse(raw)
    if not parsed.hostname:
        raise ValueError(f"Invalid Weaviate URL: {url}")

    scheme = (parsed.scheme or default_scheme).lower()
    if scheme not in ("http", "https", "grpc", "grpcs"):
        raise ValueError(f"Unsupported scheme for Weaviate URL: {url}")

    secure = scheme in ("https", "grpcs")
    default_port = 443 if secure else 80
    port = parsed.port or default_port

    return ProtocolParams(host=parsed.hostname, port=port, secure=secure)


def _weaviate_base_url() -> Optional[str]:
    if not WEAVIATE_URL:
        return None
    url = WEAVIATE_URL.rstrip("/")
    # Ensure URL has a scheme
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url


def _rest_headers() -> dict:
    headers = {"Content-Type": "application/json"}
    if WEAVIATE_API_KEY:
        headers["Authorization"] = f"Bearer {WEAVIATE_API_KEY}"
    return headers


def get_embedder() -> Optional[OpenAIEmbeddings]:
    """Return a cached embeddings client for manual vector generation."""
    global _embedder
    if _embedder is not None:
        return _embedder
    if not OPENAI_API_KEY:
        logging.warning("OPENAI_API_KEY missing; embedding-based Weaviate features disabled.")
        return None
    try:
        _embedder = OpenAIEmbeddings(
            model="text-embedding-3-small",
            openai_api_key=OPENAI_API_KEY,
        )
    except Exception as exc:
        logging.warning(f"Failed to initialize OpenAI embeddings: {exc}")
        _embedder = None
    return _embedder


def embed_text(text: str) -> Optional[List[float]]:
    """Generate vector embeddings for text using OpenAI's text-embedding-3-small model.
    
    Args:
        text: The text to embed (will be stripped of extra whitespace)
        
    Returns:
        List of floats representing the embedding vector, or None if embedding fails
    """
    if not text or not text.strip():
        logging.warning("Cannot embed empty text")
        return None
    
    embedder = get_embedder()
    if not embedder:
        return None
    
    try:
        # Normalize whitespace for consistent embeddings
        normalized_text = " ".join(text.split())
        return embedder.embed_query(normalized_text)
    except Exception as exc:
        logging.warning(f"Embedding generation failed for text (length {len(text)}): {exc}")
        return None


def _fetch_class_schema(class_name: str) -> Optional[dict]:
    """Retrieve schema via REST API."""
    base = _weaviate_base_url()
    if not base:
        return None
    try:
        resp = requests.get(f"{base}/v1/schema/{class_name}", headers=_rest_headers(), timeout=10)
    except Exception as exc:
        logging.warning(f"Failed to fetch Weaviate schema for {class_name}: {exc}")
        return None
    if resp.status_code == 404:
        return None
    if resp.status_code != 200:
        logging.warning(
            "Unexpected status when fetching schema (%s): %s",
            resp.status_code,
            resp.text,
        )
        return None
    try:
        return resp.json()
    except Exception as exc:
        logging.warning(f"Invalid schema response for {class_name}: {exc}")
        return None


def _delete_class_schema(class_name: str) -> bool:
    """Delete existing schema."""
    base = _weaviate_base_url()
    if not base:
        return False
    try:
        resp = requests.delete(f"{base}/v1/schema/{class_name}", headers=_rest_headers(), timeout=10)
        if resp.status_code in (200, 202, 204):
            logging.info("Deleted existing Weaviate class '%s'.", class_name)
            return True
        logging.warning(
            "Failed to delete Weaviate class '%s' (status %s): %s",
            class_name,
            resp.status_code,
            resp.text,
        )
    except Exception as exc:
        logging.warning(f"Error deleting Weaviate class '{class_name}': {exc}")
    return False


def _create_debugging_solution_schema(client: WeaviateClient) -> bool:
    """Create the DebuggingSolution container if it does not exist."""
    schema_definition = {
        "class": "DebuggingSolution",
        "description": "Stores normalized, deduplicated error debugging solutions from multiple monitoring tools",
        "vectorizer": "none",
        "moduleConfig": {},
        "properties": [
            # Existing fields
            {"name": "project", "dataType": ["text"]},
            {"name": "title", "dataType": ["text"]},
            {"name": "error_code", "dataType": ["text"]},
            {"name": "error_description", "dataType": ["text"]},
            {"name": "last_seen", "dataType": ["text"]},
            {"name": "environment", "dataType": ["text"]},
            {"name": "release", "dataType": ["text"]},
            {"name": "culprit", "dataType": ["text"]},
            {"name": "stacktrace_files", "dataType": ["text[]"]},
            {"name": "solution_recommendation", "dataType": ["text"]},
            {"name": "solution_steps", "dataType": ["text[]"]},
            {"name": "resolved", "dataType": ["boolean"]},
            
            # Normalization fields
            {
                "name": "source_tool",
                "dataType": ["text"],
                "indexFilterable": True,
                "description": "CLOUDWATCH | SENTRY | DATADOG | LOKI | NEWRELIC"
            },
            {
                "name": "severity",
                "dataType": ["text"],
                "indexFilterable": True,
                "description": "Raw severity from tool"
            },
            {
                "name": "context_metadata",
                "dataType": ["text"],
                "description": "JSON string with tool-specific data"
            },
            
            # Deduplication fields
            {
                "name": "error_fingerprint",
                "dataType": ["text"],
                "tokenization": "word",
                "indexFilterable": True,
                "indexSearchable": True,
                "description": "Hash for deduplication"
            },
            {
                "name": "occurrence_count",
                "dataType": ["int"],
                "indexFilterable": True,
                "description": "Number of times error occurred"
            },
            {
                "name": "first_seen",
                "dataType": ["text"],
                "description": "First occurrence timestamp"
            },
            
            # User feedback fields
            {
                "name": "rating",
                "dataType": ["int"],
                "indexFilterable": True,
                "description": "Binary rating: 0 (false/not solved) | 1 (true/solved)"
            },
            {
                "name": "feedback",
                "dataType": ["text"],
                "description": "User feedback/comments on solution"
            },
            
            # AI confidence field
            {
                "name": "confidence_level",
                "dataType": ["number"],
                "indexFilterable": True,
                "description": "LLM confidence level (0.0-1.0)"
            },
            
            # Tech stack fields
            {
                "name": "tech_stack",
                "dataType": ["text"],
                "description": "JSON string with technology stack info (languages, frameworks, host, database, etc.)"
            },
        ],
    }

    try:
        if hasattr(client, "schema") and client.schema is not None:
            create_class = getattr(client.schema, "create_class", None)
            if callable(create_class):
                create_class(schema_definition)
            else:
                client.schema.create(schema_definition)
            logging.info("Created 'DebuggingSolution' class in Weaviate schema.")
            return True

        base_url = _weaviate_base_url()
        if not base_url:
            logging.warning("Cannot create schema without WEAVIATE_URL.")
            return False

        headers = {"Content-Type": "application/json"}
        if WEAVIATE_API_KEY:
            headers["Authorization"] = f"Bearer {WEAVIATE_API_KEY}"

        response = requests.post(
            f"{base_url}/v1/schema",
            headers=headers,
            json=schema_definition,
            timeout=15,
        )
        if response.status_code in (200, 201):
            logging.info("Created 'DebuggingSolution' schema via REST API.")
            return True
        logging.warning(
            "Weaviate schema creation failed (%s): %s",
            response.status_code,
            response.text,
        )
    except Exception as exc:
        logging.warning(f"Failed to create DebuggingSolution schema: {exc}")
    return False


def get_weaviate_client() -> Optional[WeaviateClient]:
    """Return a cached Weaviate client; initialize lazily if needed.
    
    Returns:
        WeaviateClient instance if connection successful, None otherwise
        
    Note:
        Client is cached globally and reused across calls. Connection health
        is validated before returning cached client.
    """
    global _weaviate_client
    
    # Check if cached client is still healthy
    if _weaviate_client is not None:
        try:
            if _weaviate_client.is_ready():
                return _weaviate_client
            else:
                logging.warning("Cached Weaviate client is no longer ready, reconnecting...")
                _weaviate_client = None
        except Exception as exc:
            logging.warning(f"Health check failed on cached client: {exc}")
            _weaviate_client = None

    if not WEAVIATE_URL:
        logging.warning("WEAVIATE_URL not set; skipping Weaviate initialization.")
        return None

    try:
        # Build connection parameters with validation
        http_params = _build_protocol_params(WEAVIATE_URL, default_scheme="https")
        grpc_params = _build_protocol_params(WEAVIATE_GRPC, default_scheme="grpcs")
        
        if not http_params:
            logging.warning("Failed to parse WEAVIATE_URL, cannot connect")
            return None
        
        connection_params = ConnectionParams(http=http_params, grpc=grpc_params)

        # Initialize client with or without authentication
        auth = AuthApiKey(WEAVIATE_API_KEY) if WEAVIATE_API_KEY else None
        if auth:
            _weaviate_client = WeaviateClient(
                connection_params=connection_params,
                auth_client_secret=auth,
            )
            logging.debug("Weaviate client initialized with API key authentication")
        else:
            _weaviate_client = WeaviateClient(connection_params=connection_params)
            logging.debug("Weaviate client initialized without authentication")

        # Connect and verify readiness
        _weaviate_client.connect()
        if not _weaviate_client.is_ready():
            logging.warning("Weaviate client not ready after connect().")
            _weaviate_client.close()
            _weaviate_client = None
            return None

        logging.info("✅ Connected to Weaviate!")
        return _weaviate_client
        
    except ValueError as ve:
        logging.warning(f"Invalid Weaviate configuration: {ve}")
        _weaviate_client = None
        return None
    except Exception as exc:
        logging.warning(f"Failed to initialize Weaviate client: {type(exc).__name__}: {exc}")
        _weaviate_client = None
        return None


def ensure_debugging_solution_schema(client: WeaviateClient) -> bool:
    """Check whether the DebuggingSolution class exists in Weaviate."""
    try:
        if hasattr(client, "schema") and client.schema is not None:
            schema = client.schema.get()
            classes = schema.get("classes", []) if isinstance(schema, dict) else []
            if any(cls.get("class") == "DebuggingSolution" for cls in classes):
                return True
            logging.warning("Weaviate class 'DebuggingSolution' not found in schema. Attempting to create it.")
            return _create_debugging_solution_schema(client)

        class_info = _fetch_class_schema("DebuggingSolution")
        if class_info:
            vectorizer = (class_info.get("vectorizer") or "").lower()
            if vectorizer not in ("", "none"):
                logging.warning(
                    "Existing 'DebuggingSolution' class uses vectorizer '%s'. Recreating with 'none'.",
                    vectorizer,
                )
                if _delete_class_schema("DebuggingSolution"):
                    return _create_debugging_solution_schema(client)
                return False
            return True

        logging.warning("Weaviate schema 'DebuggingSolution' not found. Attempting to create it.")
        return _create_debugging_solution_schema(client)
    except Exception as exc:
        logging.warning(f"Error checking Weaviate schema: {exc}")
        return False


def fetch_similar_solution(error_description: str, certainty_threshold: float = 0.9) -> Optional[dict]:
    """Vector similarity search for similar errors in Weaviate database.
    
    Args:
        error_description: The error description to search for
        certainty_threshold: Minimum certainty score (0.0-1.0) for accepting results (default: 0.9)
        
    Returns:
        Dictionary with solution_recommendation, solution_steps, and resolved fields,
        or None if no similar solution found or error occurs
    """
    if not error_description or not error_description.strip():
        logging.warning("Cannot search with empty error description")
        return None
    
    logging.info(f"Searching for similar error: '{error_description[:100]}...'")
    
    # Generate embedding vector
    vector = embed_text(error_description)
    if vector is None:
        logging.warning("Skipping Weaviate lookup; embeddings unavailable.")
        return None

    # Get Weaviate client
    client = get_weaviate_client()
    if not client:
        logging.warning("Weaviate client not available; cannot query for similar solutions.")
        return None

    try:
        collection = client.collections.get("DebuggingSolution")
        
        # Query for similar vectors
        response = collection.query.near_vector(
            near_vector=vector,
            limit=1,
            return_metadata=['distance', 'certainty']
        )
        
        if not response.objects:
            logging.info("No solutions found in Weaviate database. Database may be empty.")
            return None
        
        # Extract metadata
        obj = response.objects[0]
        certainty = obj.metadata.certainty if obj.metadata.certainty else 0.0
        distance = obj.metadata.distance if obj.metadata.distance else 1.0
        
        # Check certainty threshold
        if certainty < certainty_threshold:
            logging.info(
                f"Found solution but similarity too low "
                f"(certainty: {certainty:.3f}, threshold: {certainty_threshold})"
            )
            return None
        
        logging.info(f"✅ Found similar solution (certainty: {certainty:.3f}, distance: {distance:.3f})")
        
        # Extract and validate properties
        properties = obj.properties
        solution_recommendation = properties.get("solution_recommendation")
        solution_steps = properties.get("solution_steps", [])
        resolved = properties.get("resolved", False)
        
        if not solution_recommendation:
            logging.warning("Found solution has no recommendation text")
            return None
        
        return {
            "solution_recommendation": solution_recommendation,
            "solution_steps": solution_steps if isinstance(solution_steps, list) else [],
            "resolved": bool(resolved),
        }
        
    except AttributeError as ae:
        logging.warning(f"Weaviate API structure mismatch: {ae}")
        return None
    except Exception as exc:
        logging.warning(f"Error querying Weaviate: {type(exc).__name__}: {exc}")
        return None


def fetch_similar_solutions_multi(
    error_description: str,
    limit: int = 5,
    min_threshold: float = 0.7,
    include_metadata: bool = True
) -> List[dict]:
    """Enhanced vector similarity search returning multiple similar errors with rankings.
    
    Args:
        error_description: The error description to search for
        limit: Maximum number of results to return (default: 5)
        min_threshold: Minimum certainty score (0.0-1.0) for including results (default: 0.7)
        include_metadata: Include rating, feedback, confidence_level, tech_stack (default: True)
        
    Returns:
        List of dictionaries with solution data, sorted by certainty score (highest first).
        Each dict contains:
            - solution_recommendation: Solution text
            - solution_steps: List of troubleshooting steps
            - resolved: Boolean flag
            - certainty: Similarity score (0.0-1.0)
            - distance: Vector distance
            - rating: User rating (0=no rating, 1=solved) if include_metadata=True
            - feedback: User feedback text if include_metadata=True
            - confidence_level: LLM confidence if include_metadata=True
            - tech_stack: Tech stack JSON if include_metadata=True
    """
    if not error_description or not error_description.strip():
        logging.warning("Cannot search with empty error description")
        return []
    
    logging.info(f"Searching for {limit} similar errors (threshold: {min_threshold}): '{error_description[:100]}...'")
    
    # Generate embedding vector
    vector = embed_text(error_description)
    if vector is None:
        logging.warning("Skipping Weaviate lookup; embeddings unavailable.")
        return []

    # Get Weaviate client
    client = get_weaviate_client()
    if not client:
        logging.warning("Weaviate client not available; cannot query for similar solutions.")
        return []

    try:
        collection = client.collections.get("DebuggingSolution")
        
        # Query for similar vectors
        response = collection.query.near_vector(
            near_vector=vector,
            limit=limit,
            return_metadata=['distance', 'certainty']
        )
        
        if not response.objects:
            logging.info("No solutions found in Weaviate database.")
            return []
        
        # Extract and filter results
        results = []
        for obj in response.objects:
            certainty = obj.metadata.certainty if obj.metadata.certainty else 0.0
            distance = obj.metadata.distance if obj.metadata.distance else 1.0
            
            # Apply threshold filter
            if certainty < min_threshold:
                continue
            
            properties = obj.properties
            solution_recommendation = properties.get("solution_recommendation")
            
            if not solution_recommendation:
                continue
            
            result = {
                "solution_recommendation": solution_recommendation,
                "solution_steps": properties.get("solution_steps", []),
                "resolved": bool(properties.get("resolved", False)),
                "certainty": certainty,
                "distance": distance,
            }
            
            # Add metadata if requested
            if include_metadata:
                result["rating"] = int(properties.get("rating", 0))
                result["feedback"] = str(properties.get("feedback", ""))
                result["confidence_level"] = float(properties.get("confidence_level", 0.0))
                result["tech_stack"] = str(properties.get("tech_stack", "{}"))
                result["error_code"] = str(properties.get("error_code", ""))
                result["project"] = str(properties.get("project", ""))
                result["environment"] = str(properties.get("environment", ""))
            
            results.append(result)
        
        logging.info(f"✅ Found {len(results)} similar solutions (threshold >= {min_threshold})")
        return results
        
    except AttributeError as ae:
        logging.warning(f"Weaviate API structure mismatch: {ae}")
        return []
    except Exception as exc:
        logging.warning(f"Error querying Weaviate: {type(exc).__name__}: {exc}")
        return []


def rank_solutions_by_feedback(solutions: List[dict]) -> List[dict]:
    """Rank solutions by combining similarity certainty and user feedback rating.
    
    Args:
        solutions: List of solution dicts from fetch_similar_solutions_multi()
        
    Returns:
        Re-ranked list of solutions with 'rank_score' added to each dict.
        Ranking formula: (certainty * 0.6) + (rating * 0.4)
        Solutions with rating=0 (not solved) are penalized.
    """
    if not solutions:
        return []
    
    for solution in solutions:
        certainty = solution.get("certainty", 0.0)
        rating = solution.get("rating", 0)  # 0 or 1
        confidence_level = solution.get("confidence_level", 0.0)
        
        # Calculate weighted score
        # Certainty: 60% weight
        # User rating: 30% weight  
        # LLM confidence: 10% weight
        rank_score = (certainty * 0.6) + (rating * 0.3) + (confidence_level * 0.1)
        
        solution["rank_score"] = rank_score
    
    # Sort by rank_score descending
    ranked = sorted(solutions, key=lambda x: x.get("rank_score", 0.0), reverse=True)
    
    logging.info(f"Ranked {len(ranked)} solutions by feedback. Top score: {ranked[0]['rank_score']:.3f}")
    return ranked


def store_solution_in_db(error_input, solution, is_resolved: bool = False) -> bool:
    """Stores the final error input and solution in Weaviate database.
    
    Args:
        error_input: ErrorInput object containing error details
        solution: Solution object with recommendation and troubleshooting steps
        is_resolved: Whether the issue was successfully resolved (default: False)
        
    Returns:
        True if storage successful, False otherwise
    """
    # Validate inputs
    if not error_input or not solution:
        logging.warning("Cannot store solution: missing error_input or solution")
        return False
    
    if not hasattr(error_input, 'error_description') or not error_input.error_description:
        logging.warning("Cannot store solution: error_input missing error_description")
        return False
    
    if not hasattr(solution, 'recommendation') or not solution.recommendation:
        logging.warning("Cannot store solution: solution missing recommendation")
        return False
    
    # Get Weaviate client
    client = get_weaviate_client()
    if not client:
        logging.warning("Weaviate not initialized. Skipping solution storage.")
        return False
    
    # Ensure schema exists
    if not ensure_debugging_solution_schema(client):
        logging.warning("DebuggingSolution schema missing. Skipping storage.")
        return False
    
    logging.info("\n--- STORING SOLUTION IN VECTOR DB ---")
    logging.info(f"Storing solution for: '{error_input.error_description[:100]}...'")
    
    # Generate embedding vector
    vector = embed_text(error_input.error_description)
    if vector is None:
        logging.warning("Skipping storage; embeddings unavailable.")
        return False
    
    # Build properties dictionary with validation
    properties = {
        # Existing fields
        "project": str(error_input.project or ""),
        "title": str(error_input.title or ""),
        "error_code": str(error_input.error_code or ""),
        "error_description": str(error_input.error_description),
        "last_seen": str(error_input.last_seen),
        "environment": str(error_input.environment or ""),
        "release": str(error_input.release or ""),
        "culprit": str(error_input.culprit or ""),
        "stacktrace_files": list(error_input.stacktrace_files or []),
        "solution_recommendation": str(solution.recommendation),
        "solution_steps": list(solution.troubleshooting_steps) if hasattr(solution, 'troubleshooting_steps') else [],
        "resolved": bool(is_resolved),
        
        # Normalization fields
        "source_tool": str(error_input.source_tool),
        "severity": str(error_input.severity or ""),
        "context_metadata": str(error_input.context_metadata) if error_input.context_metadata else "{}",
        
        # Deduplication fields
        "error_fingerprint": str(error_input.error_fingerprint),
        "occurrence_count": int(error_input.occurrence_count or 1),
        "first_seen": str(error_input.first_seen or error_input.last_seen),
        
        # User feedback fields
        "rating": int(bool(getattr(error_input, 'rating', False))),
        "feedback": str(getattr(error_input, 'feedback', "")),
        
        # AI confidence and tech stack fields
        "confidence_level": float(getattr(solution, 'confidence_level', 0.0)),
        "tech_stack": str(getattr(error_input, 'tech_stack', "{}")) if getattr(error_input, 'tech_stack', None) else "{}",
    }
    
    # Try primary storage methods
    try:
        if hasattr(client, "data_object") and client.data_object is not None:
            client.data_object.create(properties, class_name="DebuggingSolution", vector=vector)
            logging.info("--- ✅ SUCCESSFULLY STORED IN DB (via data_object) ---")
            return True
        elif hasattr(client, "collections"):
            try:
                collection = client.collections.get("DebuggingSolution")
                collection.data.insert(properties, vector=vector)
                logging.info("--- ✅ SUCCESSFULLY STORED IN DB (via collections) ---")
                return True
            except Exception as exc:
                logging.warning(f"Collection insert failed, attempting REST fallback: {exc}")
                raise
        else:
            raise AttributeError("Weaviate client lacks write APIs")
            
    except Exception as exc:
        logging.warning(f"Primary storage method failed: {type(exc).__name__}: {exc}")
        
        # Fall back to REST API
        base_url = _weaviate_base_url()
        if not base_url:
            logging.warning(f"Failed to store solution in Weaviate: no fallback URL available")
            return False
        
        headers = {"Content-Type": "application/json"}
        if WEAVIATE_API_KEY:
            headers["Authorization"] = f"Bearer {WEAVIATE_API_KEY}"
        
        payload = {
            "class": "DebuggingSolution",
            "properties": properties,
            "vector": vector
        }
        
        try:
            resp = requests.post(
                f"{base_url}/v1/objects",
                headers=headers,
                json=payload,
                timeout=15
            )
            
            if resp.status_code in (200, 201):
                logging.info("--- ✅ STORED IN DB VIA REST FALLBACK ---")
                return True
            else:
                logging.warning(
                    "Failed to store solution via REST (status %s): %s",
                    resp.status_code,
                    resp.text[:200]
                )
                return False
                
        except requests.Timeout:
            logging.warning("REST API storage timed out")
            return False
        except Exception as rest_exc:
            logging.warning(f"Failed to store solution via REST: {type(rest_exc).__name__}: {rest_exc}")
            return False


# ============================================================================
# API ENDPOINTS - Vector Database Operations
# ============================================================================

@router.post("/search", response_model=SearchResponse)
async def search_similar_endpoint(request: SearchRequest):
    """
    Search for similar solutions in vector database using semantic similarity
    """
    try:
        result = fetch_similar_solution(
            error_description=request.query,
            certainty_threshold=request.threshold
        )
        
        if result:
            return SearchResponse(
                found=True,
                solution_recommendation=result.get("solution_recommendation"),
                solution_steps=result.get("solution_steps"),
                resolved=result.get("resolved"),
                certainty=0.9  # Note: actual certainty from metadata if available
            )
        else:
            return SearchResponse(found=False)
            
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Search failed: {str(e)}"
        )


@router.get("/health", response_model=VectorDBHealthResponse)
async def weaviate_health():
    """
    Check Weaviate connection and schema status
    """
    try:
        client = get_weaviate_client()
        if not client:
            return VectorDBHealthResponse(
                connected=False,
                message="Weaviate client not initialized",
                schema_exists=False
            )
        
        # Check if ready
        if not client.is_ready():
            return VectorDBHealthResponse(
                connected=False,
                message="Weaviate not ready",
                schema_exists=False
            )
        
        # Check schema
        schema_exists = ensure_debugging_solution_schema(client)
        
        return VectorDBHealthResponse(
            connected=True,
            message="Weaviate operational",
            schema_exists=schema_exists
        )
        
    except Exception as e:
        return VectorDBHealthResponse(
            connected=False,
            message=f"Error: {str(e)}",
            schema_exists=False
        )
