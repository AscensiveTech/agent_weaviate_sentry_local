# Error Monitoring Agent

AI-powered error analysis and resolution system for CloudWatch and Sentry monitoring tools.

## Architecture

```
agent_unified/
├── src/                         # Source code (organized by layer)
│   ├── core/                   # Core agent logic
│   │   ├── __init__.py
│   │   └── agent.py           # DebuggingAgent, models, LangGraph
│   ├── normalization/          # Error normalization layer
│   │   ├── __init__.py
│   │   └── normalizer.py      # UnifiedError, ErrorNormalizer
│   ├── vector_db/              # Vector database layer
│   │   ├── __init__.py
│   │   ├── interface.py       # VectorDB abstraction
│   │   └── weaviate_client.py # Weaviate implementation
│   ├── monitoring/             # Monitoring tool adapters
│   │   ├── __init__.py
│   │   ├── base.py            # Interface definition
│   │   ├── factory.py         # Factory pattern
│   │   ├── config.py          # Monitoring configuration
│   │   ├── cloudwatch.py      # AWS CloudWatch adapter
│   │   └── sentry.py          # Sentry adapter
│   ├── tools/                  # Agent tools (search, context)
│   │   ├── __init__.py
│   │   ├── _shared.py
│   │   ├── fetch_monitoring_context.py
│   │   ├── search_web.py
│   │   ├── search_stackoverflow.py
│   │   ├── search_github_issues.py
│   │   └── search_developer_forums.py
│   ├── config.py               # Application configuration
│   ├── exceptions.py           # Custom exception hierarchy
│   └── state.py                # State management utilities
├── main.py                      # Application entry point (CLI + API)
├── requirements.txt             # Python dependencies
├── .env                         # Environment configuration
├── .gitignore                   # Git ignore rules
└── README.md                    # This file
```

## Quick Start

### Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure environment variables in `.env`:
```bash
# Required
MONITORING_TOOL=CLOUDWATCH  # or SENTRY
OPENAI_API_KEY=your-key

# CloudWatch (if using CloudWatch)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
CLOUDWATCH_LOG_GROUP=ALL  # or specific log group

# Sentry (if using Sentry)
SENTRY_AUTH_TOKEN=your-token
SENTRY_ORG_SLUG=your-org
SENTRY_PROJECT_SLUG=your-project

# Vector Database
WEAVIATE_URL=your-cluster.weaviate.cloud
WEAVIATE_API_KEY=your-key
```

### Usage

#### CLI Mode (One-time Processing)
```bash
# Process errors since last run
python main.py

# Process last 60 minutes
python main.py --lookback 60

# Process all history
python main.py --lookback 0
```

#### API Mode (Web Server)
```bash
# Start API server
python main.py --mode api

# Custom host/port
python main.py --mode api --host 0.0.0.0 --port 8080
```

#### API Endpoints

- `GET /` - Service information
- `GET /health` - Health check
- `POST /debug` - Debug single error manually

## Features

### Core Capabilities
- **Multi-tool Support**: CloudWatch and Sentry adapters
- **AI-Powered Analysis**: GPT-4 for solution generation
- **Vector Database**: Caching and similarity search
- **Deduplication**: Automatic error deduplication
- **Normalization**: Unified error format across tools

### Configuration
- Type-safe configuration with validation
- Environment-based configuration
- Smart defaults for monitoring tools
- Extensible via factory pattern

### Error Handling
- Custom exception hierarchy
- Graceful degradation
- Comprehensive logging
- Detailed error messages

## Development

### Code Quality
- Type hints throughout
- Professional naming conventions
- SOLID principles
- Clean architecture
- Dependency injection

### Testing
```bash
# Run CLI test
python main.py --lookback 60

# Test API
python main.py --mode api &
curl http://localhost:8000/health
```

### Adding New Monitoring Tools

1. Create adapter in `monitoring_clients/`:
```python
from monitoring_clients.base import MonitoringToolInterface
from normalizer import UnifiedError

class NewToolMonitor(MonitoringToolInterface):
    def get_tool_name(self) -> str:
        return "NEWTOOL"
    
    def validate_connection(self) -> bool:
        # Validation logic
        pass
    
    def fetch_errors_since(self, since_timestamp: str) -> List[UnifiedError]:
        # Fetch logic
        pass
```

2. Register in factory:
```python
from monitoring_clients.factory import MonitoringToolFactory
from monitoring_clients.new_tool_adapter import NewToolMonitor

MonitoringToolFactory.register_tool("NEWTOOL", NewToolMonitor)
```

3. Add configuration in `config.py`:
```python
@dataclass
class NewToolConfig:
    api_key: str = field(default_factory=lambda: os.getenv("NEWTOOL_API_KEY", ""))
```

## Dependencies

- `fastapi` - API framework
- `uvicorn` - ASGI server
- `langchain` - LLM orchestration
- `langgraph` - Agent workflow
- `weaviate-client` - Vector database
- `boto3` - AWS SDK (CloudWatch)
- `sentry-sdk` - Sentry integration

## License

Proprietary
