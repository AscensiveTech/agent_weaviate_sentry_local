"""Abstract interface for vector database operations."""
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any


class VectorDBInterface(ABC):
    """Abstract interface that any vector database must implement."""
    
    @abstractmethod
    def initialize(self) -> bool:
        """Initialize the database connection and schema."""
        pass
    
    @abstractmethod
    def search_similar(self, error_description: str, threshold: float = 0.3) -> Optional[Dict[str, Any]]:
        """
        Search for similar solutions in the database.
        
        Args:
            error_description: The error description to search for
            threshold: Minimum similarity threshold
            
        Returns:
            Dictionary with 'solution_recommendation', 'solution_steps', and 'resolved' keys,
            or None if no similar solution found
        """
        pass
    
    @abstractmethod
    def store_solution(self, error_input: Any, solution: Any, is_resolved: bool = False) -> bool:
        """
        Store a solution in the database.
        
        Args:
            error_input: ErrorInput object with error details
            solution: Solution object with recommendation and steps
            is_resolved: Whether the issue was resolved
            
        Returns:
            True if stored successfully, False otherwise
        """
        pass


class WeaviateVectorDB(VectorDBInterface):
    """Weaviate implementation of the vector database interface."""
    
    def __init__(self):
        from weaviate_client import get_weaviate_client, ensure_debugging_solution_schema
        self.get_client = get_weaviate_client
        self.ensure_schema = ensure_debugging_solution_schema
    
    def initialize(self) -> bool:
        """Initialize Weaviate connection and schema."""
        client = self.get_client()
        if not client:
            return False
        return self.ensure_schema(client)
    
    def search_similar(self, error_description: str, threshold: float = 0.3) -> Optional[Dict[str, Any]]:
        """Search for similar solutions in Weaviate."""
        from weaviate_client import fetch_similar_solution
        return fetch_similar_solution(error_description)
    
    def store_solution(self, error_input: Any, solution: Any, is_resolved: bool = False) -> bool:
        """Store solution in Weaviate."""
        from weaviate_client import store_solution_in_db
        store_solution_in_db(error_input, solution, is_resolved)
        return True
