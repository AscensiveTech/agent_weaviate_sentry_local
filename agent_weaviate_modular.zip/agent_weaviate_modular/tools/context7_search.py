"""Context7 API search tool for official documentation."""
import os
import requests
import json
from dotenv import load_dotenv
from langchain_core.tools import tool
from tools._shared import truncate

load_dotenv()
CONTEXT7_API_KEY = os.getenv("CONTEXT7_API_KEY")


@tool
def context7_search(query: str) -> str:
    """
    Searches Context7 API for official documentation matching the query.
    Requires a CONTEXT7_API_KEY environment variable.
    
    Args:
        query: The documentation search query
    
    Returns:
        Documentation content from Context7
    """
    if not CONTEXT7_API_KEY:
        return "Error: CONTEXT7_API_KEY is not set. Please configure it in your .env file."
    
    if not query or not query.strip():
        return "Error: Query cannot be empty."
    
    url = "https://context7.com/api/v1/search"
    params = {"query": query.strip()}
    headers = {
        "Authorization": f"Bearer {CONTEXT7_API_KEY}",
        "Content-Type": "application/json",
        "User-Agent": "DebuggingAgent/1.0"
    }
    
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=15)
        resp.raise_for_status()
        
        # Try to parse as JSON first
        content_type = resp.headers.get('Content-Type', '')
        if 'application/json' in content_type:
            try:
                data = resp.json()
                
                # Handle different response formats
                if isinstance(data, dict):
                    if 'error' in data:
                        return f"Context7 API error: {data.get('error', 'Unknown error')}"
                    
                    if 'results' in data:
                        results = data['results']
                        if not results:
                            return f"No documentation found for query: '{query[:50]}...'"
                        
                        # Format structured results
                        formatted = []
                        for idx, result in enumerate(results[:3], 1):
                            title = result.get('title', 'N/A')
                            content = result.get('content', result.get('text', 'N/A'))
                            source = result.get('source', result.get('url', 'N/A'))
                            
                            formatted.append(f"Documentation {idx}:\n")
                            formatted.append(f"Title: {title}\n")
                            if source != 'N/A':
                                formatted.append(f"Source: {source}\n")
                            formatted.append(f"Content:\n{content}\n")
                            formatted.append("-" * 40)
                        
                        return truncate("\n".join(formatted), max_chars=3000)
                    
                    # If data is a dict but no 'results' key, return formatted dict
                    return truncate(json.dumps(data, indent=2), max_chars=3000)
                
                elif isinstance(data, list):
                    return truncate(json.dumps(data, indent=2), max_chars=3000)
                    
            except json.JSONDecodeError:
                pass  # Fall through to text handling
        
        # Handle as plain text
        text = resp.text.strip()
        if not text:
            return f"No documentation content returned for query: '{query[:50]}...'"
        
        return truncate(text, max_chars=3000)
        
    except requests.Timeout:
        return "Error: Context7 API request timed out. Please try again."
    except requests.ConnectionError:
        return "Error: Unable to connect to Context7 API. Check your internet connection."
    except requests.HTTPError as e:
        if e.response.status_code == 401:
            return "Error: Context7 API authentication failed. Check your CONTEXT7_API_KEY."
        elif e.response.status_code == 403:
            return "Error: Access forbidden. Your Context7 API key may not have proper permissions."
        elif e.response.status_code == 404:
            return "Error: Context7 API endpoint not found. The service may have changed."
        elif e.response.status_code == 429:
            return "Error: Context7 API rate limit exceeded. Please try again later."
        return f"Error: Context7 API returned status {e.response.status_code}: {e}"
    except Exception as e:
        return f"Error fetching Context7 docs: {type(e).__name__}: {e}"
