"""General web search tool using Tavily API."""
import os
import requests
from dotenv import load_dotenv
from langchain_core.tools import tool
from tools._shared import truncate

load_dotenv()
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")


@tool
def search_web(query: str) -> str:
    """
    Performs a general web search for articles, blog posts, and other resources.
    Uses Tavily API for high-quality search results.
    
    Args:
        query: The search query string
    
    Returns:
        Formatted string with web search results (titles, URLs, and content snippets)
    """
    if not TAVILY_API_KEY:
        return "Error: Tavily API key not configured. Please set TAVILY_API_KEY in your .env file."
    
    if not query or not query.strip():
        return "Error: Query cannot be empty."
    
    payload = {
        "api_key": TAVILY_API_KEY,
        "query": query.strip(),
        "max_results": 3,
        "search_depth": "basic",
        "include_answer": False,
        "include_domains": [],
        "exclude_domains": []
    }
    
    try:
        resp = requests.post(
            "https://api.tavily.com/search",
            json=payload,
            timeout=15,
            headers={"Content-Type": "application/json"}
        )
        resp.raise_for_status()
        data = resp.json()
        
        # Check for API errors
        if "error" in data:
            return f"Tavily API error: {data.get('error', 'Unknown error')}"
        
        results = data.get('results', [])
        if not results:
            return f"No web search results found for query: '{query[:50]}...'"
        
        # Format results with more details
        result_strings = []
        result_strings.append(f"Top {len(results)} web search results:\n")
        
        for idx, item in enumerate(results, 1):
            title = item.get('title', 'N/A')
            url = item.get('url', 'N/A')
            content = item.get('content', '')
            score = item.get('score', 0)
            
            result = f"{idx}. {title}\n"
            result += f"   URL: {url}\n"
            if score:
                result += f"   Relevance: {score:.2f}\n"
            if content:
                # Clean and truncate content
                content = content.strip()[:400]
                result += f"   Snippet: {content}...\n"
            
            result_strings.append(result)
        
        return truncate("\n".join(result_strings), max_chars=2000)
        
    except requests.Timeout:
        return "Error: Tavily API request timed out. Please try again."
    except requests.ConnectionError:
        return "Error: Unable to connect to Tavily API. Check your internet connection."
    except requests.HTTPError as e:
        if e.response.status_code == 401:
            return "Error: Tavily API authentication failed. Check your TAVILY_API_KEY."
        elif e.response.status_code == 429:
            return "Error: Tavily API rate limit exceeded. Please try again later."
        return f"Error: Tavily API returned status {e.response.status_code}: {e}"
    except Exception as e:
        return f"Error querying Tavily: {type(e).__name__}: {e}"
