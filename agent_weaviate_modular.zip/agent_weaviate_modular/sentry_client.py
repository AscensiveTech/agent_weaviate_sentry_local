"""Sentry API client and utilities."""
import os
import logging
import requests
from typing import Optional, List, Dict
from dotenv import load_dotenv

# FastAPI imports for API endpoints
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

load_dotenv()

# Sentry API Configuration
SENTRY_AUTH_TOKEN = os.getenv("SENTRY_AUTH_TOKEN")
ORG_SLUG = os.getenv("SENTRY_ORG_SLUG")
PROJECT_SLUG = os.getenv("SENTRY_PROJECT_SLUG")
SENTRY_API_HEADERS = {"Authorization": f"Bearer {SENTRY_AUTH_TOKEN}"}

# ============================================================================
# API ROUTER - Sentry Integration Endpoints
# ============================================================================

router = APIRouter(prefix="/sentry", tags=["Sentry Integration"])


class SentryHealthResponse(BaseModel):
    """Response model for Sentry health check"""
    connected: bool
    message: str
    organization: Optional[str] = None
    project: Optional[str] = None


class SentryIssuesResponse(BaseModel):
    """Response model for Sentry issues"""
    count: int
    issues: List[Dict]
    since_timestamp: str


def validate_sentry_connection() -> bool:
    """Validate Sentry API connection and credentials.
    
    Returns:
        True if connection successful, False otherwise
        
    Raises:
        ValueError: If required environment variables are missing
        ConnectionError: If Sentry API is unreachable
    """
    # Check required environment variables
    if not all([SENTRY_AUTH_TOKEN, ORG_SLUG, PROJECT_SLUG]):
        missing = []
        if not SENTRY_AUTH_TOKEN:
            missing.append("SENTRY_AUTH_TOKEN")
        if not ORG_SLUG:
            missing.append("SENTRY_ORG_SLUG")
        if not PROJECT_SLUG:
            missing.append("SENTRY_PROJECT_SLUG")
        raise ValueError(f"Missing required Sentry environment variables: {', '.join(missing)}")
    
    # Test connection with a simple API call
    test_url = f"https://sentry.io/api/0/projects/{ORG_SLUG}/{PROJECT_SLUG}/"
    
    try:
        response = requests.get(test_url, headers=SENTRY_API_HEADERS, timeout=10)
        
        if response.status_code == 401:
            raise ConnectionError("Sentry authentication failed. Invalid SENTRY_AUTH_TOKEN.")
        elif response.status_code == 403:
            raise ConnectionError("Sentry access forbidden. Check token permissions.")
        elif response.status_code == 404:
            raise ConnectionError(f"Sentry project not found: {ORG_SLUG}/{PROJECT_SLUG}")
        elif response.status_code != 200:
            raise ConnectionError(f"Sentry API returned unexpected status {response.status_code}")
        
        logging.info("✅ Sentry connection validated successfully")
        return True
        
    except requests.Timeout:
        raise ConnectionError("Sentry API connection timed out. Check network connectivity.")
    except requests.ConnectionError as e:
        raise ConnectionError(f"Cannot connect to Sentry API: {e}")
    except Exception as e:
        raise ConnectionError(f"Sentry connection validation failed: {e}")


def get_sentry_issues_since(last_seen_iso: str):
    """Fetch Sentry issues since a given timestamp."""
    if not all([SENTRY_AUTH_TOKEN, ORG_SLUG, PROJECT_SLUG]):
        raise ValueError("SENTRY environment variables are not properly configured.")
    url = f"https://sentry.io/api/0/projects/{ORG_SLUG}/{PROJECT_SLUG}/issues/"
    query = f"lastSeen:>{last_seen_iso}"
    params = {"query": query}
    response = requests.get(url, headers=SENTRY_API_HEADERS, params=params)
    response.raise_for_status()
    return response.json()


def get_event_details(event_id: str):
    """Retrieve detailed event information from Sentry."""
    if not event_id:
        return None
    url = f"https://sentry.io/api/0/projects/{ORG_SLUG}/{PROJECT_SLUG}/events/{event_id}/"
    response = requests.get(url, headers=SENTRY_API_HEADERS)
    if response.status_code == 200:
        return response.json()
    return None


def extract_stacktrace_files(event: dict) -> Optional[List[str]]:
    """Parse stacktrace files from a Sentry event."""
    if not event or "exception" not in event or "values" not in event["exception"]:
        return None
    files = set()
    for exc in event["exception"]["values"]:
        if "stacktrace" in exc and "frames" in exc["stacktrace"]:
            for frame in exc["stacktrace"]["frames"]:
                if filename := frame.get("filename"):
                    files.add(filename)
    return list(files) if files else None


def extract_tag_value(tags: List[dict], key: str) -> Optional[str]:
    """Helper to extract tag values from Sentry issue tags."""
    tag = next((tag for tag in tags if tag["key"] == key), None)
    return tag["value"] if tag else None


def extract_issue_details(issue: dict) -> dict:
    """Transform Sentry issue into standardized format."""
    tags = issue.get("tags", [])
    return {
        "project": PROJECT_SLUG,
        "title": issue.get("title"),
        "error_code": issue.get("metadata", {}).get("type"),
        "error_description": issue.get("metadata", {}).get("value"),
        "occurrences": issue.get("count"),
        "last_seen": issue.get("lastSeen"),
        "environment": extract_tag_value(tags, "environment"),
        "release": extract_tag_value(tags, "release"),
        "transaction": extract_tag_value(tags, "transaction"),
        "culprit": issue.get("culprit"),
    }


# ============================================================================
# API ENDPOINTS - Sentry Operations
# ============================================================================

@router.get("/health", response_model=SentryHealthResponse)
async def sentry_health():
    """
    Check Sentry API connection and credentials
    """
    try:
        validate_sentry_connection()
        return SentryHealthResponse(
            connected=True,
            message="Sentry connection validated successfully",
            organization=ORG_SLUG,
            project=PROJECT_SLUG
        )
    except ValueError as e:
        return SentryHealthResponse(
            connected=False,
            message=str(e),
            organization=ORG_SLUG,
            project=PROJECT_SLUG
        )
    except ConnectionError as e:
        return SentryHealthResponse(
            connected=False,
            message=str(e),
            organization=ORG_SLUG,
            project=PROJECT_SLUG
        )


@router.get("/issues", response_model=SentryIssuesResponse)
async def get_issues(since_timestamp: Optional[str] = None):
    """
    Fetch Sentry issues since a specific timestamp
    """
    try:
        from utils import get_last_seen
        
        timestamp = since_timestamp or get_last_seen()
        issues = get_sentry_issues_since(timestamp)
        
        return SentryIssuesResponse(
            count=len(issues),
            issues=issues,
            since_timestamp=timestamp
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch Sentry issues: {str(e)}"
        )
