"""Pure agent logic - database and tool agnostic."""
import logging
from typing import Optional, List, Annotated, TypedDict, Callable, Dict, Any
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END, START
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from pydantic import BaseModel, Field

# FastAPI imports for API endpoints
from fastapi import APIRouter, HTTPException

# Import tools from the modular tools package
from tools import get_all_tools, get_tool

# ============================================================================
# API ROUTER - Agent Debugging Endpoints
# ============================================================================

router = APIRouter(prefix="/agent", tags=["Debugging Agent"])


class DebugRequest(BaseModel):
    """Request model for debugging an error"""
    error_message: str = Field(..., description="The error message to debug")
    stack_trace: Optional[str] = Field(None, description="Optional stack trace")
    project: str = Field("unknown", description="Project name")
    environment: Optional[str] = Field(None, description="Environment (production, development, etc.)")
    release: Optional[str] = Field(None, description="Release version")


class DebugResponse(BaseModel):
    """Response model for debugging result"""
    success: bool
    solution_recommendation: Optional[str] = None
    troubleshooting_steps: Optional[List[str]] = None
    error: Optional[str] = None
    stored_in_db: bool = False
    solution_from_db: bool = False


# --- DATA MODELS ---
class ErrorInput(BaseModel):
    """Generic error input model."""
    project: str = Field(..., description="The project slug, e.g., 'python'.")
    title: Optional[str] = Field(None, description="The human-readable title of the error.")
    error_code: Optional[str] = Field(None, description="The specific error code, e.g., '404 Not Found', 'TypeError'.")
    error_description: str = Field(..., description="A detailed description of the error message and context.")
    last_seen: str = Field(..., description="The timestamp when the error was last seen.")
    environment: Optional[str] = Field(None, description="The environment, e.g., 'production', 'development'.")
    release: Optional[str] = Field(None, description="The release version of the code.")
    culprit: Optional[str] = Field(None, description="The function or file where the error occurred.")
    stacktrace_files: Optional[List[str]] = Field(None, description="List of files from the stacktrace.")


class Solution(BaseModel):
    """Solution output model."""
    recommendation: str = Field(..., description="A concise, high-level recommendation to fix the issue.")
    troubleshooting_steps: List[str] = Field(..., description="A list of concrete, step-by-step instructions to resolve the error.")


class AgentState(TypedDict):
    """Agent state for LangGraph."""
    messages: Annotated[List[BaseMessage], add_messages]
    error_input: ErrorInput
    solution: Optional[Solution]
    solution_from_db: bool
    is_resolved: Optional[bool]


class DebuggingAgent:
    """
    Pure debugging agent with dependency injection.
    
    This agent is completely agnostic to:
    - Vector database implementation (Weaviate, Pinecone, ChromaDB, etc.)
    - Monitoring tool (Sentry, Datadog, New Relic, etc.)
    - Tools used (automatically loaded from tools/ directory)
    
    All external dependencies are injected through the constructor.
    """
    
    def __init__(
        self,
        llm_model: str = "gpt-4o",
        llm_temperature: float = 0,
        tool_names: Optional[List[str]] = None,
        vector_db_search: Optional[Callable[[str], Optional[Dict[str, Any]]]] = None,
        vector_db_store: Optional[Callable[[ErrorInput, Solution, bool], bool]] = None,
    ):
        """
        Initialize the debugging agent.
        
        Args:
            llm_model: The LLM model to use
            llm_temperature: Temperature for LLM responses
            tool_names: List of tool names to use (if None, uses all available tools)
                       Examples: ['search_stackoverflow', 'search_github_issues']
            vector_db_search: Function to search for similar solutions
            vector_db_store: Function to store solutions
        """
        self.llm = ChatOpenAI(model=llm_model, temperature=llm_temperature)
        
        # Load tools dynamically
        if tool_names:
            self.tools = [get_tool(name) for name in tool_names if get_tool(name)]
            if len(self.tools) != len(tool_names):
                missing = set(tool_names) - {t.name for t in self.tools}
                logging.warning(f"Some tools not found: {missing}")
        else:
            self.tools = get_all_tools()
        
        logging.info(f"Loaded {len(self.tools)} tools: {[t.name for t in self.tools]}")
        
        self.vector_db_search = vector_db_search
        self.vector_db_store = vector_db_store
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the agent graph with injected dependencies."""
        
        def check_db_node(state: AgentState) -> dict:
            """Check database for similar errors using injected search function."""
            logging.info("---1. CHECKING DATABASE FOR SIMILAR ERRORS---")
            error_input = state["error_input"]
            
            # If no vector DB search function provided, skip DB check
            if not self.vector_db_search:
                logging.info("---⚠️ NO VECTOR DB CONFIGURED. SKIPPING DB CHECK.---")
                return {"solution_from_db": False}
            
            try:
                solution_obj = self.vector_db_search(error_input.error_description)
                if not solution_obj:
                    logging.info("---⚠️ NO MATCH FOUND IN DB.---")
                    return {"solution_from_db": False}
                
                found_solution = Solution(
                    recommendation=solution_obj.get("solution_recommendation"),
                    troubleshooting_steps=solution_obj.get("solution_steps", []),
                )
                logging.info("---✅ FOUND MATCH IN DB. RETRIEVING SOLUTION.---")
                return {
                    "solution": found_solution,
                    "solution_from_db": True,
                    "is_resolved": solution_obj.get("resolved", False),
                }
            except Exception as e:
                logging.error(f"---❌ ERROR DURING DB QUERY: {e} ---")
                return {"solution_from_db": False}
        
        def query_generator_node(state: AgentState) -> dict:
            """Generate queries using LLM and tools."""
            logging.info("---2. GENERATING QUERIES---")
            error_data = state["error_input"].model_dump()
            prompt_text = (
                f"I encountered an error. Details: Project={error_data.get('project')}, "
                f"Title={error_data.get('title')}, Error={error_data.get('error_code')}, "
                f"Description={error_data.get('error_description')}, Release={error_data.get('release')}, "
                f"Environment={error_data.get('environment')}, Culprit={error_data.get('culprit')}"
            )
            if stack_files := error_data.get('stacktrace_files'):
                prompt_text += f"\n\nRelevant files from the stacktrace:\n{', '.join(stack_files)}"
            
            # Build dynamic tool usage guidelines based on available tools
            tool_guidelines = []
            tool_names = [t.name for t in self.tools]
            if 'context7_search' in tool_names:
                tool_guidelines.append("   - `context7_search`: Use for official documentation lookup")
            if 'search_developer_forums' in tool_names:
                tool_guidelines.append("   - `search_developer_forums`: Use for technology-specific community solutions")
            if 'search_stackoverflow' in tool_names:
                tool_guidelines.append("   - `search_stackoverflow`: Use for general programming questions")
            if 'search_github_issues' in tool_names:
                tool_guidelines.append("   - `search_github_issues`: Use for known bugs or library-specific issues")
            if 'search_web' in tool_names:
                tool_guidelines.append("   - `search_web`: Use as last resort for general web resources")
            
            tools_section = "\n".join(tool_guidelines) if tool_guidelines else "   - Use available tools wisely"
            
            system_message = f"""You are an expert SRE advisor helping developers and site reliability engineers debug production issues.
                Your role is to research and provide guidance - NOT to auto-fix issues.

                **YOUR GOAL**: Help engineers understand what's happening and guide them to resolution with context and best practices.

                **CRITICAL RULES:**
                1. **Answer from knowledge FIRST**: If you can confidently explain the error and provide guidance using your internal knowledge, do so immediately WITHOUT using any tools.
                2. **Use tools ONLY when necessary**: Use tools only if:
                - The error requires recent documentation or production incident patterns
                - You need to find similar production issues and their resolutions
                - The error is obscure or requires community battle-tested solutions
                3. **NEVER guess or hallucinate**: If unsure, either use tools or explicitly state uncertainty. Do NOT invent:
                - Fake API endpoints, functions, or methods
                - Non-existent incident reports or documentation
                - Speculative solutions without evidence
                4. **Tool usage guidelines** (prioritize production-relevant sources):
                {tools_section}
                5. **When using tools**: Base your guidance STRICTLY on the retrieved content. Focus on patterns from real production incidents.
                6. **Production context**: Always consider impact on live systems and provide safe, tested approaches.

                **Response quality**: Provide context-rich guidance that helps engineers understand and safely resolve issues. Prioritize official docs and proven solutions.
            """
            query_generator_prompt = ChatPromptTemplate.from_messages([
                ("system", system_message),
                ("human", "{problem_description}")
            ])
            chain = query_generator_prompt | self.llm.bind_tools(self.tools)
            response = chain.invoke({"problem_description": prompt_text})
            return {"messages": [response]}
        
        tool_executor_node = ToolNode(self.tools) if self.tools else None
        
        def solution_synthesizer_node(state: AgentState) -> dict:
            """Synthesize solution from tool results."""
            logging.info("\n---3. FETCHED TOOL RESULTS---")
            from langchain_core.messages import ToolMessage
            for msg in state["messages"]:
                if isinstance(msg, ToolMessage):
                    tool_name = msg.name
                    tool_output = msg.content
                    logging.info(f"\nTool: {tool_name}\nResult:\n{tool_output[:500]}...")
            
            logging.info("---4. SYNTHESIZING NEW STRUCTURED SOLUTION---")
            synthesizer_llm = self.llm.with_structured_output(Solution)
            system_prompt = (
                "You are an experienced SRE advisor synthesizing guidance to help developers resolve production issues. The error is: {error_input}.\n\n"
                "**YOUR ROLE**: Provide comprehensive advisory guidance - NOT automated fixes. Help engineers understand and safely resolve issues.\n\n"
                "**STRICT SYNTHESIS RULES:**\n"
                "1. **Use ONLY retrieved content**: Base your guidance exclusively on the tool results provided. Do NOT add information from memory.\n"
                "2. **No hallucination**: Do NOT invent APIs, functions, code snippets, or incident reports that weren't in the tool results.\n"
                "3. **Prioritization order** (production-focused):\n"
                "   - Official documentation (context7_search) is highest priority\n"
                "   - Production incident patterns from developer forums (search_developer_forums) - use top 2 results only\n"
                "   - GitHub issues for known bugs in production\n"
                "   - Stack Overflow for battle-tested community solutions\n"
                "   - General web search as last resort\n"
                "4. **Conservative approach**: If tool results are insufficient or conflicting, state this clearly. Do NOT guess. Production safety first.\n"
                "5. **Factual guidance only**: Each step must be directly supported by the retrieved content.\n"
                "6. **Citation awareness**: When using forum/community results, acknowledge sources.\n\n"
                "**COMPREHENSIVE OUTPUT** - Provide rich context in the Solution schema:\n"
                "- `recommendation`: Clear, high-level approach to resolve the issue\n"
                "- `troubleshooting_steps`: Detailed investigation and resolution steps\n"
                "- `error_context`: Explain what this error means in production (help engineers understand)\n"
                "- `common_causes`: List likely root causes based on similar incidents\n"
                "- `impact_assessment`: Describe potential user/business impact for prioritization\n"
                "- `diagnostic_queries`: Specific logs, metrics, commands to run for diagnosis\n"
                "- `related_resources`: Include URLs from tool results (docs, discussions, issues)\n\n"
                "Think like an advisor helping a capable engineer, not an automated fix system."
            )
            solution_prompt = ChatPromptTemplate.from_messages([
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="messages")
            ])
            chain = solution_prompt | synthesizer_llm
            solution = chain.invoke({
                "messages": state["messages"],
                "error_input": state["error_input"].model_dump_json(),
            })
            return {"solution": solution, "solution_from_db": False}
        
        def should_run_llm(state: AgentState) -> str:
            """Decide whether to use LLM or return cached solution."""
            return "end" if state.get("solution_from_db") else "query_generator"
        
        # Build the graph
        builder = StateGraph(AgentState)
        builder.add_node("check_db", check_db_node)
        builder.add_node("query_generator", query_generator_node)
        if tool_executor_node:
            builder.add_node("tool_executor", tool_executor_node)
        builder.add_node("solution_synthesizer", solution_synthesizer_node)
        
        builder.add_edge(START, "check_db")
        builder.add_conditional_edges("check_db", should_run_llm, {"end": END, "query_generator": "query_generator"})
        
        if tool_executor_node:
            builder.add_edge("query_generator", "tool_executor")
            builder.add_edge("tool_executor", "solution_synthesizer")
        else:
            builder.add_edge("query_generator", "solution_synthesizer")
        
        builder.add_edge("solution_synthesizer", END)
        
        return builder.compile()
    
    def solve(self, error_input: ErrorInput, initial_messages: Optional[List[BaseMessage]] = None) -> Dict[str, Any]:
        """
        Solve an error using the agent.
        
        Args:
            error_input: The error to solve
            initial_messages: Optional initial messages for the agent
            
        Returns:
            Final state dictionary with solution
        """
        initial_state = {
            "messages": initial_messages or [HumanMessage(content=error_input.model_dump_json())],
            "error_input": error_input,
            "solution": None,
            "solution_from_db": False,
            "is_resolved": False,
        }
        
        final_state = self.graph.invoke(initial_state)
        
        # Store solution if store function provided and solution exists
        storage_success = False
        if self.vector_db_store and final_state.get("solution"):
            try:
                result = self.vector_db_store(
                    error_input,
                    final_state["solution"],
                    final_state.get("is_resolved", False)
                )
                if result:
                    storage_success = True
                    logging.info("✅ Solution stored in vector database")
                else:
                    logging.error("❌ Failed to store solution in vector database")
                    raise RuntimeError("Vector database storage failed")
            except Exception as e:
                logging.error(f"❌ CRITICAL: Failed to store solution: {e}")
                raise RuntimeError(f"Solution storage failed: {e}")
        
        # Add storage success flag to final state
        final_state["storage_success"] = storage_success
        
        return final_state


# ============================================================================
# API ENDPOINTS - Agent Operations
# ============================================================================

@router.post("/debug", response_model=DebugResponse)
async def debug_error_endpoint(request: DebugRequest):
    """
    Debug an error using the AI agent
    Searches vector DB first, then uses LLM tools if needed
    """
    try:
        # Import dependencies here to avoid circular imports
        from vector_db_interface import WeaviateVectorDB
        from datetime import datetime, timezone
        
        # Initialize vector DB
        vector_db = WeaviateVectorDB()
        if not vector_db.initialize():
            raise RuntimeError("Failed to initialize vector database")
        
        # Create agent
        agent = DebuggingAgent(
            llm_model="gpt-4o",
            llm_temperature=0,
            tool_names=None,  # Use all tools
            vector_db_search=vector_db.search_similar,
            vector_db_store=vector_db.store_solution
        )
        
        # Create error input
        error_input = ErrorInput(
            project=request.project,
            title=request.error_message[:100],
            error_code="API_ERROR",
            error_description=request.error_message,
            last_seen=datetime.now(timezone.utc).isoformat(),
            environment=request.environment,
            release=request.release,
            culprit=None,
            stacktrace_files=request.stack_trace.split("\n") if request.stack_trace else None
        )
        
        # Solve the error
        result = agent.solve(error_input)
        
        solution = result.get("solution")
        if solution:
            return DebugResponse(
                success=True,
                solution_recommendation=solution.recommendation,
                troubleshooting_steps=solution.troubleshooting_steps,
                stored_in_db=result.get("storage_success", False),
                solution_from_db=result.get("solution_from_db", False)
            )
        else:
            return DebugResponse(
                success=False,
                error="No solution generated",
                stored_in_db=False,
                solution_from_db=False
            )
            
    except Exception as e:
        logging.error(f"Debug endpoint error: {e}")
        return DebugResponse(
            success=False,
            error=str(e),
            stored_in_db=False,
            solution_from_db=False
        )


@router.get("/status")
async def agent_status():
    """
    Get agent status and available tools
    """
    try:
        tools = get_all_tools()
        return {
            "status": "operational",
            "available_tools": [t.name for t in tools],
            "tool_count": len(tools),
            "llm_model": "gpt-4o"
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get agent status: {str(e)}"
        )
