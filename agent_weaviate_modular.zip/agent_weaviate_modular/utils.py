"""Shared utilities and local state persistence."""
import os
import json
import logging
from typing import List, Optional
from datetime import datetime

# FastAPI imports for API endpoints
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

# Local JSON files for persistence
STATE_FILE = "agent_state.json"
AGENT_RUNS_FILE = "agent_runs.json"

# ============================================================================
# API ROUTER - State Management Endpoints
# ============================================================================

router = APIRouter(prefix="/state", tags=["State Management"])


class LastSeenResponse(BaseModel):
    """Response model for last seen timestamp"""
    last_seen: str


class UpdateTimestampRequest(BaseModel):
    """Request model for updating timestamp"""
    timestamp: str = Field(..., description="ISO format timestamp")


class AgentRunsResponse(BaseModel):
    """Response model for agent runs history"""
    total_runs: int
    runs: List[dict]


def get_last_seen() -> str:
    """Fetch the last processed timestamp from the local state file."""
    try:
        if not os.path.exists(STATE_FILE):
            return "1970-01-01T00:00:00Z"
        with open(STATE_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            if "lastSeen" in data:
                return data.get("lastSeen", "1970-01-01T00:00:00Z")
            if data:
                first_user = next(iter(data.values()), {})
                if isinstance(first_user, dict):
                    return next(
                        (
                            agent_map.get("lastSeen")
                            for agent_map in first_user.values()
                            if isinstance(agent_map, dict) and agent_map.get("lastSeen")
                        ),
                        "1970-01-01T00:00:00Z",
                    )
        if isinstance(data, str):
            return data
        return "1970-01-01T00:00:00Z"
    except Exception as exc:
        logging.error(f"Error fetching lastSeen from local state file: {exc}")
        return "1970-01-01T00:00:00Z"


def save_last_seen(new_last_seen: str) -> None:
    """Persist the last processed timestamp in the local state file."""
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as handle:
            json.dump({"lastSeen": new_last_seen}, handle, indent=2)
        logging.info(f"Updated lastSeen: {new_last_seen}")
    except Exception as exc:
        logging.error(f"Error updating lastSeen in local state file: {exc}")


def put_agent_run(run_item: dict) -> None:
    """Append the latest agent run to the local history file."""
    try:
        runs: List[dict] = []
        if os.path.exists(AGENT_RUNS_FILE):
            with open(AGENT_RUNS_FILE, "r", encoding="utf-8") as handle:
                runs = json.load(handle)
        runs.append(run_item)
        with open(AGENT_RUNS_FILE, "w", encoding="utf-8") as handle:
            json.dump(runs, handle, indent=2)
    except Exception as exc:
        logging.error(f"Failed to persist agent run locally: {exc}")


# ============================================================================
# API ENDPOINTS - State Management Operations
# ============================================================================

@router.get("/last-seen", response_model=LastSeenResponse)
async def get_last_seen_endpoint():
    """
    Get the last processed Sentry timestamp
    """
    try:
        last_seen = get_last_seen()
        return LastSeenResponse(last_seen=last_seen)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load timestamp: {str(e)}"
        )


@router.put("/last-seen")
async def update_last_seen_endpoint(request: UpdateTimestampRequest):
    """
    Update the last seen timestamp for Sentry issues
    Timestamp should be in ISO format
    """
    try:
        # Validate timestamp format
        datetime.fromisoformat(request.timestamp.replace('Z', '+00:00'))
        
        save_last_seen(request.timestamp)
        return {
            "success": True,
            "message": f"Last seen timestamp updated to {request.timestamp}"
        }
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail="Invalid timestamp format. Use ISO format."
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save timestamp: {str(e)}"
        )


@router.get("/runs", response_model=AgentRunsResponse)
async def get_agent_runs(limit: Optional[int] = None):
    """
    Get agent run history
    """
    try:
        runs: List[dict] = []
        if os.path.exists(AGENT_RUNS_FILE):
            with open(AGENT_RUNS_FILE, "r", encoding="utf-8") as handle:
                runs = json.load(handle)
        
        if limit:
            runs = runs[-limit:]  # Get last N runs
        
        return AgentRunsResponse(
            total_runs=len(runs),
            runs=runs
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load agent runs: {str(e)}"
        )
