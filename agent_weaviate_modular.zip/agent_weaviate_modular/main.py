"""Main orchestration for Sentry issue processing with debugging agent."""
import logging
from datetime import datetime, timezone
from dotenv import load_dotenv
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager
import asyncio

# FastAPI imports
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Import monitoring tool adapter (Sentry)
from sentry_client import (
    validate_sentry_connection,
    get_sentry_issues_since,
    get_event_details,
    extract_stacktrace_files,
    extract_issue_details
)

# Import vector DB adapter (Weaviate)
from vector_db_interface import WeaviateVectorDB

# Import pure agent core
from agent_core import DebuggingAgent, ErrorInput

# Import utilities
from utils import get_last_seen, save_last_seen, put_agent_run

# Import routers from all modules
import weaviate_client
import sentry_client
import agent_core
import utils

load_dotenv()
logging.basicConfig(level=logging.INFO, format='%(message)s')


# ============================================================================
# PYDANTIC MODELS FOR API
# ============================================================================

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    sentry_connected: bool
    weaviate_connected: bool
    timestamp: str


class ProcessSentryResponse(BaseModel):
    """Response for Sentry processing endpoint"""
    success: bool
    issues_processed: int = 0
    message: str
    error: Optional[str] = None


class LastSeenResponse(BaseModel):
    """Response for last seen timestamp"""
    last_seen: Optional[str] = None


class ValidateResponse(BaseModel):
    """Response for validation endpoint"""
    valid: bool
    message: str


# ============================================================================
# FASTAPI APP INITIALIZATION
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifecycle manager"""
    logging.info("🚀 Starting Sentry Debugging Agent API...")
    try:
        validate_prerequisites()
        logging.info("✅ API ready to accept requests\n")
    except SystemExit:
        logging.error("❌ API startup failed - prerequisites not met")
        raise
    
    yield
    
    logging.info("\n🛑 Shutting down API...")


app = FastAPI(
    title="Sentry Debugging Agent API",
    description="REST API for automated error debugging with Sentry integration",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount all routers from modules
app.include_router(weaviate_client.router)
app.include_router(sentry_client.router)
app.include_router(agent_core.router)
app.include_router(utils.router)


# ============================================================================
# CORE FUNCTIONS (Existing CLI Logic)
# ============================================================================

def validate_prerequisites() -> None:
    """Validate all required connections before starting agent.
    
    Raises:
        SystemExit: If any prerequisite validation fails
    """
    logging.info("=" * 60)
    logging.info("VALIDATING PREREQUISITES")
    logging.info("=" * 60)
    
    # Validate Sentry connection
    try:
        logging.info("\n[1/2] Validating Sentry connection...")
        validate_sentry_connection()
    except (ValueError, ConnectionError) as e:
        logging.error(f"\n❌ SENTRY CONNECTION FAILED: {e}")
        logging.error("\nAgent cannot run without Sentry connection.")
        logging.error("Please check your Sentry configuration and try again.\n")
        raise SystemExit(1)
    
    # Validate Weaviate connection
    try:
        logging.info("\n[2/2] Validating Weaviate connection...")
        vector_db = WeaviateVectorDB()
        if not vector_db.initialize():
            raise ConnectionError("Weaviate initialization failed")
        logging.info("✅ Weaviate connection validated successfully")
    except Exception as e:
        logging.error(f"\n❌ WEAVIATE CONNECTION FAILED: {e}")
        logging.error("\nAgent cannot run without Weaviate connection.")
        logging.error("Please check your Weaviate configuration and try again.\n")
        raise SystemExit(1)
    
    logging.info("\n" + "=" * 60)
    logging.info("✅ ALL PREREQUISITES VALIDATED SUCCESSFULLY")
    logging.info("=" * 60 + "\n")


def process_sentry_issues() -> dict:
    """Fetch recent Sentry issues, resolve them, and persist the outcomes."""
    logging.info("Starting Sentry issue processing")
    last_seen = get_last_seen()
    logging.info(f"Last seen timestamp retrieved: {last_seen}")

    try:
        # Initialize vector database (already validated, but get instance)
        vector_db = WeaviateVectorDB()
        if not vector_db.initialize():
            raise RuntimeError("Weaviate initialization failed after validation")
        
        # Create agent with specific tools
        # You can customize which tools to use:
        # Option 1: Use all tools
        agent = DebuggingAgent(
            llm_model="gpt-4o",
            llm_temperature=0,
            tool_names=None,  # None = use all tools
            vector_db_search=vector_db.search_similar,
            vector_db_store=vector_db.store_solution
        )
        
        # Option 2: Use specific tools only
        # agent = DebuggingAgent(
        #     llm_model="gpt-4o",
        #     llm_temperature=0,
        #     tool_names=['search_stackoverflow', 'search_github_issues', 'context7_search'],
        #     vector_db_search=vector_db.search_similar,
        #     vector_db_store=vector_db.store_solution
        # )
        
        # Fetch issues from monitoring tool (Sentry)
        issues = get_sentry_issues_since(last_seen)
        if not issues:
            logging.info("No new issues to process.")
            new_last_seen = datetime.utcnow().replace(tzinfo=timezone.utc).isoformat(timespec="seconds") + "Z"
            save_last_seen(new_last_seen)
            return {"statusCode": 200, "body": "No new issues found"}
        issues.sort(key=lambda x: x["lastSeen"])

        # Process each issue
        for issue in issues:
            details = extract_issue_details(issue)
            latest_event_id = issue.get("latestEvent")
            event_obj = get_event_details(latest_event_id)
            stack_files = extract_stacktrace_files(event_obj)
            
            error_input = ErrorInput(
                project=details.get('project'),
                title=details.get('title'),
                error_code=details.get('error_code'),
                error_description=f"Error Description: {details.get('error_description')}",
                last_seen=details.get('last_seen'),
                environment=details.get('environment'),
                release=details.get('release'),
                culprit=details.get('culprit'),
                stacktrace_files=stack_files
            )
            
            logging.info(f"Processing error: {error_input.title}")
            
            # Use the agent to solve the error
            final_state = agent.solve(error_input)
            solution = final_state.get("solution")

            if solution:
                logging.info("Solution Found:")
                logging.info(f"Recommendation: {solution.recommendation}")
                for i, step in enumerate(solution.troubleshooting_steps, 1):
                    logging.info(f"Step {i}: {step}")

                # Verify solution was stored in Weaviate
                if not final_state.get("storage_success", False):
                    logging.error("❌ CRITICAL: Failed to store solution in Weaviate")
                    logging.error("Agent execution halted due to storage failure")
                    raise RuntimeError("Solution storage in Weaviate failed")
                
                logging.info("✅ Solution successfully stored in Weaviate")

                run_item = {
                    "startedAt": details.get('last_seen'),
                    "status": "resolved" if final_state.get("is_resolved") else "unresolved",
                    "recommendation": solution.recommendation,
                    "troubleshooting_steps": solution.troubleshooting_steps,
                    "errorTitle": details.get('title'),
                    "errorCode": details.get('error_code'),
                    "errorDescription": details.get('error_description'),
                    "environment": details.get('environment'),
                    "release": details.get('release'),
                }
                put_agent_run(run_item)
            else:
                logging.warning("No solution generated for this error.")

        new_last_seen = issues[-1]["lastSeen"]
        save_last_seen(new_last_seen)
        return {"statusCode": 200, "body": f"Processed {len(issues)} issues up to {new_last_seen}"}
    except Exception as exc:
        logging.error(f"Error during local execution: {exc}")
        return {"statusCode": 500, "body": str(exc)}


def main() -> None:
    """Main entry point with prerequisite validation."""
    try:
        # Validate all connections before starting
        validate_prerequisites()
        
        # Process issues
        result = process_sentry_issues()
        logging.info("\n" + "=" * 60)
        logging.info("✅ AGENT RUN COMPLETED SUCCESSFULLY")
        logging.info(f"Result: {result.get('body')}")
        logging.info("=" * 60 + "\n")
        
    except SystemExit:
        # Re-raise SystemExit to maintain exit code
        raise
    except Exception as e:
        logging.error("\n" + "=" * 60)
        logging.error("❌ AGENT RUN FAILED")
        logging.error(f"Error: {e}")
        logging.error("=" * 60 + "\n")
        raise SystemExit(1)


# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Sentry Debugging Agent API",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """
    Health check endpoint - verifies Sentry and Weaviate connections
    """
    sentry_ok = False
    weaviate_ok = False
    
    try:
        validate_sentry_connection()
        sentry_ok = True
    except:
        pass
    
    try:
        vector_db = WeaviateVectorDB()
        weaviate_ok = vector_db.initialize()
    except:
        pass
    
    status = "healthy" if (sentry_ok and weaviate_ok) else "degraded"
    
    return HealthResponse(
        status=status,
        sentry_connected=sentry_ok,
        weaviate_connected=weaviate_ok,
        timestamp=datetime.now(timezone.utc).isoformat()
    )


@app.post("/process-sentry", response_model=ProcessSentryResponse, tags=["Sentry"])
async def process_sentry_endpoint(background_tasks: BackgroundTasks):
    """
    Process new Sentry issues endpoint
    Fetches issues since last seen timestamp and processes them
    """
    try:
        # Run in thread to avoid blocking
        result = await asyncio.to_thread(process_sentry_issues)
        
        if result.get("statusCode") == 200:
            return ProcessSentryResponse(
                success=True,
                issues_processed=result.get("body", "").split()[1] if "Processed" in result.get("body", "") else 0,
                message=result.get("body", "")
            )
        else:
            return ProcessSentryResponse(
                success=False,
                message=result.get("body", "Unknown error"),
                error=result.get("body")
            )
    except Exception as e:
        logging.error(f"API endpoint error: {e}")
        return ProcessSentryResponse(
            success=False,
            message="Failed to process Sentry issues",
            error=str(e)
        )


@app.post("/validate", response_model=ValidateResponse, tags=["Orchestration"])
async def validate_connections():
    """
    Validate all connections (Sentry + Weaviate)
    High-level orchestration endpoint
    """
    try:
        validate_prerequisites()
        return ValidateResponse(
            valid=True,
            message="All connections validated successfully"
        )
    except SystemExit:
        raise HTTPException(
            status_code=503,
            detail="Validation failed - check logs for details"
        )
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Validation failed: {str(e)}"
        )


# ============================================================================
# CLI ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    import sys
    
    # Check if running as API server or CLI
    if len(sys.argv) > 1 and sys.argv[1] == "--api":
        import uvicorn
        logging.info("Starting API server mode...")
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
    else:
        # Run as CLI
        main()
