"""State management utilities for persistence."""
import os
import json
import logging
from typing import List, Optional, Dict, Any
from pathlib import Path


logger = logging.getLogger(__name__)


class StateManager:
    """Manages persistent state for the agent."""
    
    DEFAULT_STATE_FILE = "agent_state.json"
    DEFAULT_RUNS_FILE = "agent_runs.json"
    
    def __init__(
        self,
        state_file: str = DEFAULT_STATE_FILE,
        runs_file: str = DEFAULT_RUNS_FILE
    ):
        """
        Initialize state manager.
        
        Args:
            state_file: Path to state file.
            runs_file: Path to runs history file.
        """
        self.state_file = Path(state_file)
        self.runs_file = Path(runs_file)
    
    def get_last_seen(self, state_file: Optional[str] = None) -> str:
        """
        Fetch the last processed timestamp.
        
        Args:
            state_file: Optional override for state file path.
        
        Returns:
            ISO 8601 timestamp string or epoch if not found.
        """
        filepath = Path(state_file) if state_file else self.state_file
        
        try:
            if not filepath.exists():
                return "1970-01-01T00:00:00Z"
            
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if isinstance(data, dict):
                return data.get("lastSeen", "1970-01-01T00:00:00Z")
            if isinstance(data, str):
                return data
            
            return "1970-01-01T00:00:00Z"
            
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON in state file: {filepath}")
            return "1970-01-01T00:00:00Z"
        except Exception as e:
            logger.error(f"Error reading state file: {e}")
            return "1970-01-01T00:00:00Z"
    
    def save_last_seen(
        self,
        timestamp: str,
        state_file: Optional[str] = None
    ) -> None:
        """
        Persist the last processed timestamp.
        
        Args:
            timestamp: ISO 8601 timestamp string.
            state_file: Optional override for state file path.
        """
        filepath = Path(state_file) if state_file else self.state_file
        
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump({"lastSeen": timestamp}, f, indent=2)
            logger.debug(f"Saved last_seen timestamp: {timestamp}")
        except Exception as e:
            logger.error(f"Error saving state file: {e}")
    
    def save_agent_run(self, run_data: Dict[str, Any]) -> None:
        """
        Append an agent run record to history.
        
        Args:
            run_data: Run metadata dictionary.
        """
        try:
            runs = []
            if self.runs_file.exists():
                with open(self.runs_file, "r", encoding="utf-8") as f:
                    runs = json.load(f)
            
            runs.append(run_data)
            
            with open(self.runs_file, "w", encoding="utf-8") as f:
                json.dump(runs, f, indent=2)
                
            logger.debug(f"Saved agent run: {run_data.get('timestamp', 'unknown')}")
        except Exception as e:
            logger.error(f"Error saving agent run: {e}")
    
    def get_agent_runs(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Retrieve agent run history.
        
        Args:
            limit: Optional limit on number of runs to return.
        
        Returns:
            List of run metadata dictionaries.
        """
        try:
            if not self.runs_file.exists():
                return []
            
            with open(self.runs_file, "r", encoding="utf-8") as f:
                runs = json.load(f)
            
            if limit:
                return runs[-limit:]
            return runs
            
        except Exception as e:
            logger.error(f"Error reading agent runs: {e}")
            return []


# Backwards compatibility functions
def get_last_seen(state_file: str = StateManager.DEFAULT_STATE_FILE) -> str:
    """Legacy function for backwards compatibility."""
    manager = StateManager()
    return manager.get_last_seen(state_file)


def save_last_seen(timestamp: str, state_file: str = StateManager.DEFAULT_STATE_FILE) -> None:
    """Legacy function for backwards compatibility."""
    manager = StateManager()
    manager.save_last_seen(timestamp, state_file)


def put_agent_run(run_item: dict) -> None:
    """Legacy function for backwards compatibility."""
    manager = StateManager()
    manager.save_agent_run(run_item)
