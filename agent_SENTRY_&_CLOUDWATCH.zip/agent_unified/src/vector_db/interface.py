"""
Vector Database Interface

Abstract interface and Weaviate implementation for solution storage/retrieval.

Design Pattern:
    Abstract interface allows swapping vector DB implementations without
    changing agent code. Follows dependency injection principle.

VectorDBInterface (Abstract):
    - initialize(): Setup connection and validate schema
    - search_similar(): Find similar errors by semantic similarity
    - store_solution(): Persist error-solution pairs with metadata

WeaviateVectorDB (Implementation):
    - Concrete implementation using Weaviate Cloud
    - OpenAI embeddings (1536 dimensions)
    - Semantic similarity search with cosine distance
    - Stores 21 fields per error-solution entry

Storage Schema:
    - Error fields (9): description, code, project, environment, stacktrace, etc.
    - Solution fields (3): recommendation, troubleshooting steps, resolved flag
    - Metadata fields (6): source tool, severity, timestamps, fingerprint, rating
    - Tech stack (1): JSON with languages, frameworks, database info

Usage:
    from src.vector_db.interface import WeaviateVectorDB
    
    db = WeaviateVectorDB()
    db.initialize()
    
    solution = db.search_similar("connection timeout error", threshold=0.8)
    if solution:
        print(solution['solution_recommendation'])
    
    db.store_solution(error_input, solution, is_resolved=True)

Extensibility:
    To add new vector DB (Pinecone, ChromaDB, etc.):
    1. Create new class: class PineconeVectorDB(VectorDBInterface)
    2. Implement: initialize(), search_similar(), store_solution()
    3. Update agent to use new implementation
"""
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any


class VectorDBInterface(ABC):
    """Abstract interface that any vector database must implement."""
    
    @abstractmethod
    def initialize(self) -> bool:
        """Initialize the database connection and schema."""
        pass
    
    @abstractmethod
    def search_similar(self, error_description: str, threshold: float = 0.3) -> Optional[Dict[str, Any]]:
        """
        Search for similar solutions in the database.
        
        Args:
            error_description: The error description to search for
            threshold: Minimum similarity threshold
            
        Returns:
            Dictionary with 'solution_recommendation', 'solution_steps', and 'resolved' keys,
            or None if no similar solution found
        """
        pass
    
    @abstractmethod
    def store_solution(self, error_input: Any, solution: Any, is_resolved: bool = False) -> bool:
        """
        Store a solution in the database.
        
        Args:
            error_input: ErrorInput object with error details
            solution: Solution object with recommendation and steps
            is_resolved: Whether the issue was resolved
            
        Returns:
            True if stored successfully, False otherwise
        """
        pass


class WeaviateVectorDB(VectorDBInterface):
    """Weaviate implementation of the vector database interface."""
    
    def __init__(self):
        from src.vector_db.weaviate_client import get_weaviate_client, ensure_debugging_solution_schema
        self.get_client = get_weaviate_client
        self.ensure_schema = ensure_debugging_solution_schema
    
    def initialize(self) -> bool:
        """Initialize Weaviate connection and schema."""
        client = self.get_client()
        if not client:
            return False
        return self.ensure_schema(client)
    
    def search_similar(self, error_description: str, threshold: float = 0.3) -> Optional[Dict[str, Any]]:
        """Search for similar solutions in Weaviate."""
        from src.vector_db.weaviate_client import fetch_similar_solution
        return fetch_similar_solution(error_description)
    
    def store_solution(self, error_input: Any, solution: Any, is_resolved: bool = False) -> bool:
        """Store solution in Weaviate."""
        from src.vector_db.weaviate_client import store_solution_in_db
        store_solution_in_db(error_input, solution, is_resolved)
        return True
