"""Custom exceptions for the error monitoring agent."""


class AgentError(Exception):
    """Base exception for all agent errors."""
    pass


class ConfigurationError(AgentError):
    """Raised when configuration is invalid or missing."""
    pass


class MonitoringToolError(AgentError):
    """Base exception for monitoring tool errors."""
    pass


class ConnectionError(MonitoringToolError):
    """Raised when connection to monitoring tool fails."""
    pass


class AuthenticationError(MonitoringToolError):
    """Raised when authentication with monitoring tool fails."""
    pass


class VectorDBError(AgentError):
    """Base exception for vector database errors."""
    pass


class VectorDBConnectionError(VectorDBError):
    """Raised when connection to vector database fails."""
    pass


class VectorDBQueryError(VectorDBError):
    """Raised when vector database query fails."""
    pass


class NormalizationError(AgentError):
    """Raised when error normalization fails."""
    pass


class SolutionGenerationError(AgentError):
    """Raised when solution generation fails."""
    pass
