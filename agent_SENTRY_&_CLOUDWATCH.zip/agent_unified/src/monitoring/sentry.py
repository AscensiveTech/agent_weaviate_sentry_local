"""Sentry adapter for unified error monitoring."""
import os
import logging
import requests
from typing import List, Optional
from datetime import datetime
from dotenv import load_dotenv

from src.monitoring.base import MonitoringToolInterface
from src.normalization.normalizer import UnifiedError

load_dotenv()

# Sentry API Configuration
SENTRY_AUTH_TOKEN = os.getenv("SENTRY_AUTH_TOKEN")
ORG_SLUG = os.getenv("SENTRY_ORG_SLUG")
PROJECT_SLUG = os.getenv("SENTRY_PROJECT_SLUG")
SENTRY_API_HEADERS = {"Authorization": f"Bearer {SENTRY_AUTH_TOKEN}"}


# ============================================================================
# SENTRY PLATFORM SPECIFICATIONS (Official API Standards)
# ============================================================================
# These constants define Sentry's official severity levels and status values.
# Reference: https://docs.sentry.io/product/sentry-basics/integrate-frontend/error-monitoring/
# Users should NOT configure these - they are Sentry API specifications.

# Sentry standard severity levels (as defined in Sentry's official documentation)
# These numeric values match Sentry's internal level system
SENTRY_SEVERITY_LEVELS = {
    'fatal': 50,      # Fatal/catastrophic errors - immediate action required
    'error': 40,      # Errors that should be investigated and fixed
    'warning': 30,    # Warnings that may lead to errors
    'info': 20,       # Informational messages
    'debug': 10,      # Debug-level messages for development
}

# Sentry issue status values (official Sentry states)
SENTRY_STATUS_UNRESOLVED = 'unresolved'  # Active issues requiring attention
SENTRY_STATUS_RESOLVED = 'resolved'      # Fixed issues
SENTRY_STATUS_IGNORED = 'ignored'        # Acknowledged but not fixed
# ============================================================================

logger = logging.getLogger(__name__)


class SentryMonitor(MonitoringToolInterface):
    """Sentry monitoring adapter."""
    
    def __init__(self):
        """Initialize Sentry client."""
        self.auth_token = SENTRY_AUTH_TOKEN
        self.org_slug = ORG_SLUG
        self.project_slug = PROJECT_SLUG
        self.headers = SENTRY_API_HEADERS
    
    def get_tool_name(self) -> str:
        """Return the name of the monitoring tool."""
        return "SENTRY"
    
    def validate_connection(self) -> bool:
        """
        Validate Sentry API connection and credentials.
        
        Returns:
            True if connection successful
            
        Raises:
            ValueError: If required environment variables are missing
            ConnectionError: If Sentry API is unreachable
        """
        # Check required environment variables
        if not all([self.auth_token, self.org_slug, self.project_slug]):
            missing = []
            if not self.auth_token:
                missing.append("SENTRY_AUTH_TOKEN")
            if not self.org_slug:
                missing.append("SENTRY_ORG_SLUG")
            if not self.project_slug:
                missing.append("SENTRY_PROJECT_SLUG")
            raise ValueError(f"Missing required Sentry environment variables: {', '.join(missing)}")
        
        # Test connection with a simple API call
        test_url = f"https://sentry.io/api/0/projects/{self.org_slug}/{self.project_slug}/"
        
        try:
            response = requests.get(test_url, headers=self.headers, timeout=10)
            
            if response.status_code == 401:
                raise ConnectionError("Sentry authentication failed. Invalid SENTRY_AUTH_TOKEN.")
            elif response.status_code == 403:
                raise ConnectionError("Sentry access forbidden. Check token permissions.")
            elif response.status_code == 404:
                raise ConnectionError(f"Sentry project not found: {self.org_slug}/{self.project_slug}")
            elif response.status_code != 200:
                raise ConnectionError(f"Sentry API returned unexpected status {response.status_code}")
            
            logger.info("✅ Sentry connection validated successfully")
            return True
            
        except requests.exceptions.Timeout:
            raise ConnectionError("Sentry API request timed out")
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Sentry connection failed: {e}")
    
    def fetch_errors_since(self, since_timestamp: str) -> List[UnifiedError]:
        """
        Fetch Sentry issues since a given timestamp.
        
        Args:
            since_timestamp: ISO 8601 timestamp (YYYY-MM-DDTHH:MM:SSZ)
            
        Returns:
            List[UnifiedError]: List of errors in unified format
        """
        try:
            # Fetch issues from Sentry API
            issues_url = f"https://sentry.io/api/0/projects/{self.org_slug}/{self.project_slug}/issues/"
            
            params = {
                "query": f"lastSeen:>={since_timestamp}",
                "statsPeriod": "14d"
            }
            
            response = requests.get(issues_url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code != 200:
                raise ConnectionError(f"Sentry API error: {response.status_code}")
            
            issues = response.json()
            
            # Convert each issue to UnifiedError
            unified_errors = []
            for issue in issues:
                unified_error = self._parse_sentry_issue(issue)
                if unified_error:
                    unified_errors.append(unified_error)
            
            logger.info(f"Fetched {len(unified_errors)} issues from Sentry since {since_timestamp}")
            return unified_errors
            
        except requests.exceptions.Timeout:
            logger.error("Sentry API request timed out")
            raise ConnectionError("Sentry API request timed out")
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch Sentry issues: {e}")
            raise ConnectionError(f"Sentry fetch failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error fetching Sentry issues: {e}")
            raise
    
    def _parse_sentry_issue(self, issue: dict) -> Optional[UnifiedError]:
        """
        Parse a Sentry issue into UnifiedError format.
        
        Args:
            issue: Sentry issue dictionary
            
        Returns:
            UnifiedError object or None if parsing fails
        """
        try:
            # Extract basic info
            issue_id = issue.get('id', '')
            title = issue.get('title', 'Unknown Error')
            culprit = issue.get('culprit', '')
            
            # Get metadata
            metadata = issue.get('metadata', {})
            error_type = metadata.get('type', issue.get('type', 'Error'))
            error_value = metadata.get('value', '')
            
            # Build error description
            error_description = f"{error_type}: {error_value}\n"
            
            # Add culprit if available
            if culprit:
                error_description += f"Culprit: {culprit}\n"
            
            # Get last seen timestamp
            last_seen = issue.get('lastSeen', '')
            if last_seen:
                # Sentry returns ISO format, ensure it has 'Z' suffix
                if not last_seen.endswith('Z'):
                    last_seen += 'Z'
            else:
                last_seen = datetime.utcnow().isoformat() + 'Z'
            
            # Extract environment
            environment = None
            tags = issue.get('tags', [])
            for tag in tags:
                if tag.get('key') == 'environment':
                    environment = tag.get('value')
                    break
            
            # Get project name as service name
            project = issue.get('project', {})
            service_name = project.get('name', self.project_slug)
            
            # Create unified error
            unified_error = UnifiedError(
                error_description=error_description,
                source_tool="SENTRY",
                title=title,
                error_type=error_type,
                timestamp=last_seen,
                environment=environment,
                service_name=service_name,
                culprit=culprit,
                severity=issue.get('level', 'error'),
                context_metadata={
                    'issue_id': issue_id,
                    'short_id': issue.get('shortId', ''),
                    'permalink': issue.get('permalink', ''),
                    'count': issue.get('count', 0),
                    'user_count': issue.get('userCount', 0),
                }
            )
            
            return unified_error
            
        except Exception as e:
            logger.warning(f"Failed to parse Sentry issue: {e}")
            return None
