"""Base interface for monitoring tool adapters."""
from abc import ABC, abstractmethod
from typing import List
from src.normalization.normalizer import UnifiedError


class MonitoringToolInterface(ABC):
    """
    Abstract base class for all monitoring tool adapters.
    Each monitoring tool (CloudWatch, Sentry, Datadog, etc.) must implement this interface.
    """
    
    @abstractmethod
    def get_tool_name(self) -> str:
        """
        Return the name of the monitoring tool.
        
        Returns:
            str: Tool name (e.g., "CLOUDWATCH", "SENTRY", "DATADOG")
        """
        pass
    
    @abstractmethod
    def validate_connection(self) -> bool:
        """
        Validate connection to the monitoring tool.
        
        Returns:
            bool: True if connection successful, False otherwise
            
        Raises:
            ValueError: If required configuration is missing
            ConnectionError: If monitoring tool is unreachable
        """
        pass
    
    @abstractmethod
    def fetch_errors_since(self, since_timestamp: str) -> List[UnifiedError]:
        """
        Fetch errors from the monitoring tool since a given timestamp.
        
        Args:
            since_timestamp: ISO 8601 timestamp (YYYY-MM-DDTHH:MM:SSZ)
            
        Returns:
            List[UnifiedError]: List of errors in unified format
            
        Raises:
            ConnectionError: If API call fails
        """
        pass
