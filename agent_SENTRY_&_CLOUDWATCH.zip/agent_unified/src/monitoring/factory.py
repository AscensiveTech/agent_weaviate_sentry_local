"""Factory for creating monitoring tool instances."""
from typing import Dict, Type

from src.config import get_config
from src.exceptions import ConfigurationError
from src.monitoring.base import MonitoringToolInterface
from src.monitoring.cloudwatch import CloudWatchMonitor
from src.monitoring.sentry import SentryMonitor


class MonitoringToolFactory:
    """Factory for creating monitoring tool instances based on configuration."""
    
    _TOOL_REGISTRY: Dict[str, Type[MonitoringToolInterface]] = {
        "CLOUDWATCH": CloudWatchMonitor,
        "SENTRY": SentryMonitor,
    }
    
    @classmethod
    def create(cls, tool_type: str) -> MonitoringToolInterface:
        """
        Create a monitoring tool instance.
        
        Args:
            tool_type: Tool type identifier (CLOUDWATCH, SENTRY, etc.)
        
        Returns:
            Configured monitoring tool instance.
        
        Raises:
            ConfigurationError: If tool type is unsupported.
        """
        tool_type = tool_type.upper()
        
        if tool_type not in cls._TOOL_REGISTRY:
            supported = ", ".join(cls._TOOL_REGISTRY.keys())
            raise ConfigurationError(
                f"Unsupported monitoring tool: {tool_type}. "
                f"Supported tools: {supported}"
            )
        
        tool_class = cls._TOOL_REGISTRY[tool_type]
        return tool_class()
    
    @classmethod
    def register_tool(
        cls,
        tool_type: str,
        tool_class: Type[MonitoringToolInterface]
    ):
        """
        Register a custom monitoring tool.
        
        Args:
            tool_type: Tool type identifier.
            tool_class: Tool class implementing MonitoringToolInterface.
        """
        cls._TOOL_REGISTRY[tool_type.upper()] = tool_class
    
    @classmethod
    def get_supported_tools(cls) -> list[str]:
        """Get list of supported monitoring tools."""
        return list(cls._TOOL_REGISTRY.keys())
