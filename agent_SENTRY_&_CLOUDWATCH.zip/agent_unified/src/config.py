"""Configuration management for the error monitoring agent."""
import os
from typing import Optional
from dataclasses import dataclass, field

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


@dataclass
class LLMConfig:
    """Configuration for Large Language Model."""
    
    model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "gpt-4o"))
    temperature: float = field(default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0")))
    api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    
    def __post_init__(self):
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY must be set in environment")


@dataclass
class AWSConfig:
    """Configuration for AWS services."""
    
    region: str = field(default_factory=lambda: os.getenv("AWS_REGION", "us-east-1"))
    access_key_id: Optional[str] = field(default_factory=lambda: os.getenv("AWS_ACCESS_KEY_ID"))
    secret_access_key: Optional[str] = field(default_factory=lambda: os.getenv("AWS_SECRET_ACCESS_KEY"))
    
    def __post_init__(self):
        if self.region.lower() == "global":
            raise ValueError("AWS_REGION cannot be 'Global'. Please specify a valid region like 'us-east-1'")
    
    def has_credentials(self) -> bool:
        """Check if AWS credentials are configured."""
        return bool(self.access_key_id and self.secret_access_key)


@dataclass
class CloudWatchConfig:
    """Configuration for CloudWatch monitoring."""
    
    log_group: str = field(default_factory=lambda: os.getenv("CLOUDWATCH_LOG_GROUP", ""))
    filter_pattern: Optional[str] = field(default_factory=lambda: os.getenv("CLOUDWATCH_FILTER_PATTERN"))
    
    def __post_init__(self):
        if not self.log_group:
            raise ValueError("CLOUDWATCH_LOG_GROUP must be set in environment")
    
    def is_query_all(self) -> bool:
        """Check if configured to query all log groups."""
        return self.log_group.upper() == "ALL"


@dataclass
class SentryConfig:
    """Configuration for Sentry monitoring."""
    
    auth_token: str = field(default_factory=lambda: os.getenv("SENTRY_AUTH_TOKEN", ""))
    org_slug: str = field(default_factory=lambda: os.getenv("SENTRY_ORG_SLUG", ""))
    project_slug: str = field(default_factory=lambda: os.getenv("SENTRY_PROJECT_SLUG", ""))
    dsn: Optional[str] = field(default_factory=lambda: os.getenv("SENTRY_DSN"))
    
    def __post_init__(self):
        if not all([self.auth_token, self.org_slug, self.project_slug]):
            raise ValueError("SENTRY_AUTH_TOKEN, SENTRY_ORG_SLUG, and SENTRY_PROJECT_SLUG must be set")


@dataclass
class WeaviateConfig:
    """Configuration for Weaviate vector database."""
    
    url: str = field(default_factory=lambda: os.getenv("WEAVIATE_URL", ""))
    grpc_url: str = field(default_factory=lambda: os.getenv("WEAVIATE_GRPC", ""))
    api_key: str = field(default_factory=lambda: os.getenv("WEAVIATE_API_KEY", ""))
    
    def __post_init__(self):
        if not all([self.url, self.api_key]):
            raise ValueError("WEAVIATE_URL and WEAVIATE_API_KEY must be set in environment")


@dataclass
class SearchToolsConfig:
    """Configuration for search tools (optional)."""
    
    tavily_api_key: Optional[str] = field(default_factory=lambda: os.getenv("TAVILY_API_KEY"))
    context7_api_key: Optional[str] = field(default_factory=lambda: os.getenv("CONTEXT7_API_KEY"))
    github_token: Optional[str] = field(default_factory=lambda: os.getenv("GITHUB_TOKEN"))


@dataclass
class AppConfig:
    """Main application configuration."""
    
    monitoring_tool: str = field(default_factory=lambda: os.getenv("MONITORING_TOOL", "").upper())
    lookback_minutes: Optional[int] = field(default_factory=lambda: 
        int(os.getenv("LOOKBACK_MINUTES")) if os.getenv("LOOKBACK_MINUTES") else None
    )
    
    llm: LLMConfig = field(default_factory=LLMConfig)
    aws: AWSConfig = field(default_factory=AWSConfig)
    cloudwatch: Optional[CloudWatchConfig] = None
    sentry: Optional[SentryConfig] = None
    weaviate: WeaviateConfig = field(default_factory=WeaviateConfig)
    search_tools: SearchToolsConfig = field(default_factory=SearchToolsConfig)
    
    def __post_init__(self):
        if not self.monitoring_tool:
            raise ValueError("MONITORING_TOOL must be set in environment")
        
        if self.monitoring_tool not in ["CLOUDWATCH", "SENTRY"]:
            raise ValueError(f"Unsupported MONITORING_TOOL: {self.monitoring_tool}")
        
        # Initialize monitoring-specific config
        if self.monitoring_tool == "CLOUDWATCH":
            self.cloudwatch = CloudWatchConfig()
        elif self.monitoring_tool == "SENTRY":
            self.sentry = SentryConfig()
    
    @classmethod
    def from_env(cls) -> "AppConfig":
        """Create configuration from environment variables."""
        return cls()


# Singleton instance
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    """Get the application configuration singleton."""
    global _config
    if _config is None:
        _config = AppConfig.from_env()
    return _config


def reload_config() -> AppConfig:
    """Reload configuration from environment (useful for testing)."""
    global _config
    load_dotenv(override=True)
    _config = AppConfig.from_env()
    return _config
