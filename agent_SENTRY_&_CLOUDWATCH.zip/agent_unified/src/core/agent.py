"""Pure agent logic - database and tool agnostic."""
import logging
from typing import Optional, List, Annotated, TypedDict, Callable, Dict, Any
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END, START
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from pydantic import BaseModel, Field

from src.tools import get_all_tools, get_tool


class DebugRequest(BaseModel):
    """Request model for debugging an error"""
    project: str = Field(default="unknown", description="Project name")
    title: Optional[str] = Field(None, description="Error title")
    error_type: Optional[str] = Field(None, description="Error type/code")
    description: str = Field(..., description="Error description")
    environment: Optional[str] = Field(None, description="Environment (production, development, etc.)")


class DebugResponse(BaseModel):
    """Response model for debugging result"""
    success: bool
    recommendation: Optional[str] = None
    steps: Optional[List[str]] = None
    error: Optional[str] = None


# --- DATA MODELS ---
class ErrorInput(BaseModel):
    """Generic error input model with normalization support."""
    # Existing fields
    project: str = Field(..., description="The project slug, e.g., 'python'.")
    title: Optional[str] = Field(None, description="The human-readable title of the error.")
    error_code: Optional[str] = Field(None, description="The specific error code, e.g., '404 Not Found', 'TypeError'.")
    error_description: str = Field(..., description="A detailed description of the error message and context.")
    last_seen: str = Field(..., description="The timestamp when the error was last seen.")
    environment: Optional[str] = Field(None, description="The environment, e.g., 'production', 'development'.")
    release: Optional[str] = Field(None, description="The release version of the code.")
    culprit: Optional[str] = Field(None, description="The function or file where the error occurred.")
    stacktrace_files: Optional[List[str]] = Field(None, description="List of files from the stacktrace.")
    
    # Normalization fields
    source_tool: str = Field(..., description="Monitoring tool origin: CLOUDWATCH, SENTRY, DATADOG, LOKI, NEWRELIC")
    severity: Optional[str] = Field(None, description="Raw severity from source tool (not standardized)")
    error_fingerprint: str = Field(..., description="Hash for deduplication")
    occurrence_count: int = Field(1, description="Number of times error occurred in batch")
    first_seen: Optional[str] = Field(None, description="Timestamp of first occurrence")
    context_metadata: Optional[dict] = Field(None, description="Tool-specific metadata: stacktraces, IDs, traces")
    tech_stack: Optional[dict] = Field(None, description="Technology stack: languages, frameworks, host, database, etc.")


class Solution(BaseModel):
    """Solution output model."""
    recommendation: str = Field(..., description="A concise, high-level recommendation to fix the issue. If insufficient information, explicitly state: 'INSUFFICIENT_INFORMATION: <reason>'")
    troubleshooting_steps: List[str] = Field(..., description="A list of concrete, step-by-step instructions to resolve the error. Empty list if insufficient information.")


class AgentState(TypedDict):
    """Agent state for LangGraph."""
    messages: Annotated[List[BaseMessage], add_messages]
    error_input: ErrorInput
    solution: Optional[Solution]
    solution_from_db: bool
    is_resolved: Optional[bool]
    similar_solutions: Optional[List[dict]]  # Similar errors from semantic search
    rejected_solutions_context: Optional[str]  # Formatted context of rejected solutions


class DebuggingAgent:
    """
    Pure debugging agent with dependency injection.
    
    This agent is completely agnostic to:
    - Vector database implementation (Weaviate, Pinecone, ChromaDB, etc.)
    - Monitoring tool (Sentry, Datadog, New Relic, etc.)
    - Tools used (automatically loaded from tools/ directory)
    
    All external dependencies are injected through the constructor.
    """
    
    def __init__(
        self,
        llm_model: str = "gpt-4o",
        llm_temperature: float = 0,
        tool_names: Optional[List[str]] = None,
        vector_db_search: Optional[Callable[[str], Optional[Dict[str, Any]]]] = None,
        vector_db_store: Optional[Callable[[ErrorInput, Solution, bool], bool]] = None,
    ):
        """
        Initialize the debugging agent.
        
        Args:
            llm_model: The LLM model to use
            llm_temperature: Temperature for LLM responses
            tool_names: List of tool names to use (if None, uses all available tools)
                       Examples: ['search_stackoverflow', 'search_github_issues']
            vector_db_search: Function to search for similar solutions
            vector_db_store: Function to store solutions
        """
        self.llm = ChatOpenAI(model=llm_model, temperature=llm_temperature)
        
        # Load tools dynamically
        if tool_names:
            self.tools = [get_tool(name) for name in tool_names if get_tool(name)]
            if len(self.tools) != len(tool_names):
                missing = set(tool_names) - {t.name for t in self.tools}
                logging.warning(f"Some tools not found: {missing}")
        else:
            self.tools = get_all_tools()
        
        logging.info(f"Loaded {len(self.tools)} tools: {[t.name for t in self.tools]}")
        
        self.vector_db_search = vector_db_search
        self.vector_db_store = vector_db_store
        self.graph = self._build_graph()
    
    def _format_rejected_solutions(self, rejected_solutions: List[dict]) -> str:
        """Format rejected solutions as context for LLM to avoid similar approaches."""
        if not rejected_solutions:
            return ""
        
        context_parts = ["**⚠️ PREVIOUSLY REJECTED SOLUTIONS - DO NOT REPEAT THESE APPROACHES:**\n"]
        
        for idx, sol in enumerate(rejected_solutions, 1):
            recommendation = sol.get("solution_recommendation", "N/A")
            feedback = sol.get("feedback", "No feedback provided")
            similarity = sol.get("similarity", 0.0)
            
            context_parts.append(f"\n{idx}. **Rejected Solution** (similarity: {similarity:.1%}):")
            context_parts.append(f"   - **What was suggested:** {recommendation[:200]}...")
            context_parts.append(f"   - **Why it was rejected:** {feedback}")
            context_parts.append(f"   - **Action:** Avoid this approach and try different angle\n")
        
        return "\n".join(context_parts)
    
    def _format_similar_solutions(self, similar_solutions: List[dict]) -> str:
        """Format similar solutions as context to help LLM synthesize better solution."""
        if not similar_solutions:
            return ""
        
        context_parts = ["**📚 SIMILAR HISTORICAL ERRORS FOR REFERENCE:**\n"]
        
        for idx, sol in enumerate(similar_solutions, 1):
            recommendation = sol.get("solution_recommendation", "N/A")
            similarity = sol.get("similarity", 0.0)
            rating = sol.get("rating", 0)
            
            status_emoji = "✅" if rating == 1 else "❓"
            context_parts.append(f"\n{idx}. {status_emoji} **Similar Error** (similarity: {similarity:.1%}):")
            context_parts.append(f"   - **Solution:** {recommendation[:250]}...")
            if rating == 1:
                context_parts.append(f"   - **Status:** Solved by user")
        
        context_parts.append("\n**Use these as inspiration but adapt to the specific error context.**\n")
        return "\n".join(context_parts)
    
    def _format_tech_stack(self, tech_stack: Optional[dict]) -> str:
        """Format tech stack info for LLM context."""
        if not tech_stack:
            return ""
        
        import json
        try:
            if isinstance(tech_stack, str):
                tech_stack = json.loads(tech_stack)
        except:
            return ""
        
        if not tech_stack or tech_stack == {}:
            return ""
        
        parts = ["**🔧 TECHNOLOGY STACK:**"]
        
        if "languages" in tech_stack:
            parts.append(f"  - Languages: {', '.join(tech_stack['languages'])}")
        if "frameworks" in tech_stack:
            parts.append(f"  - Frameworks: {', '.join(tech_stack['frameworks'])}")
        if "host" in tech_stack:
            parts.append(f"  - Host/Platform: {tech_stack['host']}")
        if "database" in tech_stack:
            parts.append(f"  - Database: {tech_stack['database']}")
        if "cloud_provider" in tech_stack:
            parts.append(f"  - Cloud: {tech_stack['cloud_provider']}")
        
        parts.append("\n**Focus searches and solutions on this tech stack.**\n")
        return "\n".join(parts)
    
    def _build_graph(self) -> StateGraph:
        """Build the agent graph with injected dependencies."""
        
        def check_db_node(state: AgentState) -> dict:
            """Check database for similar errors using semantic search with feedback ranking."""
            logging.info("---1. CHECKING DATABASE FOR SIMILAR ERRORS---")
            error_input = state["error_input"]
            
            # If no vector DB search function provided, skip DB check
            if not self.vector_db_search:
                logging.info("---⚠️ NO VECTOR DB CONFIGURED. SKIPPING DB CHECK.---")
                return {"solution_from_db": False, "similar_solutions": None, "rejected_solutions_context": None}
            
            try:
                # Import the enhanced search functions
                from src.vector_db.weaviate_client import fetch_similar_solutions_multi, rank_solutions_by_feedback
                
                # Fetch multiple similar solutions (threshold 0.7 = 70%)
                similar_solutions = fetch_similar_solutions_multi(
                    error_description=error_input.error_description,
                    limit=5,
                    min_threshold=0.7,
                    include_metadata=True
                )
                
                if not similar_solutions:
                    logging.info("---⚠️ NO MATCH FOUND IN DB (threshold >= 0.7).---")
                    return {"solution_from_db": False, "similar_solutions": None, "rejected_solutions_context": None}
                
                # Rank by feedback
                ranked_solutions = rank_solutions_by_feedback(similar_solutions)
                
                # Get the top-ranked solution
                top_solution = ranked_solutions[0]
                similarity = top_solution.get("similarity", 0.0)
                rating = top_solution.get("rating", 0)
                
                logging.info(f"Found {len(ranked_solutions)} similar solutions. Top: similarity={similarity:.3f}, rating={rating}")
                
                # Simplified logic:
                # - If no user feedback (rating=0): rely on similarity threshold (>= 0.8)
                # - If has user feedback (rating>0): check both similarity >= 0.8 AND rating > 4
                use_cached = False
                if rating == 0:
                    # No feedback: trust high similarity
                    use_cached = similarity >= 0.8
                    if use_cached:
                        logging.info(f"---✅ HIGH SIMILARITY ({similarity:.1%}), NO FEEDBACK. USING CACHED SOLUTION.---")
                else:
                    # Has feedback: require high similarity AND high rating
                    use_cached = similarity >= 0.8 and rating >= 4
                    if use_cached:
                        logging.info(f"---✅ HIGH SIMILARITY ({similarity:.1%}) + HIGH RATING ({rating}/5). USING CACHED SOLUTION.---")
                
                if use_cached:
                    # Use cached solution directly
                    found_solution = Solution(
                        recommendation=top_solution.get("solution_recommendation"),
                        troubleshooting_steps=top_solution.get("solution_steps", [])
                    )
                    
                    # Build context of other similar solutions (excluding low-rated ones)
                    other_solutions = [s for s in ranked_solutions[1:] if s.get("rating", 0) != 0]
                    
                    return {
                        "solution": found_solution,
                        "solution_from_db": True,
                        "is_resolved": top_solution.get("resolved", False),
                        "similar_solutions": other_solutions[:3],  # Keep top 3 for reference
                        "rejected_solutions_context": None
                    }
                else:
                    # Medium confidence: pass all similar solutions to LLM for synthesis
                    logging.info("---⚠️ MEDIUM CONFIDENCE. PASSING SIMILAR SOLUTIONS TO LLM FOR SYNTHESIS.---")
                    
                    # Separate rejected solutions (rating=0 with feedback)
                    rejected = [s for s in ranked_solutions if s.get("rating", 0) == 0 and s.get("feedback", "").strip()]
                    accepted = [s for s in ranked_solutions if s.get("rating", 0) == 1]
                    uncertain = [s for s in ranked_solutions if s.get("rating", 0) == 0 and not s.get("feedback", "").strip()]
                    
                    # Format rejected solutions context
                    rejected_context = self._format_rejected_solutions(rejected) if rejected else None
                    
                    return {
                        "solution_from_db": False,
                        "similar_solutions": accepted + uncertain,  # Pass non-rejected solutions
                        "rejected_solutions_context": rejected_context
                    }
                
            except Exception as e:
                logging.error(f"---❌ ERROR DURING DB QUERY: {e} ---", exc_info=True)
                return {"solution_from_db": False, "similar_solutions": None, "rejected_solutions_context": None}
        
        def query_generator_node(state: AgentState) -> dict:
            """Generate queries using LLM and tools."""
            logging.info("---2. GENERATING QUERIES---")
            error_data = state["error_input"].model_dump()
            
            # Build base error prompt
            prompt_text = (
                f"I encountered an error. Details: Project={error_data.get('project')}, "
                f"Title={error_data.get('title')}, Error={error_data.get('error_code')}, "
                f"Description={error_data.get('error_description')}, Release={error_data.get('release')}, "
                f"Environment={error_data.get('environment')}, Culprit={error_data.get('culprit')}"
            )
            if stack_files := error_data.get('stacktrace_files'):
                prompt_text += f"\n\nRelevant files from the stacktrace:\n{', '.join(stack_files)}"
            
            # Add tech stack context
            tech_stack_info = self._format_tech_stack(state["error_input"].tech_stack)
            if tech_stack_info:
                prompt_text += f"\n\n{tech_stack_info}"
            
            # Add similar solutions context
            similar_solutions_context = ""
            if state.get("similar_solutions"):
                similar_solutions_context = self._format_similar_solutions(state["similar_solutions"])
                prompt_text += f"\n\n{similar_solutions_context}"
            
            # Add rejected solutions warning
            if state.get("rejected_solutions_context"):
                prompt_text += f"\n\n{state['rejected_solutions_context']}"
            
            # Build dynamic tool usage guidelines based on available tools
            tool_guidelines = []
            tool_names = [t.name for t in self.tools]
            if 'context7_search' in tool_names:
                tool_guidelines.append("   - `context7_search`: Use for official documentation lookup")
            if 'search_developer_forums' in tool_names:
                tool_guidelines.append("   - `search_developer_forums`: **IMPORTANT:** Use this for technology-specific community solutions. Tailor queries to the tech stack.")
            if 'search_stackoverflow' in tool_names:
                tool_guidelines.append("   - `search_stackoverflow`: Use for general programming questions. Include framework/language in query.")
            if 'search_github_issues' in tool_names:
                tool_guidelines.append("   - `search_github_issues`: Use for known bugs or library-specific issues. Use library/framework names from tech stack.")
            if 'search_web' in tool_names:
                tool_guidelines.append("   - `search_web`: Use as last resort for general web resources")
            
            tools_section = "\n".join(tool_guidelines) if tool_guidelines else "   - Use available tools wisely"
            
            # Separate last-resort tool
            monitoring_context_available = 'fetch_monitoring_context' in tool_names
            
            system_message = f"""You are an expert SRE helping debug production issues.

                **CRITICAL RULES:**
                1. **Answer from knowledge FIRST**: If you can confidently explain the error and provide guidance using your internal knowledge, do so immediately WITHOUT using any tools.
                   - Common programming errors (NullPointerException, TypeError, syntax errors)
                   - Well-known framework issues (React, Django, Express, Spring Boot)
                   - Standard cloud service errors (AWS, Azure, GCP with documented solutions)
                   - Database errors (connection issues, timeouts, constraint violations)
                   - Most production errors are common patterns you already know
                
                2. **Use tools ONLY when necessary**: Use tools only if:
                   - The error requires recent documentation or version-specific fixes
                   - You need to find similar production issues and their resolutions
                   - The error is obscure or requires community battle-tested solutions
                
                3. **NEVER guess or hallucinate**: If unsure after checking knowledge and tools, explicitly state uncertainty. Do NOT invent:
                   - Fake API endpoints, functions, or methods
                   - Non-existent incident reports or documentation
                   - Speculative solutions without evidence
                
                4. **Available Tools** (use only when knowledge insufficient):
                {tools_section}
                
                5. **When using tools**: Base your guidance STRICTLY on the retrieved content. Focus on patterns from real production incidents.
                
                6. **Production context**: Always consider impact on live systems and provide safe, tested approaches.
                
                7. **Tech Stack Awareness**: When searching, ALWAYS include the relevant technology from the tech stack in your queries (e.g., "nodejs express", "python django", "aws lambda").
                
                8. **Learn from User Feedback**: If rejected solutions are shown, understand WHY they were rejected and take a completely different approach.
                
                **DECISION FLOW - FOLLOW IN ORDER:**
                Step 1: Can you solve from internal knowledge? → Provide solution immediately
                Step 2: Need external information? → Use search tools (context7, forums, stackoverflow, github, web)
                Step 3: Still insufficient information after searching? → {"Use `fetch_monitoring_context` to gather additional context (surrounding logs/events), then retry solving" if monitoring_context_available else "Return INSUFFICIENT_INFORMATION"}
                {"Step 4: After analyzing monitoring context, still cannot solve? → Return INSUFFICIENT_INFORMATION with explanation" if monitoring_context_available else ""}
                
                {"**ADDITIONAL CONTEXT TOOL: fetch_monitoring_context**" if monitoring_context_available else ""}
                {"When search tools don't provide enough information, use this to get more context:" if monitoring_context_available else ""}
                {"- Extracts 5-10 surrounding logs/events from the monitoring system" if monitoring_context_available else ""}
                {"- Helps understand the error sequence and what led to the failure" if monitoring_context_available else ""}
                {"- Check error's context_metadata for event_id or issue_id field" if monitoring_context_available else ""}
                {"- Call: fetch_monitoring_context(event_identifier=<value_from_context_metadata>)" if monitoring_context_available else ""}
                {"- Use the additional context to provide a more informed solution" if monitoring_context_available else ""}

                **Response quality**: Provide context-rich guidance that helps engineers understand and safely resolve issues. Prioritize official docs and proven solutions.
            """
            query_generator_prompt = ChatPromptTemplate.from_messages([
                ("system", system_message),
                ("human", "{problem_description}")
            ])
            chain = query_generator_prompt | self.llm.bind_tools(self.tools)
            response = chain.invoke({"problem_description": prompt_text})
            return {"messages": [response]}
        
        tool_executor_node = ToolNode(self.tools) if self.tools else None
        
        def solution_synthesizer_node(state: AgentState) -> dict:
            """Synthesize solution from tool results."""
            logging.info("\n---3. FETCHED TOOL RESULTS---")
            from langchain_core.messages import ToolMessage
            for msg in state["messages"]:
                if isinstance(msg, ToolMessage):
                    tool_name = msg.name
                    tool_output = msg.content
                    logging.info(f"\nTool: {tool_name}\nResult:\n{tool_output[:500]}...")
            
            logging.info("---4. SYNTHESIZING NEW STRUCTURED SOLUTION---")
            
            # Build context for solution synthesis
            synthesis_context = ""
            if state.get("similar_solutions"):
                synthesis_context = self._format_similar_solutions(state["similar_solutions"])
            if state.get("rejected_solutions_context"):
                synthesis_context += f"\n\n{state['rejected_solutions_context']}"
            
            synthesizer_llm = self.llm.with_structured_output(Solution)
            system_prompt = (
                "You are synthesizing a solution for: {error_input}\n\n"
                "**Instructions:**\n"
                "1. Use ONLY the tool results provided - do not add information from memory\n"
                "2. Prioritize official documentation over community sources\n"
                "3. Base each step on authoritative content (official docs, verified solutions)\n\n"
                "**Solution Requirements:**\n"
                "- Provide solution ONLY if: Official docs OR multiple authoritative sources confirm it\n"
                "- If insufficient information: Set recommendation to 'INSUFFICIENT_INFORMATION: <reason>' and troubleshooting_steps to []\n\n"
                "**What Qualifies as Valid Solution:**\n"
                "✅ Official documentation with exact error and solution\n"
                "✅ Multiple Stack Overflow answers (50+ votes) confirming same fix\n"
                "✅ GitHub issue showing bug acknowledged and fixed\n"
                "✅ Production incident reports with verified resolution\n\n"
                "**Insufficient Information (refuse):**\n"
                "❌ Conflicting information between sources\n"
                "❌ General advice not specific to this error\n"
                "❌ Unclear error context, cannot determine root cause\n\n"
                "**Remember:** Better to refuse than provide uncertain guidance in production."
            )
            
            # Add similar solutions context to prompt if available
            if synthesis_context:
                system_prompt += f"\n\n{synthesis_context}"
            
            solution_prompt = ChatPromptTemplate.from_messages([
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="messages")
            ])
            chain = solution_prompt | synthesizer_llm
            solution = chain.invoke({
                "messages": state["messages"],
                "error_input": state["error_input"].model_dump_json(),
            })
            return {"solution": solution, "solution_from_db": False}
        
        def should_run_llm(state: AgentState) -> str:
            """Decide whether to use LLM or return cached solution."""
            return "end" if state.get("solution_from_db") else "query_generator"
        
        # Build the graph
        builder = StateGraph(AgentState)
        builder.add_node("check_db", check_db_node)
        builder.add_node("query_generator", query_generator_node)
        if tool_executor_node:
            builder.add_node("tool_executor", tool_executor_node)
        builder.add_node("solution_synthesizer", solution_synthesizer_node)
        
        builder.add_edge(START, "check_db")
        builder.add_conditional_edges("check_db", should_run_llm, {"end": END, "query_generator": "query_generator"})
        
        if tool_executor_node:
            builder.add_edge("query_generator", "tool_executor")
            builder.add_edge("tool_executor", "solution_synthesizer")
        else:
            builder.add_edge("query_generator", "solution_synthesizer")
        
        builder.add_edge("solution_synthesizer", END)
        
        return builder.compile()
    
    def solve(self, error_input: ErrorInput, initial_messages: Optional[List[BaseMessage]] = None) -> Dict[str, Any]:
        """
        Solve an error using the agent.
        
        Args:
            error_input: The error to solve
            initial_messages: Optional initial messages for the agent
            
        Returns:
            Final state dictionary with solution
        """
        initial_state = {
            "messages": initial_messages or [HumanMessage(content=error_input.model_dump_json())],
            "error_input": error_input,
            "solution": None,
            "solution_from_db": False,
            "is_resolved": False,
        }
        
        final_state = self.graph.invoke(initial_state)
        
        # Store solution if store function provided and solution exists
        storage_success = False
        if self.vector_db_store and final_state.get("solution"):
            try:
                result = self.vector_db_store(
                    error_input,
                    final_state["solution"],
                    final_state.get("is_resolved", False)
                )
                if result:
                    storage_success = True
                    logging.info("✅ Solution stored in vector database")
                else:
                    logging.error("❌ Failed to store solution in vector database")
                    raise RuntimeError("Vector database storage failed")
            except Exception as e:
                logging.error(f"❌ CRITICAL: Failed to store solution: {e}")
                raise RuntimeError(f"Solution storage failed: {e}")
        
        # Add storage success flag to final state
        final_state["storage_success"] = storage_success
        
        return final_state
