"""
Tool registry for the debugging agent.
Tools are automatically discovered and loaded from this directory.
"""
import os
import importlib
import inspect
from typing import List
from langchain_core.tools import BaseTool

# Registry of all available tools
_tool_registry = {}


def register_tool(tool: BaseTool):
    """Register a tool in the global registry."""
    _tool_registry[tool.name] = tool
    return tool


def get_tool(tool_name: str) -> BaseTool:
    """Get a specific tool by name."""
    return _tool_registry.get(tool_name)


def get_all_tools() -> List[BaseTool]:
    """Get all registered tools."""
    return list(_tool_registry.values())


def load_tools():
    """
    Automatically discover and load all tools from the tools directory.
    Each tool file should export a tool decorated with @tool from langchain.
    """
    tools_dir = os.path.dirname(__file__)
    
    for filename in os.listdir(tools_dir):
        if filename.endswith('.py') and not filename.startswith('_'):
            module_name = filename[:-3]
            try:
                module = importlib.import_module(f'src.tools.{module_name}')
                
                # Find all tool objects in the module
                for name, obj in inspect.getmembers(module):
                    if isinstance(obj, BaseTool) and not name.startswith('_'):
                        register_tool(obj)
            except Exception as e:
                print(f"Warning: Failed to load tool from {filename}: {e}")


# Auto-load all tools when the package is imported
load_tools()
