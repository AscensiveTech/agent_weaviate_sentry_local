"""GitHub issues search tool for finding known bugs and solutions."""
import os
import requests
import time
from typing import Optional
from dotenv import load_dotenv
from langchain_core.tools import tool
from src.tools._shared import truncate

load_dotenv()
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")


@tool
def search_github_issues(query: str, repo: Optional[str] = None, max_results: int = 3) -> str:
    """
    Searches GitHub issues for a query, returning title, URL, state, and full issue body.
    Requires a GITHUB_TOKEN environment variable.
    
    Args:
        query: The search query string
        repo: Optional repository in format 'owner/repo' (e.g., 'facebook/react')
        max_results: Maximum number of results to return (default: 3)
    
    Returns:
        Formatted string with GitHub issue details
    """
    if not GITHUB_TOKEN:
        return "Error: GITHUB_TOKEN is not configured. Please set it in your .env file."
    
    if not query or not query.strip():
        return "Error: Query cannot be empty."
    
    max_results = min(max(1, max_results), 5)  # Limit between 1-5

    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "DebuggingAgent",
        "Authorization": f"token {GITHUB_TOKEN}",
        "X-GitHub-Api-Version": "2022-11-28"
    }
    
    # Build search query
    base_query = f"is:issue {query.strip()}"
    if repo:
        if '/' not in repo:
            return f"Error: Invalid repo format '{repo}'. Use 'owner/repo' format (e.g., 'facebook/react')."
        base_query += f" repo:{repo}"

    params = {
        "q": base_query,
        "sort": "relevance",
        "order": "desc",
        "per_page": max_results
    }

    try:
        # Search with retry logic
        for attempt in range(2):
            res = requests.get(
                "https://api.github.com/search/issues",
                headers=headers,
                params=params,
                timeout=10
            )
            
            # Handle rate limiting
            if res.status_code == 403:
                rate_limit_remaining = res.headers.get('X-RateLimit-Remaining', '0')
                if rate_limit_remaining == '0':
                    reset_time = res.headers.get('X-RateLimit-Reset', 'unknown')
                    return f"GitHub API rate limit exceeded. Resets at timestamp: {reset_time}"
                if attempt == 0:
                    time.sleep(1)
                    continue
            
            # Handle secondary rate limit (abuse detection)
            if res.status_code == 429:
                if attempt == 0:
                    retry_after = int(res.headers.get('Retry-After', 2))
                    time.sleep(retry_after)
                    continue
                return "GitHub API secondary rate limit exceeded. Please try again later."
            
            res.raise_for_status()
            break
        
        data = res.json()
        issues = data.get("items", [])
        total_count = data.get("total_count", 0)
        
        if not issues:
            return f"No GitHub issues found for query: '{query[:50]}...'" + (f" in repo {repo}" if repo else "")

        result_strings = []
        result_strings.append(f"Found {total_count} total issues, showing top {len(issues)}:\n")
        
        for idx, issue in enumerate(issues, 1):
            title = issue.get("title", "N/A")
            url = issue.get("html_url", "N/A")
            state = issue.get("state", "unknown")
            labels = [label["name"] for label in issue.get("labels", [])[:5]]
            comments_count = issue.get("comments", 0)
            created_at = issue.get("created_at", "unknown")[:10]
            updated_at = issue.get("updated_at", "unknown")[:10]
            
            # Extract repo info from URL
            if repo:
                owner, repo_name = repo.split("/")
            else:
                parts = url.split("/")
                if len(parts) >= 5:
                    owner, repo_name = parts[3], parts[4]
                else:
                    owner, repo_name = "unknown", "unknown"
            
            issue_number = issue.get("number")

            # Fetch detailed issue with comments
            issue_url = f"https://api.github.com/repos/{owner}/{repo_name}/issues/{issue_number}"
            issue_res = requests.get(issue_url, headers=headers, timeout=10)
            issue_res.raise_for_status()
            issue_data = issue_res.json()
            
            body = issue_data.get("body", "") or "[No body content available]"
            body = body.strip()
            
            # Build result string
            result = f"Issue {idx}:\n"
            result += f"Title: {title}\n"
            result += f"Repository: {owner}/{repo_name}\n"
            result += f"URL: {url}\n"
            result += f"State: {state.upper()} | Comments: {comments_count}\n"
            result += f"Created: {created_at} | Updated: {updated_at}\n"
            if labels:
                result += f"Labels: {', '.join(labels)}\n"
            result += f"\nBody:\n{body[:1200]}{'...' if len(body) > 1200 else ''}\n"
            
            # Include top comment if available and issue has helpful comments
            if comments_count > 0 and state == "closed":
                comments_url = f"https://api.github.com/repos/{owner}/{repo_name}/issues/{issue_number}/comments"
                try:
                    comments_res = requests.get(comments_url, headers=headers, params={"per_page": 1}, timeout=5)
                    if comments_res.status_code == 200:
                        comments = comments_res.json()
                        if comments:
                            top_comment = comments[0].get("body", "")[:300]
                            if top_comment:
                                result += f"\nTop Comment:\n{top_comment}...\n"
                except:
                    pass  # Skip comments if they fail
            
            result += "-" * 40
            result_strings.append(result)

        return truncate("\n\n".join(result_strings), max_chars=3500)

    except requests.Timeout:
        return "Error: GitHub API request timed out. Please try again."
    except requests.ConnectionError:
        return "Error: Unable to connect to GitHub API. Check your internet connection."
    except requests.HTTPError as e:
        if e.response.status_code == 401:
            return "Error: GitHub authentication failed. Check your GITHUB_TOKEN."
        elif e.response.status_code == 404:
            return f"Error: Repository not found or inaccessible: {repo if repo else 'N/A'}"
        return f"Error: GitHub API returned status {e.response.status_code}: {e}"
    except Exception as e:
        return f"Error querying GitHub Issues: {type(e).__name__}: {e}"
