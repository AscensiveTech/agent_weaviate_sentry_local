"""Developer forums search tool for community solutions."""
import os
import requests
from typing import Optional
from dotenv import load_dotenv
from langchain_core.tools import tool
from src.tools._shared import truncate

load_dotenv()
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

# Known developer forum domains for filtering
FORUM_DOMAINS = [
    'reddit.com', 'discourse.org', 'discuss.python.org', 'community.',
    'forum.', 'dev.to', 'hashnode.com', 'medium.com'
]


@tool
def search_developer_forums(query: str, technology_hint: Optional[str] = None) -> str:
    """
    Searches relevant developer forums and official documentation across all technology stacks.
    Automatically enhances search with technology context when available.
    Returns ONLY the top 2 most relevant community posts/discussions.
    
    Args:
        query: The search query string
        technology_hint: Optional technology context (e.g., 'React', 'Python', 'Django')
    
    Returns:
        Top 2 forum posts with titles, URLs, and content snippets
    """
    if not TAVILY_API_KEY:
        return "Error: Tavily API key not configured for forum search. Please set TAVILY_API_KEY in your .env file."
    
    if not query or not query.strip():
        return "Error: Query cannot be empty."
    
    # Build enhanced search query
    search_terms = [query.strip()]
    
    if technology_hint and technology_hint.strip():
        search_terms.append(technology_hint.strip())
    
    # Add forum-specific keywords
    search_terms.append("forum OR discussion OR community OR Q&A")
    search_query = " ".join(search_terms)
    
    payload = {
        "api_key": TAVILY_API_KEY,
        "query": search_query,
        "max_results": 3,  # Get 3 to allow filtering
        "search_depth": "basic",
        "include_answer": False
    }
    
    try:
        resp = requests.post(
            "https://api.tavily.com/search",
            json=payload,
            timeout=15,
            headers={"Content-Type": "application/json"}
        )
        resp.raise_for_status()
        data = resp.json()
        
        # Check for API errors
        if "error" in data:
            return f"Tavily API error: {data.get('error', 'Unknown error')}"
        
        results = data.get('results', [])
        if not results:
            search_context = f" for {technology_hint}" if technology_hint else ""
            return f"No developer forum posts found for query: '{query[:50]}...'{search_context}"
        
        # Filter for forum-like domains (prefer actual forums)
        forum_results = []
        other_results = []
        
        for result in results:
            url = result.get('url', '').lower()
            is_forum = any(domain in url for domain in FORUM_DOMAINS)
            if is_forum:
                forum_results.append(result)
            else:
                other_results.append(result)
        
        # Prioritize forum results, fall back to other results
        selected_results = (forum_results + other_results)[:2]
        
        if not selected_results:
            return f"No relevant developer forum posts found for query: '{query[:50]}...'"
        
        # Format results
        result_strings = []
        tech_context = f" (Technology: {technology_hint})" if technology_hint else ""
        result_strings.append(f"Top {len(selected_results)} developer forum results{tech_context}:\n")
        
        for idx, item in enumerate(selected_results, 1):
            title = item.get('title', 'N/A')
            url = item.get('url', 'N/A')
            content = item.get('content', 'No content available')
            score = item.get('score', 0)
            
            # Identify source type
            source_type = "Forum Post"
            if 'reddit.com' in url:
                source_type = "Reddit Discussion"
            elif 'stackoverflow.com' in url:
                source_type = "Stack Overflow"
            elif 'dev.to' in url:
                source_type = "Dev.to Article"
            elif 'medium.com' in url:
                source_type = "Medium Article"
            elif 'github.com' in url:
                source_type = "GitHub Discussion"
            
            result = f"{source_type} {idx}:\n"
            result += f"Title: {title}\n"
            result += f"URL: {url}\n"
            if score:
                result += f"Relevance: {score:.2f}\n"
            
            # Clean and format content
            content = content.strip()
            if len(content) > 800:
                content = content[:800] + "..."
            
            result += f"Content:\n{content}\n"
            result += "-" * 40
            
            result_strings.append(result)
        
        return "\n\n".join(result_strings)
        
    except requests.Timeout:
        return "Error: Forum search request timed out. Please try again."
    except requests.ConnectionError:
        return "Error: Unable to connect to Tavily API. Check your internet connection."
    except requests.HTTPError as e:
        if e.response.status_code == 401:
            return "Error: Tavily API authentication failed. Check your TAVILY_API_KEY."
        elif e.response.status_code == 429:
            return "Error: Tavily API rate limit exceeded. Please try again later."
        return f"Error: Tavily API returned status {e.response.status_code}: {e}"
    except Exception as e:
        return f"Error querying developer forums: {type(e).__name__}: {e}"
