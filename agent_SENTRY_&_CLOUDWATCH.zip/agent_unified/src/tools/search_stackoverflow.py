"""Stack Overflow search tool for finding programming solutions."""
import requests
import re
import time
from typing import Optional, List
from langchain_core.tools import tool
from src.tools._shared import truncate


def _clean_html(text: str) -> str:
    """Clean HTML tags and entities from Stack Overflow content."""
    if not text:
        return text
    # Replace common HTML tags with markdown equivalents
    text = re.sub(r'<code>(.*?)</code>', r'`\1`', text, flags=re.DOTALL)
    text = re.sub(r'<pre>(.*?)</pre>', r'```\n\1\n```', text, flags=re.DOTALL)
    text = re.sub(r'<strong>(.*?)</strong>', r'**\1**', text)
    text = re.sub(r'<em>(.*?)</em>', r'*\1*', text)
    text = re.sub(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', r'[\2](\1)', text)
    # Remove remaining HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    # Clean up HTML entities
    text = text.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
    text = text.replace('&quot;', '"').replace('&#39;', "'")
    # Clean up whitespace
    text = re.sub(r'\n\s*\n', '\n\n', text)
    return text.strip()


@tool
def search_stackoverflow(query: str, tags: Optional[List[str]] = None, max_results: int = 3) -> str:
    """
    Searches Stack Overflow for questions related to a query.
    Returns title, link, question body, and top answer snippets.
    
    Args:
        query: The search query string
        tags: Optional list of tags to filter by (e.g., ['python', 'django'])
        max_results: Maximum number of results to return (default: 3)
    
    Returns:
        Formatted string with Stack Overflow questions and answers
    """
    if not query or not query.strip():
        return "Error: Query cannot be empty."
    
    max_results = min(max(1, max_results), 5)  # Limit between 1-5
    base_url = "https://api.stackexchange.com/2.3/search/advanced"
    params = {
        'order': 'desc',
        'sort': 'relevance',
        'q': query.strip(),
        'site': 'stackoverflow',
        'pagesize': max_results,
        'filter': '!9_bDDxJY5',  # Include body content
    }
    if tags:
        params['tagged'] = ";".join(t.strip() for t in tags if t.strip())

    try:
        # Initial search with retry logic
        for attempt in range(2):
            resp = requests.get(base_url, params=params, timeout=10)
            
            # Handle rate limiting
            if resp.status_code == 429:
                if attempt == 0:
                    time.sleep(1)
                    continue
                return "Stack Overflow API rate limit exceeded. Please try again later."
            
            resp.raise_for_status()
            break
        
        data = resp.json()
        
        # Check for API quota
        if data.get('quota_remaining', 1) < 10:
            print(f"Warning: Stack Overflow API quota low ({data.get('quota_remaining')} remaining)")
        
        questions = data.get('items', [])
        if not questions:
            return f"No Stack Overflow results found for query: '{query[:50]}...'"

        # Fetch detailed question data with answers
        question_ids = ";".join(str(q['question_id']) for q in questions)
        detail_url = f"https://api.stackexchange.com/2.3/questions/{question_ids}"
        detail_params = {
            'site': 'stackoverflow',
            'filter': '!9_bDDxJY5',  # Include body and answers
            'pagesize': max_results
        }
        
        detail_resp = requests.get(detail_url, params=detail_params, timeout=10)
        detail_resp.raise_for_status()
        detail_data = detail_resp.json()
        details = {item['question_id']: item for item in detail_data.get('items', [])}

        result_strings = []
        for idx, q in enumerate(questions, 1):
            detail = details.get(q['question_id'], {})
            title = q.get('title', 'N/A')
            link = q.get('link', 'N/A')
            score = q.get('score', 0)
            answer_count = q.get('answer_count', 0)
            is_answered = q.get('is_answered', False)
            
            # Clean and format the question body
            body = detail.get('body', '[No detailed body available]')
            body = _clean_html(body)
            
            # Build result string
            result = f"Result {idx}:\n"
            result += f"Title: {title}\n"
            result += f"Link: {link}\n"
            result += f"Score: {score} | Answers: {answer_count} | Accepted: {'Yes' if is_answered else 'No'}\n"
            result += f"Question:\n{body[:1000]}{'...' if len(body) > 1000 else ''}\n"
            result += "-" * 40
            
            result_strings.append(result)

        return truncate("\n\n".join(result_strings), max_chars=3000)

    except requests.Timeout:
        return "Error: Stack Overflow API request timed out. Please try again."
    except requests.ConnectionError:
        return "Error: Unable to connect to Stack Overflow API. Check your internet connection."
    except requests.HTTPError as e:
        return f"Error: Stack Overflow API returned status {e.response.status_code}: {e}"
    except Exception as e:
        return f"Error querying Stack Overflow: {type(e).__name__}: {e}"
