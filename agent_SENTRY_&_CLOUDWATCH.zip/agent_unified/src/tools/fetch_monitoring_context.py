"""
Tool for fetching additional context from monitoring systems.
Used by LLM when it needs more information to provide accurate debugging guidance.
"""
from langchain.tools import tool
from typing import Optional

# Module-level variable for monitoring tool injection
# Set by main.py before agent execution
_current_monitoring_tool: Optional[any] = None


def set_monitoring_tool(monitoring_tool):
    """Inject monitoring tool instance for use by the tool."""
    global _current_monitoring_tool
    _current_monitoring_tool = monitoring_tool


@tool
def fetch_monitoring_context(event_identifier: str) -> str:
    """
    Fetch surrounding logs/events from monitoring system when you need more context to debug.
    
    **When to use this tool:**
    - Error message is ambiguous (e.g., "exit code 137", "connection refused", "timeout")
    - You need to understand the sequence of events leading to the error
    - Error description lacks sufficient details to determine root cause
    - Want to see what happened immediately before/after the error
    
    **When NOT to use:**
    - Error already has clear stack trace and error type
    - Root cause is obvious from the error description
    - Would just add noise without providing clarity
    
    **Important:** This makes an API call to the monitoring system. Use only when genuinely uncertain.
    
    Args:
        event_identifier: Event ID from the error's context_metadata field.
                         Extract from context_metadata['event_id'] or context_metadata['issue_id']
    
    Returns:
        String containing 5-10 surrounding logs with timestamps, showing the sequence
        of events before and after the error. Helps understand root cause.
        
    Example:
        If error has context_metadata = {"event_id": "log-stream-abc:1734012345000"},
        call: fetch_monitoring_context(event_identifier="log-stream-abc:1734012345000")
    """
    # Check if monitoring tool is available
    if _current_monitoring_tool is None:
        return (
            "ERROR: Monitoring tool not available. "
            "This tool can only be used during active agent execution."
        )
    
    try:
        # Fetch surrounding context (typically 5-10 logs)
        context = _current_monitoring_tool.fetch_additional_context(
            event_id=event_identifier,
            limit=10
        )
        
        # Extract logs
        surrounding_logs = context.get("surrounding_logs", [])
        metadata = context.get("metadata", {})
        
        if not surrounding_logs:
            return (
                f"No surrounding logs found for event '{event_identifier}'. "
                "The event may be too old or the logs may have been deleted."
            )
        
        # Format for LLM readability
        result = f"**Surrounding Context ({len(surrounding_logs)} logs)**\n\n"
        result += "Timeline of events:\n"
        result += "=" * 60 + "\n\n"
        
        for i, log in enumerate(surrounding_logs, 1):
            result += f"{i}. {log}\n"
        
        # Add metadata if available
        if metadata:
            result += "\n" + "=" * 60 + "\n"
            result += "**Additional Metadata:**\n"
            for key, value in metadata.items():
                result += f"- {key}: {value}\n"
        
        # Add analysis hint
        result += "\n" + "=" * 60 + "\n"
        result += "**Analysis Hint:** Look for patterns in the timeline above - "
        result += "memory spikes, failed API calls, timeouts, or error cascades.\n"
        
        return result
        
    except ValueError as e:
        return (
            f"ERROR: Invalid event identifier format - {e}\n\n"
            "Expected format depends on monitoring tool:\n"
            "- CloudWatch: 'log-stream-name:timestamp_ms'\n"
            "- Sentry: 'issue_id' or 'event_uuid'"
        )
    except ConnectionError as e:
        return (
            f"ERROR: Failed to connect to monitoring system - {e}\n\n"
            "The monitoring tool may be experiencing issues or credentials may be invalid."
        )
    except Exception as e:
        return (
            f"ERROR: Unexpected error fetching context - {e}\n\n"
            "Please proceed with debugging based on available information."
        )


# Export for tool discovery
__all__ = ['fetch_monitoring_context', 'set_monitoring_tool']
