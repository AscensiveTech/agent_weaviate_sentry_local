"""Shared utilities used by multiple tools."""


def truncate(text: str, max_chars: int = 2000) -> str:
    """Trim long strings to keep LLM inputs within reasonable size."""
    if not isinstance(text, str):
        return text
    if len(text) <= max_chars:
        return text
    return f"{text[:max_chars]}\n...\n[truncated]"
