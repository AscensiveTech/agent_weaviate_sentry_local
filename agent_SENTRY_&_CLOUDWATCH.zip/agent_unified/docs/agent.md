# Agent Core Logic

## Purpose
The agent orchestrates the entire error debugging workflow using LangGraph's state machine pattern. It acts as the central decision-maker that determines whether to use cached solutions or generate new ones.

## Architecture

### State Management
The agent maintains state across multiple steps using `AgentState`, which tracks:
- Error input details
- Similar solutions found in vector DB
- Tool execution results
- Final solution

### Workflow Stages

**1. Database Check**
- Queries vector DB for similar errors (≥70% similarity threshold)
- Retrieves top matches sorted by similarity
- Applies rating-aware caching logic

**2. Caching Decision**
Two-tier logic based on user feedback:
- **No feedback (rating=0)**: Cache if similarity ≥ 80%
- **Has feedback (rating>0)**: Cache if similarity ≥ 80% AND rating ≥ 4

**3. Query Generation** (if not cached)
- LLM generates targeted search queries
- Uses error context and tech stack info
- Prioritizes internal knowledge before tools

**4. Tool Execution**
- Runs search tools in parallel
- Aggregates results from multiple sources
- Deduplicates information

**5. Solution Synthesis**
- LLM analyzes all gathered context
- Generates recommendation and troubleshooting steps
- Returns structured solution

**6. Storage**
- Persists solution to vector DB
- Includes error fingerprint for deduplication
- Stores metadata for future retrieval

## Key Components

### DebuggingAgent Class
Main orchestration class that:
- Builds LangGraph state machine
- Manages LLM temperature (0 for consistency)
- Handles vector DB dependency injection
- Coordinates tool execution

### ErrorInput Model
Normalized input with 21 fields:
- Core error details (project, title, description, environment)
- Temporal data (last_seen, first_seen)
- Debugging info (culprit, stacktrace_files)
- Metadata (source_tool, severity, fingerprint)
- Tech stack (languages, frameworks, databases)

### Solution Model
Structured output containing:
- High-level recommendation
- Step-by-step troubleshooting instructions
- "INSUFFICIENT_INFORMATION" flag when uncertain

### Tool Usage Philosophy
The agent follows this priority:
1. **Internal knowledge first** - Most errors are common patterns
2. **Search tools** - Documentation, forums, GitHub when needed
3. **Monitoring context** - Additional logs if search insufficient
4. **Refuse gracefully** - Better to say "insufficient info" than guess

## Decision Logic

### Similarity Threshold
- **0.7 (70%)**: Minimum for retrieval from vector DB
- **0.8 (80%)**: Minimum for caching/reuse

### Rating Scale
- **0**: No user feedback yet
- **1-5**: Quality rating (1=poor, 5=excellent)

### Why Rating-Aware Caching?
- High similarity alone doesn't guarantee solution quality
- User feedback provides signal about effectiveness
- Prevents reusing solutions that didn't actually work

## LangGraph Integration

### Graph Structure
```
START → check_db → [cached | not_cached]
  ↓
cached → return_cached → END
  ↓
not_cached → query_gen → search_tools → synthesize → store → END
```

### Conditional Edges
Decision points based on:
- Cached solution available?
- Tool invocations needed?
- Solution quality threshold met?

## Error Handling

### Graceful Degradation
- Works without vector DB (no caching layer)
- Continues if individual tools fail
- Returns partial results when possible

### Transparency
- Logs all decision points
- Tracks similarity scores
- Records which tools were used

## Why This Design?

### Knowledge-First Approach
LLMs have extensive training on common errors. External tools are supplements, not replacements.

### Parallel Tool Execution
Reduces latency by running searches simultaneously rather than sequentially.

### Stateful Processing
LangGraph maintains context across steps, enabling complex multi-stage reasoning.

### Dependency Injection
Vector DB and tools are injected dependencies, making the agent testable and adaptable to different backends.
