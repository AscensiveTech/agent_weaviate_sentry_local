# CloudWatch Integration

## Purpose
Fetches errors from AWS CloudWatch Logs for processing by the agent. Supports multiple log groups and uses CloudWatch Insights for efficient querying.

## Architecture

### AWS Services Used
- **CloudWatch Logs**: Log storage and management
- **CloudWatch Insights**: SQL-like query language for log analysis
- **boto3**: AWS SDK for Python

### Authentication
Three options (priority order):
1. Explicit credentials from `.env` (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
2. IAM role (when running on EC2, ECS, Lambda)
3. AWS CLI configured credentials (~/.aws/credentials)

---

## Configuration

### Required
- `AWS_REGION` or `AWS_DEFAULT_REGION`: AWS region (default: us-east-1)
- `CLOUDWATCH_LOG_GROUPS`: Log group names to query

### Log Groups Format
**Specific groups** (comma-separated):
```
/aws/lambda/func1,/aws/lambda/func2,/ecs/myapp
```

**All groups** (wildcard):
```
*
```
Queries all available log groups in the region.

### Optional
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`: Explicit credentials
- `CLOUDWATCH_FILTER_PATTERN`: Custom error keyword filter

---

## Error Detection

### Error Keywords (Hardcoded)
Based on industry standards:
- ERROR, Error (standard log level)
- FATAL, CRITICAL (high severity)
- Exception, exception (stack traces)
- Traceback (Python-specific)

**Why hardcoded?**
These patterns are consistent across logging frameworks:
- log4j (Java)
- Python logging module
- Winston (Node.js)
- Common best practices

### CloudWatch Insights Query
Generates query like:
```
fields @timestamp, @message, @logStream
| filter @message like /ERROR/ or @message like /Exception/ or @message like /FATAL/
| sort @timestamp desc
| limit 100
```

---

## Severity Mapping

### Inference from Content
CloudWatch Logs don't have structured severity levels, so we infer from log content:

- **FATAL/PANIC** → critical
- **CRITICAL/CRIT** → critical
- **ERROR/EXCEPTION** → error
- **WARN/WARNING** → warning
- **INFO** → info
- **DEBUG/TRACE** → debug
- **Default** → info (if no keyword found)

### Why RFC 5424?
Standard syslog severity levels, widely adopted:
- Consistent across platforms
- Well-documented taxonomy
- Matches Python logging levels

---

## Query Strategy

### Time-Based Filtering
Fetches errors since last processed timestamp:
1. Read last_seen from state file
2. Convert to epoch milliseconds
3. Query from last_seen to now
4. Update state file with new last_seen

### Multi-Log-Group Support
When querying multiple log groups:
1. Execute query against each log group
2. Run queries in parallel (async)
3. Aggregate results
4. Deduplicate by fingerprint

### Rate Limiting
CloudWatch Insights has quotas:
- 5 concurrent queries per region
- Query timeout: 15 minutes
- Result limit: 10,000 records per query

Adapter respects limits with:
- Sequential queries when >5 log groups
- Timeout handling
- Result pagination

---

## Context Retrieval

### Surrounding Logs
The `fetch_monitoring_context` tool retrieves ±5 minutes of logs:
1. Extract @timestamp from error event
2. Calculate time window (±5 minutes)
3. Fetch all logs in window from same log stream
4. Return chronologically sorted

### Why Log Streams?
CloudWatch groups logs by stream (typically one per container/instance):
- Keeps context relevant (same execution environment)
- Reduces noise (excludes unrelated parallel executions)
- Preserves causality chain

---

## Tech Stack Detection

### From Log Messages
Regex patterns identify:

**Languages**:
- Python: "Traceback", ".py:", "raise "
- Java: "Exception in thread", "java.lang."
- Node.js: ".js:", "UnhandledPromiseRejection"
- Go: "panic:", "runtime error"

**Frameworks**:
- Django: "django.", "DJANGO_SETTINGS"
- Spring: "org.springframework"
- Express: "express", "node_modules/express"

**Platforms**:
- Lambda: "lambda_handler", "AWS Lambda"
- Kubernetes: "k8s.io", "pod/"
- Docker: "container"

### From Log Group Names
Patterns in log group paths:
- `/aws/lambda/` → AWS Lambda
- `/ecs/` → ECS containers
- `/rds/` → RDS databases

---

## Error Parsing

### CloudWatch Log Format
Typical log entry:
```
{
  "@timestamp": "2025-12-15T10:30:00.000Z",
  "@message": "ERROR: Connection timeout in handler.py:42",
  "@logStream": "2025/12/15/[$LATEST]abc123",
  "@logGroup": "/aws/lambda/my-function"
}
```

### Extracted Fields
- **error_description**: @message field (full log line)
- **timestamp**: @timestamp (ISO 8601)
- **title**: First line of message (truncated)
- **culprit**: Extracted from "at file.py:line" patterns
- **stacktrace_files**: Files mentioned in message

### Context Metadata
Preserved for tool operations:
- Log stream name
- Log group name
- Request ID (if present)

---

## Challenges & Solutions

### Unstructured Logs
**Problem**: CloudWatch logs are free-form text, not structured JSON

**Solution**: 
- Regex-based parsing
- Best-effort field extraction
- Preserve full message in error_description

### False Positives
**Problem**: "ERROR" appears in non-error contexts ("ERROR_CODE": 0)

**Solution**:
- Keyword patterns include context (case sensitivity, word boundaries)
- Manual review of filter pattern if too many false positives
- User can override via CLOUDWATCH_FILTER_PATTERN

### Large Result Sets
**Problem**: High-traffic apps generate thousands of errors

**Solution**:
- Limit queries to 100 results
- Use incremental processing (state file)
- Deduplication reduces processing load

---

## Connection Validation

### validate_connection()
Tests connectivity before processing:
1. Create CloudWatch Logs client
2. List log groups (validates credentials)
3. Check region validity
4. Verify log groups exist

**Errors Caught**:
- Invalid credentials
- Missing permissions
- Invalid region
- Non-existent log groups

---

## Why CloudWatch?

### Native AWS Integration
No additional agents required:
- Lambda logs automatically to CloudWatch
- ECS containers send logs via awslogs driver
- EC2 instances use CloudWatch agent

### Centralized Logging
Single location for all AWS service logs:
- Lambda functions
- ECS containers
- RDS databases
- API Gateway
- Load balancers

### Cost-Effective
Pay only for:
- Log ingestion (first 5GB/month free)
- Storage (first 5GB/month free)
- Queries (pay per query)

Lower cost than third-party log aggregators for AWS-heavy deployments.
