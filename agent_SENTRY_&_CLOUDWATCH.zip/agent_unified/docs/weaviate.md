# Vector Database (Weaviate)

## Purpose
Weaviate provides semantic similarity search for solution caching. When the agent encounters a new error, it first checks if a similar error was solved before, avoiding redundant LLM calls and tool searches.

## Why Vector Database?

### Semantic Similarity
Traditional keyword search misses semantically similar errors:
- "connection timeout" vs "connection timed out" (same issue)
- "exit code 137" vs "OOMKilled" (same root cause)

Vector embeddings capture semantic meaning, finding similar errors even with different wording.

### Cost Efficiency
- Cached solutions avoid LLM API calls
- Skip expensive tool searches
- Faster response times

### Learning Over Time
The system improves as it processes more errors:
- More cached solutions
- Higher cache hit rate
- Better recommendations based on user feedback

---

## Architecture

### Storage Schema (21 Fields)

**Core Error (9 fields)**:
- project, title, error_code, error_description
- last_seen, environment, release
- culprit, stacktrace_files

**Solution (3 fields)**:
- solution_recommendation
- solution_steps
- resolved (boolean flag)

**Normalization (3 fields)**:
- source_tool (CLOUDWATCH, SENTRY, etc.)
- severity (error, critical, warning, etc.)
- context_metadata (tool-specific JSON)

**Deduplication (3 fields)**:
- error_fingerprint (SHA-256 hash)
- occurrence_count
- first_seen

**User Feedback (2 fields)**:
- rating (0-5 scale)
- feedback (text comments)

**Tech Stack (1 field)**:
- tech_stack (JSON: languages, frameworks, databases, platform)

### Vector Embeddings
- Generated via OpenAI embeddings API
- Dimensionality: 1536
- Field: error_description (most semantically rich)
- Distance metric: Cosine similarity

---

## Operations

### Search Similar Solutions
Finds errors matching the query description:
1. Generate embedding for query text
2. Perform vector similarity search
3. Return top N matches above threshold
4. Sort by similarity (highest first)

**Thresholds**:
- 0.7 (70%): Minimum for retrieval
- 0.8 (80%): Minimum for caching/reuse

### Store Solution
Persists error-solution pairs:
1. Generate embedding for error_description
2. Create DebuggingSolution object with all 21 fields
3. Store in Weaviate with vector index
4. Auto-generates UUID

### Ranking Logic (Simplified)
Previously used weighted formula: `rank_score = (similarity × 0.7) + (rating × 0.3)`

**Current approach**: Sort purely by similarity
- Agent applies rating filter separately in decision logic
- Simpler, more transparent
- Easier to reason about behavior

---

## Connection Management

### Singleton Pattern
Single client instance shared across application:
- Connection pooling for efficiency
- Automatic cleanup on exit
- Lazy initialization

### Configuration
Requires three environment variables:
- `WEAVIATE_URL`: Cluster endpoint
- `WEAVIATE_GRPC`: gRPC endpoint for efficient queries
- `WEAVIATE_API_KEY`: Authentication token

### Schema Initialization
On first run:
1. Check if DebuggingSolution class exists
2. Create schema if missing
3. Configure vector index on error_description field

---

## FastAPI Endpoints

### POST /vector-db/search
Search for similar solutions:
- Input: query (string), threshold (float 0.0-1.0)
- Output: found, solution_recommendation, steps, resolved, similarity

### GET /vector-db/health
Check database connectivity:
- Output: connected (bool), message, schema_exists (bool)

---

## Why Weaviate?

### Vector-Native
Built specifically for vector similarity search, unlike traditional databases with vector plugins.

### Cloud-Hosted
Managed service eliminates infrastructure overhead:
- No server management
- Automatic scaling
- Built-in backups

### gRPC Support
Efficient binary protocol reduces latency for high-volume queries.

### Open Source
Can self-host if needed, with commercial cloud option for convenience.

---

## Graceful Degradation

### Works Without Vector DB
If Weaviate is unavailable:
- Agent continues processing
- No cached solutions available
- All errors processed via LLM + tools
- Logs warning but doesn't crash

### Why Optional?
- New deployments may not have cached solutions yet
- Network issues shouldn't halt error processing
- System remains functional in degraded mode

---

## Data Flow

### Inbound (Search)
1. Error arrives at agent
2. Agent queries: `fetch_similar_solution(error_description, threshold=0.7)`
3. Weaviate generates embedding
4. Vector search returns top matches
5. Agent applies caching logic

### Outbound (Storage)
1. Agent generates solution
2. Calls: `store_solution_in_db(error_input, solution, is_resolved)`
3. Weaviate generates embedding
4. Solution persisted with all metadata

---

## Performance Considerations

### Embedding Cost
Each search/store generates OpenAI embeddings:
- Search: 1 embedding per query
- Store: 1 embedding per solution
- Cost: ~$0.0001 per 1K tokens (text-embedding-ada-002)

### Query Latency
Typical search: 100-300ms depending on:
- Network latency to Weaviate cluster
- Embedding generation time
- Collection size

### Scaling
Weaviate handles millions of vectors efficiently:
- Automatic sharding
- HNSW (Hierarchical Navigable Small World) index
- Sublinear search complexity
