# Search Tools

## Purpose
Tools extend the agent's knowledge by retrieving external information from documentation, community forums, issue trackers, and monitoring systems.

## Tool Registry System

### Auto-Discovery
The tool registry automatically loads all tools from the `src/tools/` directory:
- Scans for Python files (ignoring `_` prefixes)
- Extracts `BaseTool` instances
- Registers tools by name for O(1) lookup

### Why Auto-Discovery?
Adding new tools requires zero changes to the agent - just drop a new tool file in the directory.

---

## Available Tools

### 1. context7_search

**Purpose**: Search official documentation (React, Django, AWS, etc.)

**When Used**: 
- Framework-specific errors
- API usage questions
- Configuration issues

**Strengths**:
- Authoritative source (official docs)
- Up-to-date with latest versions
- Comprehensive API references

**Configuration**: Requires `CONTEXT7_API_KEY`

**Output**: Top 3 documentation snippets with URLs, truncated to 2000 chars

---

### 2. search_stackoverflow

**Purpose**: Find community-validated Q&A solutions

**When Used**:
- Common programming errors
- Implementation questions
- Best practices

**Ranking Strategy**:
Score = (question_score × 2) + (has_accepted_answer × 100) + answer_count

Prioritizes questions with:
- Accepted answers (green checkmark)
- High community votes
- Multiple quality answers

**Strengths**:
- Community validation via voting
- Working code examples
- Multiple solution approaches

**Configuration**: No API key required (public endpoint)

**Rate Limits**: 300 requests/day unauthenticated

---

### 3. search_github_issues

**Purpose**: Find known bugs and fixes in issue trackers

**When Used**:
- Library/framework-specific bugs
- Version compatibility issues
- Known regressions

**Search Strategy**:
- Searches across all public repos (unless repo specified)
- Filters by bug labels, closed state, comment count
- Prioritizes issues with accepted solutions

**Strengths**:
- Authoritative for library bugs
- Maintainer responses
- Version-specific information
- Workarounds and patches

**Configuration**: Optional `GITHUB_TOKEN` (recommended for higher rate limits)

**Rate Limits**:
- Authenticated: 5000 requests/hour
- Unauthenticated: 60 requests/hour

---

### 4. search_developer_forums

**Purpose**: Search community discussions (Reddit, Dev.to, Hashnode, Medium)

**When Used**:
- Real-world experiences
- Configuration challenges
- Environment-specific issues

**Domain Filtering**:
Results limited to: reddit.com, dev.to, hashnode.com, medium.com, discourse.org, community.*, forum.*

**Strengths**:
- Real-world solutions from practitioners
- Workarounds not in official docs
- Multiple perspectives
- Recent community trends

**Configuration**: Requires `TAVILY_API_KEY`

**Output**: Top 2 most relevant discussions

---

### 5. search_web

**Purpose**: General fallback for obscure errors

**When Used**:
- Obscure errors not in Stack Overflow/GitHub
- Vendor-specific documentation
- Tutorial articles
- Blog post walkthroughs

**Usage Pattern**: Last resort after specialized tools

**Why Sparingly?**:
Specialized sources (official docs, Stack Overflow, GitHub) provide higher quality, more targeted results.

**Configuration**: Requires `TAVILY_API_KEY`

---

### 6. fetch_monitoring_context

**Purpose**: Retrieve surrounding logs/events from monitoring system

**When Used**:
- Ambiguous error messages ("exit code 137", "timeout")
- Need event sequence context
- Error description lacks details
- Other tools insufficient

**How It Works**:
1. Extracts event_identifier from error's context_metadata
2. Calls monitoring tool's `fetch_surrounding_context()`
3. Returns ±5 minutes of logs chronologically

**Why Separate Tool?**:
- Makes API call to monitoring system (cost/latency consideration)
- Used judiciously only when needed
- Separates concerns (agent doesn't need monitoring tool details)

**Setup**: Monitoring tool instance injected by main.py before agent execution

---

## Tool Coordination

### Parallel Execution
The agent runs multiple tools simultaneously to reduce latency:
- Stack Overflow + GitHub + Forums in parallel
- Results aggregated after all complete
- Failures in one tool don't block others

### Result Truncation
All tools truncate output to 2000 chars to prevent:
- Token overflow in LLM context
- Excessive API costs
- Information overload

### Error Handling
Tools return error strings rather than raising exceptions:
- "Error: API key not configured"
- "Error: Rate limit exceeded"
- "No results found for query"

This allows the agent to continue with partial results.

---

## Shared Utilities

### truncate()
Limits text length while preserving readability:
- Adds "...\n[truncated]" indicator
- Prevents context window overflow
- Keeps responses manageable

---

## Design Principles

### Self-Describing
Each tool includes usage instructions in its docstring, enabling the LLM to understand when and how to use it.

### Fail Gracefully
Missing API keys or connection failures return error messages, not crashes.

### Stateless
Tools have no side effects or persistent state - pure functions that transform queries into results.

### Extensible
Adding new tools (Slack, Jira, Confluence, etc.) requires only:
1. Create new file with `@tool` decorator
2. Implement query → results logic
3. Tool automatically discovered and registered
