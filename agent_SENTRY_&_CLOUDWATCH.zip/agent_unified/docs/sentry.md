# Sentry Integration

## Purpose
Fetches errors from Sentry error tracking platform using their REST API. Provides structured error data with rich context like stack traces, release versions, and user feedback.

## Architecture

### Sentry Data Model
- **Organizations**: Top-level account container
- **Projects**: Individual applications or services
- **Issues**: Grouped error events (similar errors clustered together)
- **Events**: Individual error occurrences

### API Access
Uses Sentry REST API v1:
- Base URL: `https://sentry.io/api/0/`
- Authentication: Bearer token (organization-level auth token)
- Response format: JSON

---

## Configuration

### Required
- `SENTRY_AUTH_TOKEN`: API authentication token
- `SENTRY_ORG_SLUG`: Organization identifier (visible in URL)
- `SENTRY_PROJECT_SLUG`: Project identifier (visible in URL)

### Getting Credentials
1. Navigate to Sentry dashboard
2. Settings → Account → API → Auth Tokens
3. Create token with `org:read`, `project:read`, `event:read` scopes
4. Copy org slug and project slug from URL: `sentry.io/organizations/{org}/projects/{project}/`

### Optional
- `SENTRY_DSN`: For SDK integration (not used by adapter, only for application instrumentation)

---

## Severity Levels

### Official Sentry Taxonomy
Numeric levels (lower = less severe):
- **fatal (50)**: Catastrophic failures requiring immediate attention
- **error (40)**: Errors that should be investigated and fixed
- **warning (30)**: Potential issues that may lead to errors
- **info (20)**: Informational messages
- **debug (10)**: Debug-level messages for development

### Why Numbers?
Sentry uses numeric severity internally, matching Python logging:
- logging.CRITICAL = 50
- logging.ERROR = 40
- logging.WARNING = 30
- logging.INFO = 20
- logging.DEBUG = 10

Enables easy filtering and comparison.

---

## Issue Grouping

### Automatic Fingerprinting
Sentry automatically clusters similar errors into issues:
- Same error type + same stack trace → same issue
- Reduces noise (1 issue instead of 1000 events)
- Tracks occurrence count

### Fingerprint Components
Sentry generates fingerprint from:
- Exception type (ValueError, TypeError, etc.)
- Stack trace frames (file paths + line numbers)
- Error message template (dynamic values removed)

### Benefits
- Deduplication happens server-side (Sentry does it)
- Agent receives pre-grouped errors
- Occurrence counts already aggregated

---

## Data Extraction

### From Issues Endpoint
`GET /api/0/projects/{org}/{project}/issues/`

Provides:
- Issue title (human-readable summary)
- Status (unresolved, resolved, ignored)
- First/last seen timestamps
- Event count (occurrences)
- Issue fingerprint (Sentry's grouping hash)
- Metadata (culprit, level, platform)

### From Events Endpoint
`GET /api/0/issues/{issue_id}/events/`

Provides:
- Full stack traces with file paths
- Exception details (type, value, mechanism)
- Request context (URL, method, headers)
- User context (ID, IP, tags)
- Breadcrumbs (events leading to error)
- Release version
- Environment

---

## Query Strategy

### Time-Based Filtering
Fetches issues modified since last run:
1. Read last_seen from state file
2. Query: `statsPeriod=24h` or `start={last_seen}`
3. Filter: `query=is:unresolved`
4. Sort: `sort=date` (newest first)

### Status Filtering
Only processes unresolved issues:
- Skips resolved (already fixed)
- Skips ignored (acknowledged but not actionable)
- Focuses agent on active problems

### Pagination
Handles large result sets:
- Sentry returns 100 issues per page
- Uses Link header for pagination
- Limits to configurable max (default: 100 total)

---

## Stack Trace Parsing

### Structure
Sentry stack traces are nested:
```
exception.values[0].stacktrace.frames[]
```

Each frame contains:
- filename (e.g., "handler.py")
- function (e.g., "process_request")
- lineno (e.g., 42)
- context_line (actual code line)
- in_app (whether it's user code vs. library code)

### Extraction Strategy
1. Get all frames from stack trace
2. Filter to in_app frames (user code only)
3. Extract file paths
4. Identify culprit (deepest in_app frame)

### Why in_app Only?
- Focus on user code, not library internals
- Reduces noise from third-party dependencies
- Makes troubleshooting more actionable

---

## Tech Stack Detection

### From SDK Metadata
Sentry SDKs report technology information:

**event.sdk.name**:
- "sentry.python" → Python
- "sentry.javascript.browser" → JavaScript (browser)
- "sentry.javascript.node" → Node.js
- "sentry.java" → Java
- "sentry.dotnet" → .NET

**event.platform**:
- "python", "javascript", "java", "ruby", "go", "php", "csharp"

**event.contexts**:
- runtime.name: "CPython", "Node.js", "OpenJDK"
- runtime.version: "3.11.5", "18.12.0"

### From Stack Traces
File extensions and patterns:
- .py files → Python
- .js files → JavaScript
- .java files → Java
- .cs files → C#

### From Integrations
Sentry tracks framework integrations:
- Django: contexts.django present
- Flask: contexts.flask present
- Express: SDK includes "express"
- React: SDK includes "react"

---

## Context Preservation

### Rich Metadata
Sentry provides extensive context, preserved in `context_metadata`:
- **Breadcrumbs**: User actions leading to error
- **Request data**: URL, method, headers, body
- **User data**: ID, email, IP, custom attributes
- **Tags**: Custom key-value pairs
- **Extra data**: Application-specific context

### Why Preserve?
- `fetch_monitoring_context` tool can return this rich data
- Provides comprehensive debugging context
- Enables root cause analysis

---

## Release Tracking

### Version Information
Sentry tracks code versions:
- Release identifier (e.g., "v2.3.1", "abc123def")
- Deploy information (when, where, who)
- Commit hashes (Git integration)

### Use Cases
- Identify if error specific to recent release
- Track regressions between versions
- Correlate errors with deployments

### Extracted Fields
- **release**: Release identifier
- **environment**: production, staging, development

---

## Rate Limits

### Sentry API Quotas
Enforced per organization:
- Varies by plan (free, team, business, enterprise)
- Typically: 10-100 requests/second
- 429 response when exceeded

### Adapter Handling
- Respects 429 responses (backs off)
- Sequential queries (not parallel) to avoid hitting limits
- Configurable max results to limit API calls

---

## Connection Validation

### validate_connection()
Tests Sentry connectivity:
1. GET `/api/0/projects/{org}/{project}/`
2. Verifies token has proper scopes
3. Checks org and project exist
4. Validates permissions

**Errors Caught**:
- Invalid token (401)
- Missing permissions (403)
- Non-existent org/project (404)
- Network issues

---

## Why Sentry?

### Structured Errors
Unlike log aggregators, Sentry provides:
- Pre-parsed stack traces
- Automatic error grouping
- Rich contextual data
- User impact tracking

### Developer-Focused
Built specifically for error tracking:
- Issue management workflow
- Release tracking
- Performance monitoring integration
- User feedback collection

### Multi-Language Support
Single platform for polyglot stacks:
- Python, JavaScript, Java, Ruby, Go, PHP, .NET, etc.
- Consistent API across languages
- Unified error dashboard

### Context-Rich
More than just error messages:
- What the user was doing (breadcrumbs)
- What request caused the error (HTTP context)
- What code version (release tracking)
- How many users affected (stats)

---

## Comparison: Sentry vs. CloudWatch

### Sentry Strengths
- Structured error data (stack traces pre-parsed)
- Automatic grouping (server-side deduplication)
- Rich context (breadcrumbs, user data, releases)
- Cross-platform (not AWS-specific)

### CloudWatch Strengths
- Native AWS integration (no additional service)
- Lower cost for AWS-heavy workloads
- Centralized AWS logging
- No external dependency

### When to Use Sentry
- Multi-cloud or hybrid deployments
- Need rich error context
- Want built-in issue tracking
- Have polyglot stack

### When to Use CloudWatch
- AWS-only infrastructure
- Cost-sensitive
- Prefer single AWS account
- Existing CloudWatch investment
