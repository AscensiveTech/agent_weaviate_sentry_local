# Utility Modules

## config.py

### Purpose
Centralized configuration management using typed dataclasses. Loads all settings from `.env` file and provides validation.

### Configuration Sections

**LLMConfig**:
- OpenAI model name (default: gpt-4o)
- Temperature (default: 0 for consistency)
- API key (required)

**AWSConfig**:
- Region (default: us-east-1)
- Access key ID and secret (optional, falls back to IAM role)

**CloudWatchConfig**:
- Log group names (required for CloudWatch mode)
- Filter pattern (optional custom filter)

**SentryConfig**:
- Auth token, org slug, project slug (all required for Sentry mode)
- DSN (optional, for SDK integration)

**WeaviateConfig**:
- Cluster URL and API key (required)
- gRPC endpoint (required for efficient queries)

**SearchToolsConfig**:
- API keys for search tools (all optional)
- Tavily, Context7, GitHub tokens

**AppConfig**:
- Monitoring tool selection (CLOUDWATCH or SENTRY)
- Lookback window override (optional)

### Design Philosophy

**Zero-Configuration Principle**:
Sensible defaults for everything except credentials:
- Model: gpt-4o (most capable, cost-effective)
- Temperature: 0 (deterministic, consistent)
- Region: us-east-1 (largest AWS region)

**Validation on Load**:
Fails fast with clear error messages:
- Missing required keys
- Invalid values (e.g., region="Global")
- Incompatible settings

**Type Safety**:
Dataclasses provide IDE autocomplete and type checking, catching configuration errors at development time.

### Why .env Files?

**Security**:
- Never commit credentials to Git
- Easy to rotate secrets
- Different configs per environment

**Portability**:
- Same code works in dev/staging/prod
- Override via environment variables
- Docker/Kubernetes friendly

**Explicitness**:
- All configuration in one place
- Clear what can be customized
- Self-documenting

---

## exceptions.py

### Purpose
Application-specific exception hierarchy for precise error handling and debugging.

### Exception Tree

**AgentError** (base):
- Catch-all for agent-related issues
- Parent of all custom exceptions

**ConfigurationError**:
- Missing/invalid configuration
- Raised during startup
- Examples: missing API keys, invalid region

**MonitoringToolError** (base):
- Parent for monitoring-specific errors

**ConnectionError**:
- Cannot reach monitoring tool
- Network issues, wrong endpoint

**AuthenticationError**:
- Invalid credentials
- Expired tokens, insufficient permissions

**VectorDBError** (base):
- Parent for Weaviate-specific errors

**VectorDBConnectionError**:
- Cannot connect to Weaviate
- Network issues, wrong URL

**VectorDBQueryError**:
- Query execution failed
- Invalid query, timeout

**NormalizationError**:
- Error transformation failed
- Unexpected data format

**SolutionGenerationError**:
- LLM/agent failed to generate solution
- API errors, invalid responses

### Why Custom Exceptions?

**Specific Error Handling**:
Different recovery strategies for different failures:
- ConfigurationError → exit early with clear message
- VectorDBError → continue without cache
- ConnectionError → retry with backoff

**Debugging Context**:
Precise exception types reveal where failure occurred:
- Stack trace shows module
- Exception name indicates failure reason

**API Boundaries**:
External callers can catch `AgentError` to handle all agent issues uniformly, or catch specific types for targeted handling.

---

## state.py

### Purpose
Tracks last processed timestamp to enable incremental error processing. Avoids reprocessing errors from previous runs.

### State Files

**agent_state.json**:
Format: `{"lastSeen": "2025-12-15T10:30:00Z"}`
- Stores last successfully processed timestamp
- Updated after each run
- ISO 8601 format (timezone-aware)

**agent_runs.json**:
Format: `[{"run_id": "...", "timestamp": "...", "errors_processed": N}]`
- Tracks execution history
- Useful for debugging, auditing
- Not currently used by agent

### StateManager Class

**get_last_seen()**:
- Returns last processed timestamp
- Falls back to epoch (1970-01-01T00:00:00Z) if file missing
- Handles corrupted JSON gracefully

**save_last_seen(timestamp)**:
- Persists new timestamp
- Creates file if doesn't exist
- Pretty-prints JSON for readability

**save_agent_run(run_data)**:
- Appends execution metadata
- Tracks: run ID, timestamp, error count, success rate

### Behavior

**Without State File**:
First run or missing file:
- Defaults to epoch (processes all historical errors)
- May be large initial batch
- Subsequent runs incremental

**With LOOKBACK_MINUTES**:
Manual override in .env:
- Ignores state file
- Processes last N minutes
- Useful for testing, backfilling

### Why Incremental Processing?

**Efficiency**:
- Don't reprocess already-handled errors
- Reduces API costs (LLM, embeddings)
- Faster execution

**Idempotency**:
- Same error processed once
- Vector DB handles duplicates via fingerprints
- Safe to re-run if interrupted

**Scalability**:
- Works for high-volume error streams
- Processes only new errors each run
- Keeps batch sizes manageable

---

## main.py

### Purpose
Application entry point providing both CLI and API modes. Orchestrates initialization, error processing, and dependency injection.

### Application Modes

**CLI Mode**:
- One-shot execution
- Processes errors and exits
- Suitable for cron jobs, scheduled tasks
- Updates state file for next run

**API Mode**:
- Long-running FastAPI server
- Exposes HTTP endpoints
- Processes errors on-demand
- Stateless (no state file updates)

### Initialization Sequence

1. **Load Configuration**: Parse .env, validate settings
2. **Create Monitoring Tool**: Factory instantiation based on MONITORING_TOOL
3. **Initialize Vector DB**: Connect to Weaviate (optional)
4. **Create Agent**: Instantiate with dependencies injected
5. **Inject Monitoring Tool**: Set for fetch_monitoring_context tool

### CLI Workflow

1. Fetch errors since last_seen (or lookback window)
2. Normalize to ErrorInput format
3. Deduplicate by fingerprint
4. Process each error through agent
5. Store solutions in Weaviate
6. Update state file with new last_seen

### API Endpoints

**POST /debug**:
Single error debugging:
- Input: project, title, error_type, description, environment
- Output: success, recommendation, steps, error
- Synchronous processing

**POST /batch**:
Multiple errors:
- Input: List of DebugRequest
- Output: List of DebugResponse
- Parallel processing

**GET /health**:
System health check:
- Returns status, mode, monitoring tool
- Checks agent initialization

**GET /vector-db/health**:
Weaviate connectivity:
- Tests connection
- Checks schema existence

**POST /vector-db/search**:
Direct similarity search:
- Bypasses agent
- Queries cached solutions
- Returns top match

### Dependency Injection

**Why?**:
- Agent is tool/DB agnostic
- Easy to test (mock dependencies)
- Supports multiple backends

**What's Injected**:
- Vector DB instance (WeaviateVectorDB)
- Monitoring tool instance (CloudWatchMonitor/SentryMonitor)
- Tools are auto-discovered, not injected

### Error Handling

**Per-Error Isolation**:
One error failure doesn't stop batch:
- Try/except around each error
- Log failure, continue to next
- Partial success possible

**Graceful Degradation**:
- Missing vector DB → continue without cache
- Tool failures → logged, partial results returned
- Monitoring tool errors → logged, no crash

### Why Both Modes?

**CLI for Automation**:
- Cron jobs
- CI/CD pipelines
- Scheduled batch processing
- State file for incremental

**API for Integration**:
- Webhooks from monitoring tools
- On-demand debugging
- Interactive UIs
- Real-time processing

---

## Design Principles Across Utilities

### Fail Fast
Configuration errors detected at startup, not during processing:
- Clear error messages
- No partial initialization
- Easy to diagnose

### Single Responsibility
Each utility does one thing:
- config.py: Load settings
- exceptions.py: Define errors
- state.py: Track progress
- main.py: Orchestrate

### No Hidden State
All state explicit:
- State file on disk (not in-memory)
- Configuration from .env (not hardcoded)
- Dependencies injected (not global)

### Testability
Utilities designed for testing:
- Dataclasses (pure data)
- Exception hierarchy (precise mocking)
- State manager (file path injectable)
- Main app (dependencies injectable)
