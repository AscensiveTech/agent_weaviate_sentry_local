# Normalization Layer

## Purpose
Transforms tool-specific error formats (CloudWatch, Sentry, Datadog, etc.) into a unified `ErrorInput` model that the agent can process consistently.

## Why Normalization?

### Heterogeneous Data Sources
Each monitoring tool has different schemas:
- CloudWatch: Log streams with unstructured messages
- Sentry: Structured issues with stack traces
- Datadog: Events with tags
- New Relic: Transactions with traces

Without normalization, the agent would need tool-specific logic for each source.

### Unified Processing
Single `ErrorInput` model enables:
- Tool-agnostic agent code
- Consistent vector DB schema
- Portable solutions across tools

---

## Transformation Pipeline

### Stage 1: Tool-Specific → UnifiedError
Each monitoring adapter returns `UnifiedError` objects:
- CloudWatch parser extracts from log messages
- Sentry parser extracts from issue JSON
- Standard intermediate format

### Stage 2: Deduplication
Group identical errors using fingerprints:
- Generate SHA-256 hash of error signature
- Count occurrences per fingerprint
- Keep one representative per group

### Stage 3: UnifiedError → ErrorInput
Convert to final agent-consumable format:
- Map fields to ErrorInput schema
- Add tech stack detection
- Preserve tool metadata

---

## Fingerprinting

### Why Fingerprints?
Identical errors can appear multiple times in a batch:
- Same error logged 50 times in 5 minutes
- Processing each separately wastes API calls
- Deduplication reduces cost and improves signal

### Algorithm
Hash of normalized signature:
1. Error message (lowercased, dynamic values removed)
2. Error code/type
3. Primary stack frame (culprit) if available

**Ignores**: Timestamps, request IDs, dynamic values

### Example
```
"ConnectionError: timeout after 30s at handler.py:42"
→ sha256("connectionerror timeout handler.py")
→ fingerprint: "a3f8b92c..."
```

---

## Tech Stack Detection

### Purpose
Understanding the technology context helps the agent:
- Use appropriate search tools
- Provide language-specific guidance
- Identify framework-specific patterns

### Detection Methods

**From Log Content** (CloudWatch):
- Regex patterns for languages, frameworks
- Stack trace file extensions (.py, .js, .java)
- Import statements and package names

**From Metadata** (Sentry):
- event.sdk.name ("sentry.python", "sentry.javascript")
- event.platform field
- event.contexts (Django, Flask, Express)

**From Tags** (General):
- Common tags like "language", "framework", "runtime"
- Deployment platform indicators (Lambda, Kubernetes)

### Extracted Information
Tech stack JSON includes:
- **Languages**: Python, Java, Node.js, Ruby, Go, .NET
- **Frameworks**: Django, Spring, Express, Rails, React
- **Databases**: PostgreSQL, MySQL, MongoDB, Redis
- **Platform**: AWS Lambda, Kubernetes, Docker

---

## Field Mapping

### Core Error Fields
Essential for debugging:
- **project**: Logical grouping (service name, app name)
- **error_description**: Full message + context (used for embeddings)
- **error_code**: Status code or exception type
- **environment**: production, staging, development

### Temporal Fields
Track error lifecycle:
- **last_seen**: Most recent occurrence
- **first_seen**: Initial occurrence
- **occurrence_count**: How many times seen in batch

### Debugging Context
Help locate issue:
- **culprit**: Function or file where error occurred
- **stacktrace_files**: List of files in stack trace
- **context_metadata**: Tool-specific details (log streams, issue IDs)

### Normalization Metadata
Track data provenance:
- **source_tool**: Which monitoring tool this came from
- **severity**: Raw severity from source (not standardized)
- **error_fingerprint**: Deduplication hash

---

## Severity Handling

### Why NOT Normalized?
Different tools use different severity taxonomies:
- Sentry: fatal, error, warning, info, debug (5 levels)
- CloudWatch: Inferred from log content (variable)
- Datadog: emergency, alert, critical, error, warning, notice, info, debug (8 levels)

**Decision**: Store raw severity, don't attempt mapping
- Avoids information loss
- Preserves tool semantics
- Agent can interpret based on source_tool

### When Matters
Severity is useful for:
- Filtering (process critical errors first)
- Context (understanding impact level)
- Display (showing urgency in UI)

---

## Occurrence Counting

### Why Count?
Multiple occurrences indicate:
- High-frequency issue
- Systematic problem vs. one-off
- Potential broader impact

### Aggregation Strategy
Within a single batch (5-minute window):
1. Group errors by fingerprint
2. Count occurrences per group
3. Store count in occurrence_count field
4. Track first_seen and last_seen timestamps

### Use Cases
- Prioritize high-occurrence errors
- Identify cascading failures
- Understand error patterns

---

## Error Filtering

### Exclude Non-Errors
Only process actual errors:
- Include: ERROR, FATAL, CRITICAL, Exception
- Exclude: INFO, DEBUG, TRACE

**Why?** 
- Reduce noise
- Focus agent on actionable issues
- Avoid wasting API calls on routine logs

### CloudWatch Filtering
Uses error keywords to identify problems:
- ERROR, Exception, FATAL, CRITICAL, Traceback
- Based on common logging frameworks (log4j, Python logging, Winston)

---

## Design Principles

### Lossless Transformation
Original tool metadata preserved in `context_metadata`:
- CloudWatch: log stream names, request IDs
- Sentry: issue IDs, event IDs, breadcrumbs
- Enables tool-specific operations like fetching surrounding context

### Extensibility
Adding support for new monitoring tools:
1. Implement tool adapter returning `UnifiedError`
2. Map tool fields to `UnifiedError` fields
3. Normalizer handles rest automatically

### Idempotency
Running normalization multiple times on same data produces same result:
- Deterministic fingerprinting
- Stable field mapping
- No hidden state
