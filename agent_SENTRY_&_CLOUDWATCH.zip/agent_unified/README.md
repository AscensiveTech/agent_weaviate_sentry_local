# Error Monitoring Agent

**AI-Powered Error Analysis & Resolution System**

An intelligent agent that automatically processes errors from monitoring tools (CloudWatch, Sentry), searches for solutions across multiple sources, and maintains a knowledge base of resolutions using vector similarity search.

---

## 🏗️ Architecture Overview

### Core Components

1. **Agent Core** (`src/core/`)
   - DebuggingAgent: Main orchestration engine using LangGraph
   - Implements workflow: DB Check → Tool Search → Solution Synthesis

2. **Monitoring Adapters** (`src/monitoring/`)
   - CloudWatch: AWS CloudWatch Logs integration
   - Sentry: Sentry error tracking integration
   - Factory pattern for easy extension

3. **Vector Database** (`src/vector_db/`)
   - Weaviate Cloud integration for solution caching
   - Semantic similarity search using OpenAI embeddings
   - Stores 21 fields per error-solution pair

4. **Tools** (`src/tools/`)
   - context7_search: Official documentation lookup
   - search_stackoverflow: Stack Overflow Q&A search
   - search_github_issues: GitHub issue tracker search
   - search_developer_forums: Community forum search
   - search_web: General web search (Tavily)
   - fetch_monitoring_context: Retrieves surrounding logs from monitoring system

5. **Normalization Layer** (`src/normalization/`)
   - Converts tool-specific errors into unified format
   - Handles deduplication and fingerprinting

6. **Configuration** (`src/config.py`)
   - Centralized configuration management
   - All credentials loaded from .env

7. **State Management** (`src/state.py`)
   - Tracks last processing timestamp
   - Enables incremental error processing

---

## 📊 Workflow

```
1. Fetch Errors from Monitoring Tool
   ↓
2. Normalize & Deduplicate
   ↓
3. Check Vector DB for Similar Solutions (≥80% similarity)
   ↓
   ├─ High Confidence (rating==0: similarity≥0.8 | rating>0: similarity≥0.8 AND rating>4)
   │  └─ Return Cached Solution
   │
   └─ Medium/Low Confidence
      ↓
      4. Agent Analyzes with Tools
         - Knowledge-first approach
         - Use search tools if needed
         - fetch_monitoring_context as additional context source
      ↓
      5. LLM Synthesizes Solution
         - Validates against retrieved content
         - Returns solution or INSUFFICIENT_INFORMATION
      ↓
      6. Store in Vector DB
```

---

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- AWS credentials (for CloudWatch) OR Sentry credentials
- OpenAI API key
- Weaviate Cloud instance

### Installation

```bash
# 1. Clone repository
cd agent_unified

# 2. Create virtual environment
python -m venv .venv
.venv\Scripts\activate  # Windows
source .venv/bin/activate  # Linux/Mac

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your credentials
```

### Configuration

Edit `.env` file:

```bash
# Choose monitoring tool
MONITORING_TOOL=CLOUDWATCH  # or SENTRY

# OpenAI for LLM and embeddings
OPENAI_API_KEY=your_key_here

# Weaviate Cloud
WEAVIATE_URL=your_cluster.weaviate.cloud
WEAVIATE_API_KEY=your_key_here

# AWS CloudWatch (if using CLOUDWATCH)
AWS_REGION=us-east-1
CLOUDWATCH_LOG_GROUPS=your-log-group

# Sentry (if using SENTRY)
SENTRY_AUTH_TOKEN=your_token
SENTRY_ORG_SLUG=your_org
SENTRY_PROJECT_SLUG=your_project
```

### Run

```bash
# CLI Mode (one-time processing)
python main.py --mode cli

# API Mode (web server)
python main.py --mode api --port 8000
```

---

## 📁 Project Structure

```
agent_unified/
├── main.py                      # Application entry point
├── requirements.txt             # Python dependencies
├── .env                         # Configuration (not in git)
├── .gitignore                   # Git exclusions
│
└── src/
    ├── __init__.py             # Package exports
    ├── config.py               # Configuration loader
    ├── exceptions.py           # Custom exceptions
    ├── state.py                # State management
    │
    ├── core/                   # Agent orchestration
    │   ├── __init__.py
    │   └── agent.py            # DebuggingAgent, models
    │
    ├── monitoring/             # Monitoring tool adapters
    │   ├── __init__.py
    │   ├── base.py             # Abstract interface
    │   ├── factory.py          # Factory pattern
    │   ├── cloudwatch.py       # AWS CloudWatch
    │   ├── sentry.py           # Sentry integration
    │   └── config.py           # Monitoring config
    │
    ├── vector_db/              # Vector database layer
    │   ├── __init__.py
    │   ├── interface.py        # Abstract interface
    │   └── weaviate_client.py  # Weaviate implementation
    │
    ├── normalization/          # Error normalization
    │   ├── __init__.py
    │   └── normalizer.py       # Unified error format
    │
    └── tools/                  # LangChain tools
        ├── __init__.py         # Auto-discovery
        ├── _shared.py          # Utility functions
        ├── context7_search.py
        ├── search_stackoverflow.py
        ├── search_github_issues.py
        ├── search_developer_forums.py
        ├── search_web.py
        └── fetch_monitoring_context.py
```

---

## 🎯 Key Features

### 1. **Multi-Source Error Ingestion**
- AWS CloudWatch Logs with configurable log groups
- Sentry error tracking with project-specific filtering
- Extensible factory pattern for adding new sources

### 2. **Intelligent Solution Caching**
- Vector similarity search using OpenAI embeddings (1536 dimensions)
- Automatic solution reuse for similar errors (≥80% similarity threshold)
- User feedback loop with 0-5 rating system

### 3. **Comprehensive Search Capabilities**
- Official documentation (Context7)
- Community knowledge (Stack Overflow, developer forums)
- Bug tracking (GitHub issues)
- General web search (Tavily)
- Monitoring system context (fetch surrounding logs)

### 4. **Knowledge-First Approach**
- Agent prioritizes internal LLM knowledge
- Uses tools only when necessary
- Explicitly refuses when information is insufficient

### 5. **Production-Ready**
- Deduplication via error fingerprinting
- Incremental processing (tracks last run)
- Configurable lookback windows
- FastAPI endpoints for integration

---

## 🔧 Configuration Philosophy

**You Configure:** API keys, credentials, service endpoints

**Code Handles:** Industry standards, error patterns, best practices

### Configurable via .env:
✅ Credentials and API keys
✅ Service endpoints (AWS region, Sentry org)
✅ Optional: lookback windows, model selection

### Hardcoded in Code:
🔧 CloudWatch error keywords (ERROR, Exception, Failed, etc.)
🔧 Sentry severity mappings
🔧 LLM prompts and decision logic
🔧 Similarity thresholds

---

## 📊 Data Flow

### Error Processing

```
Monitoring Tool → Normalize → Check Cache → [Hit: Return] or [Miss: Agent → Synthesize → Store]
```

### Agent Decision Tree

```
1. Search Vector DB (similarity ≥ 70%)
   ├─ No matches → Proceed to agent
   └─ Matches found
      ├─ rating=0 AND similarity≥0.8 → Use cached
      ├─ rating>0 AND similarity≥0.8 AND rating>4 → Use cached
      └─ Otherwise → Pass to agent with context

2. Agent Processing
   ├─ Can solve from knowledge? → Provide solution
   ├─ Need external info? → Use search tools
   ├─ Still insufficient? → Use fetch_monitoring_context
   └─ Still can't solve? → Return INSUFFICIENT_INFORMATION
```

---

## 🛡️ Error Handling

- **Graceful degradation**: Agent works without vector DB (no caching)
- **API resilience**: Retries with exponential backoff
- **Validation**: All inputs validated via Pydantic models
- **Logging**: Comprehensive logging at INFO level

---

## 🔌 API Endpoints (API Mode)

### `GET /`
Service information and status

### `GET /health`
Health check (agent, monitoring tool, vector DB status)

### `POST /debug`
Manually debug a specific error

**Request:**
```json
{
  "project": "my-app",
  "title": "Database Connection Error",
  "error_type": "ConnectionError",
  "description": "Failed to connect to PostgreSQL database",
  "environment": "production"
}
```

**Response:**
```json
{
  "success": true,
  "recommendation": "Check database connection string...",
  "steps": ["Verify credentials", "Check network", "Review logs"]
}
```

---

## 🧪 Testing

```bash
# Test imports
python -c "from src import DebuggingAgent, ErrorInput; print('OK')"

# Test vector DB connection
python -c "from src import WeaviateVectorDB; db = WeaviateVectorDB(); print(db.initialize())"

# Run in CLI mode with lookback
python main.py --mode cli --lookback 60
```

---

## 📝 Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MONITORING_TOOL` | Yes | - | CLOUDWATCH or SENTRY |
| `OPENAI_API_KEY` | Yes | - | OpenAI API key |
| `WEAVIATE_URL` | Yes | - | Weaviate cluster URL |
| `WEAVIATE_API_KEY` | Yes | - | Weaviate API key |
| `AWS_REGION` | If CloudWatch | us-east-1 | AWS region |
| `CLOUDWATCH_LOG_GROUPS` | If CloudWatch | - | Comma-separated log groups |
| `SENTRY_AUTH_TOKEN` | If Sentry | - | Sentry auth token |
| `SENTRY_ORG_SLUG` | If Sentry | - | Sentry organization |
| `SENTRY_PROJECT_SLUG` | If Sentry | - | Sentry project |
| `LLM_MODEL` | No | gpt-4o | OpenAI model |
| `LLM_TEMPERATURE` | No | 0 | LLM temperature (0-1) |
| `LOOKBACK_MINUTES` | No | Since last run | Historical lookback |

---

## 🚦 Status

**Production Ready** ✅

- Tested with AWS CloudWatch and Sentry
- Handles 1000+ errors per run
- Sub-second vector similarity search
- Graceful error handling throughout

---

**Last Updated:** December 15, 2025
