"""
Main application entry point for the error monitoring agent.

This module provides both CLI and API modes for processing errors from
various monitoring tools (CloudWatch, Sentry) using an AI-powered agent.
"""
import sys
import logging
import argparse
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Optional

import uvicorn
from fastapi import FastAPI, HTTPException

from src.config import get_config
from src.exceptions import AgentError, ConfigurationError
from src.core import DebuggingAgent, DebugRequest, DebugResponse, ErrorInput
from src.vector_db import WeaviateVectorDB
from src.normalization import ErrorNormalizer
from src.state import StateManager
from src.monitoring import MonitoringToolFactory


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class AgentApplication:
    """Main application class managing agent lifecycle and dependencies."""
    
    def __init__(self):
        """Initialize application components."""
        self.config = None
        self.vector_db: Optional[WeaviateVectorDB] = None
        self.agent: Optional[DebuggingAgent] = None
        self.monitoring_tool = None
        self.normalizer = ErrorNormalizer()
        self.state_manager = StateManager()
    
    def initialize(self) -> bool:
        """
        Initialize all application components.
        
        Returns:
            True if initialization successful, False otherwise.
        """
        try:
            logger.info("Initializing application components")
            
            # Load configuration
            self.config = get_config()
            
            # Initialize vector database
            self.vector_db = WeaviateVectorDB()
            vector_db_initialized = self.vector_db.initialize()
            if vector_db_initialized:
                logger.info("✅ Vector database initialized")
            else:
                logger.warning("⚠️  Vector database unavailable - running without solution caching")
                # Create dummy functions for agent to use
                self.vector_db.search_similar = lambda desc, thresh=0.9: None
                self.vector_db.store_solution = lambda inp, sol: False
            
            # Initialize monitoring tool
            self.monitoring_tool = MonitoringToolFactory.create(
                self.config.monitoring_tool
            )
            self.monitoring_tool.validate_connection()
            logger.info(f"Monitoring tool initialized: {self.config.monitoring_tool}")
            
            # Initialize agent
            self.agent = DebuggingAgent(
                llm_model=self.config.llm.model,
                llm_temperature=self.config.llm.temperature,
                vector_db_search=self.vector_db.search_similar,
                vector_db_store=self.vector_db.store_solution,
            )
            logger.info("Agent initialized")
            
            # Configure tool callbacks
            self._configure_tool_callbacks()
            
            logger.info("Initialization complete")
            return True
            
        except ConfigurationError as e:
            logger.error(f"Configuration error: {e}")
            return False
        except AgentError as e:
            logger.error(f"Initialization error: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during initialization: {e}", exc_info=True)
            return False
    
    def _configure_tool_callbacks(self):
        """Configure monitoring tool callbacks for agent tools."""
        try:
            from src.tools import fetch_monitoring_context
            fetch_monitoring_context.set_monitoring_tool(self.monitoring_tool)
        except Exception as e:
            logger.warning(f"Failed to configure tool callbacks: {e}")
    
    def _determine_lookback_timestamp(
        self,
        lookback_minutes: Optional[int] = None
    ) -> str:
        """
        Determine the timestamp to start fetching errors from.
        
        Args:
            lookback_minutes: Override lookback period in minutes.
                            None = use config or state file.
                            <= 0 = fetch all history.
        
        Returns:
            ISO 8601 timestamp string.
        """
        # Explicit lookback parameter
        if lookback_minutes is not None:
            if lookback_minutes <= 0:
                logger.info("Fetching complete history")
                return "1970-01-01T00:00:00Z"
            
            timestamp = (
                datetime.utcnow() - timedelta(minutes=lookback_minutes)
            ).isoformat() + "Z"
            logger.info(f"Fetching last {lookback_minutes} minutes")
            return timestamp
        
        # Environment configuration
        if self.config.lookback_minutes is not None:
            if self.config.lookback_minutes <= 0:
                logger.info("Fetching complete history (from config)")
                return "1970-01-01T00:00:00Z"
            
            timestamp = (
                datetime.utcnow() - timedelta(minutes=self.config.lookback_minutes)
            ).isoformat() + "Z"
            logger.info(f"Fetching last {self.config.lookback_minutes} minutes (from config)")
            return timestamp
        
        # State file or default
        state_file = f"agent_state_{self.config.monitoring_tool.lower()}.json"
        last_seen = self.state_manager.get_last_seen(state_file)
        
        if last_seen == "1970-01-01T00:00:00Z":
            # First run default: 30 days
            timestamp = (datetime.utcnow() - timedelta(days=30)).isoformat() + "Z"
            logger.info("First run: fetching last 30 days")
            return timestamp
        
        logger.info(f"Fetching since last run: {last_seen}")
        return last_seen
    
    def process_errors(self, lookback_minutes: Optional[int] = None):
        """
        Fetch, normalize, and process errors from monitoring tool.
        
        Args:
            lookback_minutes: Optional override for lookback period.
        
        Raises:
            RuntimeError: If agent not initialized.
            AgentError: If processing fails.
        """
        if not all([self.agent, self.monitoring_tool, self.vector_db]):
            raise RuntimeError("Application not initialized. Call initialize() first.")
        
        state_file = f"agent_state_{self.config.monitoring_tool.lower()}.json"
        last_seen = self._determine_lookback_timestamp(lookback_minutes)
        
        try:
            # Fetch raw errors
            logger.info(f"Fetching errors from {self.config.monitoring_tool}")
            raw_errors = self.monitoring_tool.fetch_errors_since(last_seen)
            logger.info(f"Fetched {len(raw_errors)} raw log entries")
            
            if not raw_errors:
                logger.info("No new errors found")
                return
            
            # Normalize and filter
            logger.info("Normalizing and filtering errors")
            error_inputs = self.normalizer.normalize_batch(
                unified_errors=raw_errors,
                filter_non_errors=True,
                deduplicate=True
            )
            
            if not error_inputs:
                logger.info("No actionable errors after filtering")
                self.state_manager.save_last_seen(
                    datetime.utcnow().isoformat() + "Z",
                    state_file
                )
                return
            
            logger.info(f"Processing {len(error_inputs)} unique errors")
            
            # Process each error
            processed_count = 0
            for idx, error in enumerate(error_inputs, 1):
                logger.info(f"[{idx}/{len(error_inputs)}] {error.title}")
                
                try:
                    state = self.agent.solve(error)
                    if state and state.get("solution"):
                        solution = state["solution"]
                        from_cache = state.get("solution_from_db", False)
                        
                        # Check if solution indicates insufficient information
                        if solution.recommendation.startswith("INSUFFICIENT_INFORMATION:"):
                            logger.warning(f"  ⚠️ Agent could not provide confident solution")
                            logger.warning(f"  Reason: {solution.recommendation}")
                            # Do NOT store insufficient information responses
                            continue
                        
                        # Valid solution (confidence already checked by agent caching logic)
                        cache_status = "cached" if from_cache else "new"
                        logger.info(f"  ✅ Solution generated ({cache_status})")
                        
                        if not from_cache:
                            self.vector_db.store_solution(error, solution, False)
                        
                        processed_count += 1
                    else:
                        logger.warning("  ⚠️ No solution generated")
                        
                except Exception as e:
                    logger.error(f"  ❌ Failed to process error: {e}")
            
            # Update state
            self.state_manager.save_last_seen(
                datetime.utcnow().isoformat() + "Z",
                state_file
            )
            
            # Log summary
            reduction_pct = (
                (len(raw_errors) - len(error_inputs)) / len(raw_errors) * 100
            ) if raw_errors else 0
            
            logger.info("-" * 60)
            logger.info(
                f"Processing complete: {processed_count}/{len(error_inputs)} errors solved | "
                f"Noise reduction: {reduction_pct:.1f}%"
            )
            logger.info("-" * 60)
            
        except Exception as e:
            logger.error(f"Error processing pipeline failed: {e}", exc_info=True)
            raise AgentError(f"Processing failed: {e}") from e


# Global application instance
app_instance = AgentApplication()


# ============================================================================
# FastAPI Application
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    if not app_instance.initialize():
        logger.error("Failed to initialize application")
        sys.exit(1)
    yield


app = FastAPI(
    title="Error Monitoring Agent",
    description="AI-powered error analysis and resolution",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/")
async def root():
    """Root endpoint with service information."""
    return {
        "service": "Error Monitoring Agent",
        "version": "1.0.0",
        "monitoring_tool": app_instance.config.monitoring_tool if app_instance.config else "not initialized",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    is_healthy = all([
        app_instance.agent is not None,
        app_instance.monitoring_tool is not None,
        app_instance.vector_db is not None
    ])
    
    if is_healthy:
        return {
            "status": "healthy",
            "agent": "ready",
            "monitoring_tool": app_instance.config.monitoring_tool,
            "vector_db": "connected"
        }
    
    return {
        "status": "unhealthy",
        "agent": app_instance.agent is not None,
        "monitoring_tool": app_instance.monitoring_tool is not None,
        "vector_db": app_instance.vector_db is not None
    }


@app.post("/debug", response_model=DebugResponse)
async def debug_error(request: DebugRequest):
    """Debug a single error manually."""
    if not app_instance.agent:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    
    try:
        error_input = ErrorInput(
            project=request.project,
            title=request.title,
            error_code=request.error_type,
            error_description=request.description,
            last_seen=datetime.utcnow().isoformat() + "Z",
            environment=request.environment or "unknown",
            source_tool="API",
            error_fingerprint=f"api_{hash(request.description)}",
            occurrence_count=1,
            first_seen=datetime.utcnow().isoformat() + "Z",
        )
        
        state = app_instance.agent.solve(error_input)
        
        if state and state.get("solution"):
            solution = state["solution"]
            
            # Check if solution indicates insufficient information
            if solution.recommendation.startswith("INSUFFICIENT_INFORMATION:"):
                return DebugResponse(
                    success=False,
                    error=solution.recommendation
                )
            
            # Valid solution (confidence already checked by agent caching logic)
            return DebugResponse(
                success=True,
                recommendation=solution.recommendation,
                steps=solution.troubleshooting_steps
            )
        
        return DebugResponse(
            success=False,
            error="Solution generation failed"
        )
        
    except Exception as e:
        logger.error(f"Debug endpoint error: {e}")
        return DebugResponse(success=False, error=str(e))


# ============================================================================
# CLI Entry Point
# ============================================================================

def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Error Monitoring Agent - AI-powered error analysis"
    )
    parser.add_argument(
        "--mode",
        choices=["api", "cli"],
        default="cli",
        help="Execution mode: 'api' for web server, 'cli' for one-time processing"
    )
    parser.add_argument(
        "--lookback",
        type=int,
        default=None,
        help="Minutes to look back (default: since last run, <=0: all history)"
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="API server host (default: 0.0.0.0)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="API server port (default: 8000)"
    )
    
    args = parser.parse_args()
    
    if args.mode == "api":
        logger.info(f"Starting API server on {args.host}:{args.port}")
        uvicorn.run(app, host=args.host, port=args.port)
    else:
        if app_instance.initialize():
            app_instance.process_errors(lookback_minutes=args.lookback)
        else:
            logger.error("Failed to initialize application")
            sys.exit(1)


if __name__ == "__main__":
    main()
